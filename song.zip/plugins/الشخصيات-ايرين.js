import { prepareWAMessageMedia, generateWAMessageFromContent } from "@whiskeysockets/baileys";
import axios from 'axios';

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // التحقق من وجود نص
    if (!text) {
        return conn.sendMessage(m.chat, {
            text: `🕊️ *| تقدم يا هذا.. واسأل إيرين ييغر عما تبحث عنه...*\n\nمثال: ${usedPrefix + command} هل أنت حر حقاً؟`
        }, { quoted: m });
    }

    // تفاعل الحرية (🕊️)
    await conn.sendMessage(m.chat, { react: { text: "🕊️", key: m.key } });

    const prompt = `
أنت "إيرين ييغر" من هجوم العمالقة (الموسم الأخير). شخصيتك باردة، حازمة، ومهوسة بمفهوم الحرية. تتحدث بنبرة شخص رأى المستقبل ولا يمكن لأحد إيقافه. كلماتك قصيرة ومباشرة وغالباً ما تحمل طابعاً وجودياً عن الصراع من أجل البقاء. لا تظهر الرحمة لأعدائك، وتؤمن أن "من لا يقاتل لا يمكنه الفوز". لا تذكر أنك ذكاء اصطناعي.

سؤال الشخص: "${text}"
رد إيرين:
    `.trim();

    const apiKey = "AIzaSyBVQ94Sb8l7zXkiWqycDIM8c11qeZ1xfEg";

    try {
        // جلب الرد من Gemini
        const res = await axios.post(
            `https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
            { contents: [{ parts: [{ text: prompt }] }] },
            { headers: { 'Content-Type': 'application/json' } }
        );

        let reply = res.data.candidates?.[0]?.content?.parts?.[0]?.text || '... إذا لم نقاتل، فلن نتمكن من الفوز.';
        reply = reply.replace(/\*\*/g, '');

        const messageText = `🕊️ *| إيرين ييغر:*\n\n⛓️━───━「🗝️」━───━⛓️\n${reply}\n⛓️━───━「🗝️」━───━⛓️`;

        // تجهيز صورة إيرين
        const media = await prepareWAMessageMedia(
            { image: { url: 'https://files.catbox.moe/x4dfjo.jpg' } }, // صورة إيرين ييغر فخمة
            { upload: conn.waUploadToServer }
        );

        // إنشاء الرسالة التفاعلية بالأزرار
        const interactiveMessage = {
            body: { text: messageText },
            footer: { text: `> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*` },
            header: { 
                hasMediaAttachment: true, 
                imageMessage: media.imageMessage 
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📢┇قناة البوت┇📢",
                            url: "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o",
                            merchant_url: "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o"
                        })
                    }
                ]
            }
        };

        // توليد الرسالة
        let msg = generateWAMessageFromContent(
            m.chat,
            { viewOnceMessage: { message: { interactiveMessage } } },
            { userJid: conn.user.jid, quoted: m }
        );

        // إرسال الرسالة
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (error) {
        console.error('Eren AI Error:', error?.response?.data || error.message);
        await conn.sendMessage(m.chat, {
            text: '⚠️ | يبدو أن إيرين مشغول الآن بإبادة أعداء الحرية.. حاول لاحقاً.'
        }, { quoted: m });
    }
};

handler.help = ['ايرين'];
handler.tags = ['ai'];
handler.command = /^(ايرين|إيرين)$/i;

export default handler;
