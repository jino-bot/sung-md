let handler = async (m, { conn, args, usedPrefix, command }) => {
    // التأكد من وجود سجل للمجموعة
    let chat = global.db.data.chats[m.chat]
    if (!chat) return

    // عرض الحالة
    if (!args[0]) {
        let status = chat.antiSpam ? 'مفعل ✅' : 'معطل ❌'
        return conn.reply(
            m.chat,
            `*🚫 حالة مضاد الإسبام:* ${status}\n\n` +
            `*الاستخدام:*\n` +
            `• ${usedPrefix + command} on (تفعيل)\n` +
            `• ${usedPrefix + command} off (تعطيل)`,
            m
        )
    }

    // تفعيل مضاد الإسبام
    if (args[0] === 'on') {
        if (chat.antiSpam) return m.reply('⚠️ مضاد الإسبام مفعل بالفعل.')
        chat.antiSpam = true
        return m.reply('✅ تم تفعيل مضاد الإسبام بنجاح.')
    }

    // تعطيل مضاد الإسبام
    if (args[0] === 'off') {
        if (!chat.antiSpam) return m.reply('⚠️ مضاد الإسبام معطل بالفعل.')
        chat.antiSpam = false
        return m.reply('❌ تم تعطيل مضاد الإسبام بنجاح.')
    }

    // إدخال خاطئ
    return m.reply(
        `❌ أمر غير صحيح\n\n` +
        `*استخدم:*\n` +
        `• ${usedPrefix + command} on\n` +
        `• ${usedPrefix + command} off`
    )
}

// تعريفات الأمر
handler.help = ['اسبام']
handler.tags = ['group']
handler.command = ['اسبام', 'antispam']

// القيود
handler.group = true
handler.admin = true
handler.botAdmin = false

export default handler