let handler = async (m, { conn, command, isAdmin, isOwner, isBotAdmin }) => {

  // التحقق من الصلاحيات
  if (!isAdmin && !isOwner)
    return m.reply('*[❗] هذا الأمر مخصص للمشرفين فقط!*')

  if (!isBotAdmin)
    return m.reply('*[❗] يجب أن أكون مشرفاً لأتمكن من إدارة الشات!*')

  // ===== أمر عرض الأزرار =====
  if (command === 'شات') {

    let teks = `
*❐═━━━═╊⊰💬⊱╉═━━━═❐*
*『⚙️┇إدارة شات المجموعة┇⚙️』*
*❐═━━━═╊⊰💬⊱╉═━━━═❐*

📌 اختر الإجراء المطلوب:
🔓 *فتح الشات* → السماح للجميع بالكتابة  
🔒 *قفل الشات* → المشرفين فقط  

*❐═━━━═╊⊰💬⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*
`.trim()

    return conn.sendMessage(m.chat, {
      text: teks,
      buttons: [
        { buttonId: '.فتح_الشات', buttonText: { displayText: '🔓 فتح الشات' }, type: 1 },
        { buttonId: '.قفل_الشات', buttonText: { displayText: '🔒 قفل الشات' }, type: 1 }
      ],
      headerType: 1
    }, { quoted: m })
  }

  // ===== فتح الشات =====
  if (command === 'فتح_الشات') {
    await conn.groupSettingUpdate(m.chat, 'not_announcement')
    return m.reply('🔓 *تم فتح الشات، يمكن للجميع الكتابة الآن.*')
  }

  // ===== قفل الشات =====
  if (command === 'قفل_الشات') {
    await conn.groupSettingUpdate(m.chat, 'announcement')
    return m.reply('🔒 *تم قفل الشات، الكتابة للمشرفين فقط.*')
  }
}

handler.help = ['شات', 'فتح_الشات', 'قفل_الشات']
handler.tags = ['group']
handler.command = /^(شات|فتح_الشات|قفل_الشات)$/i
handler.group = true
handler.botAdmin = true

export default handler