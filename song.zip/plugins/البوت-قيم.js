import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const RATINGS_FILE = path.join(__dirname, '../src/JSON/التقييمات.json');
const DEVELOPER_JID = '23595456638@s.whatsapp.net';
const IMAGE_PATH = './src/media/Menu3.jpg'; // المسار الذي طلبته

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // التأكد من وجود المجلد والملف
    let dir = path.dirname(RATINGS_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(RATINGS_FILE)) fs.writeFileSync(RATINGS_FILE, JSON.stringify({}, null, 2));

    let stars = parseInt(text);

    // الحالة الأولى: عرض قائمة النجوم بالأزرار
    if (!stars || stars < 1 || stars > 5) {
        const ratingMenu = `
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
*❒ ⇇ مرحباً بك في قسم تقييم بوت سونغ 💻*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*

> *من فضلك اختر رقم النجوم لتقييم تجربتك مع البوت 🥺*

*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`.trim();

        // إرسال الأزرار مع الصورة
        let buttons = [
            ['⭐️', `${usedPrefix + command} 1`],
            ['⭐️⭐️', `${usedPrefix + command} 2`],
            ['⭐️⭐️⭐️', `${usedPrefix + command} 3`],
            ['⭐️⭐️⭐️⭐️', `${usedPrefix + command} 4`],
            ['⭐️⭐️⭐️⭐️⭐️', `${usedPrefix + command} 5`]
        ];

        return await conn.sendButton(m.chat, ratingMenu, 'اختر عدد النجوم من الأسفل 👇', IMAGE_PATH, buttons, m);
    }

    // 📌 حفظ التقييم في ملف JSON
    let ratings = JSON.parse(fs.readFileSync(RATINGS_FILE, 'utf-8'));
    let userJid = m.sender;
    if (!ratings[m.chat]) ratings[m.chat] = {};
    ratings[m.chat][userJid] = {
        stars: stars,
        time: new Date().toLocaleString(),
        name: m.pushName || 'مستخدم'
    };
    fs.writeFileSync(RATINGS_FILE, JSON.stringify(ratings, null, 2));

    let feedback = '';
    let needsButton = false;

    switch (stars) {
        case 1:
            feedback = `*❐═━━━═╊⊰🐲⊱╉═━━━═❐*\n⭐ *تقييمك بنجمة واحدة*\n*❐═━━━═╊⊰🐲⊱╉═━━━═❐*\n\n> نعمل جاهدا لإصلاح المشاكل يرجى ابلاغنا عن مشكلتك!\n\n*❐═━━━═╊⊰🐲⊱╉═━━━═❐*\n> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`;
            needsButton = true;
            break;
        case 2:
            feedback = `*❐═━━━═╊⊰🐲⊱╉═━━━═❐*\n⭐⭐ *تقييمك بنجمتين*\n*❐═━━━═╊⊰🐲⊱╉═━━━═❐*\n\n> تجربتك لبوتاتنا شرف لنا ونرجو أن تواصل معنا للنهاية!\n\n*❐═━━━═╊⊰🐲⊱╉═━━━═❐*\n> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`;
            needsButton = true;
            break;
        case 3:
            feedback = `*❐═━━━═╊⊰🐲⊱╉═━━━═❐*\n⭐⭐⭐ *تقييمك بثلاث نجوم*\n*❐═━━━═╊⊰🐲⊱╉═━━━═❐*\n\n> 👍 تقييم لطيف، شكراً لدعمك!\n\n*❐═━━━═╊⊰🐲⊱╉═━━━═❐*\n> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`;
            break;
        case 4:
            feedback = `*❐═━━━═╊⊰🐲⊱╉═━━━═❐*\n⭐⭐⭐⭐ *تقييمك بأربع نجوم*\n*❐═━━━═╊⊰🐲⊱╉═━━━═❐*\n\n> 💪 تقييم رائع! نوعدك بالأفضل!\n\n*❐═━━━═╊⊰🐲⊱╉═━━━═❐*\n> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`;
            break;
        case 5:
            feedback = `*❐═━━━═╊⊰🐲⊱╉═━━━═❐*\n⭐⭐⭐⭐⭐ *تقييمك بخمس نجوم*\n*❐═━━━═╊⊰🐲⊱╉═━━━═❐*\n\n> يسرنا أنا أعمالنا تسعد الناس شكرا على تقييمك لبوت سونغ\n\n*❐═━━━═╊⊰🐲⊱╉═━━━═❐*\n> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`;
            break;
    }

    // إرسال الرد النهائي
    if (needsButton) {
        await conn.sendButton(m.chat, feedback, 'نعتذر عن التجربة السيئة، يمكنك الإبلاغ من هنا 👇', null, [
            ['📩 ابلاغ', `.ابلاغ مشكلة في البوت (تقييم ${stars} نجوم)`]
        ], m);
    } else {
        await m.reply(feedback);
    }

    // 📌 إرسال التقرير للمطور
    const devMsg = `
*❍━━══━━✦⭐✦━━══━━❍*
*┊   📊『 تقييم مستخدم 』📊 ┊*
*❍━━══━━✦⭐✦━━══━━❍*

📍 *المستخدم:* wa.me/${userJid.split('@')[0]}
🌟 *عدد النجوم:* ${stars}
📄 *الدردشة:* ${m.chat}
🕒 *التاريخ:* ${new Date().toLocaleString()}  

*❍━━══━━✦⭐✦━━══━━❍*`.trim();

    await conn.sendMessage(DEVELOPER_JID, { text: devMsg });
};

handler.command = /^(قيم|تقييم)$/i;
export default handler;
