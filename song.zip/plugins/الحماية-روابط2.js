let handler = async (m, { conn, args, usedPrefix, command }) => {
    // الوصول لبيانات المجموعة في قاعدة البيانات
    let chat = global.db.data.chats[m.chat]
    
    // الحالة 1: عرض الحالة الحالية (عند كتابة .الروابط2 فقط)
    if (!args[0]) {
        let status = chat.antiLink2 ? 'مفعل ✅' : 'معطل ❌'
        return m.reply(`*🛡️ حالة مانع الروابط (2):* ${status}\n\n*للتحكم استخدم:* \n• ${usedPrefix + command} on\n• ${usedPrefix + command} off`)
    }

    // الحالة 2: التفعيل
    if (args[0] === 'on') {
        if (chat.antiLink2) return m.reply('*[!] الميزة مفعلة بالفعل.*')
        chat.antiLink2 = true
        m.reply('*[ ✅ ] تم تفعيل مانع الروابط 2 بنجاح. سيتم طرد أي شخص يرسل رابطًا (https).*')
    } 
    
    // الحالة 3: التعطيل
    else if (args[0] === 'off') {
        if (!chat.antiLink2) return m.reply('*[!] الميزة معطلة بالفعل.*')
        chat.antiLink2 = false
        m.reply('*[ ❌ ] تم تعطيل مانع الروابط 2 بنجاح.*')
    } 
    
    // في حال كتابة أمر خاطئ
    else {
        m.reply(`*⚠️ أمر غير صالح! استخدم:*\n*${usedPrefix + command} on*\n*${usedPrefix + command} off*`)
    }
}

// تعريفات الأمر
handler.help = ['روابط2']
handler.tags = ['group']
handler.command = ['روابط2', 'antilink2'] // الأوامر التي يستجيب لها البوت

// الشروط
handler.group = true // يعمل في المجموعات فقط
handler.admin = true // للمشرفين فقط

export default handler
