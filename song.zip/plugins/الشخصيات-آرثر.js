import { prepareWAMessageMedia, generateWAMessageFromContent } from "@whiskeysockets/baileys";
import axios from 'axios';

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // التحقق من وجود نص
    if (!text) {
        return conn.sendMessage(m.chat, {
            text: `⚔️ *| تقدم أيها المحارب واسأل الملك آرثر...*\n\nمثال: ${usedPrefix + command} ما هو سر سيف الإكسكاليبر؟`
        }, { quoted: m });
    }

    // تفاعل التاج الملكي (👑)
    await conn.sendMessage(m.chat, { react: { text: "👑", key: m.key } });

    const prompt = `
أنت "الملك آرثر بيندراغون"، حاكم بريطانيا الأسطوري وصاحب سيف الإكسكاليبر. تتحدث بشجاعة، فخر، ونبل ملوكي. أنت حكيم وعادل، كلماتك تلهم الفرسان. لا تظهر الضعف أبداً وتتحدث بلهجة الملوك القدامى (بدون تكلف زائد ولكن بوقار). لا تذكر أنك ذكاء اصطناعي. إذا سألك أحد عن مائدتك المستديرة أو فرسانك، أجب بفخر القائد.

سؤال الشخص: "${text}"
رد الملك آرثر:
    `.trim();

    const apiKey = "AIzaSyBVQ94Sb8l7zXkiWqycDIM8c11qeZ1xfEg";

    try {
        // جلب الرد من Gemini
        const res = await axios.post(
            `https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
            { contents: [{ parts: [{ text: prompt }] }] },
            { headers: { 'Content-Type': 'application/json' } }
        );

        let reply = res.data.candidates?.[0]?.content?.parts?.[0]?.text || '... الصمت هو وقار الملوك في بعض المواقف.';
        reply = reply.replace(/\*\*/g, '');

        const messageText = `👑 *| الملك آرثر بيندراغون:*\n\n⚔️━───━「🛡️」━───━⚔️\n${reply}\n⚔️━───━「🛡️」━───━⚔️`;

        // تجهيز صورة الملك آرثر
        const media = await prepareWAMessageMedia(
            { image: { url: 'https://files.catbox.moe/x1j2j7.jpg' } }, // صورة تناسب الملك آرثر
            { upload: conn.waUploadToServer }
        );

        // إنشاء الرسالة التفاعلية بالأزرار
        const interactiveMessage = {
            body: { text: messageText },
            footer: { text: `> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*` },
            header: { 
                hasMediaAttachment: true, 
                imageMessage: media.imageMessage 
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📢┇قناة البوت┇📢",
                            url: "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o",
                            merchant_url: "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o"
                        })
                    }
                ]
            }
        };

        // توليد الرسالة
        let msg = generateWAMessageFromContent(
            m.chat,
            { viewOnceMessage: { message: { interactiveMessage } } },
            { userJid: conn.user.jid, quoted: m }
        );

        // إرسال الرسالة
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (error) {
        console.error('Arthur AI Error:', error?.response?.data || error.message);
        await conn.sendMessage(m.chat, {
            text: '⚠️ | يبدو أن الملك في اجتماع مع فرسان المائدة المستديرة الآن..'
        }, { quoted: m });
    }
};

handler.help = ['ارثر'];
handler.tags = ['ai'];
handler.command = /^(ارثر|آرثر)$/i;

export default handler;
