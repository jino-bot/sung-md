import axios from 'axios'
import cheerio from 'cheerio'

let handler = async (m, { conn, args }) => {
  const chatId = m.chat
  const query = args.join(' ').trim()

  if (!query) {
    return conn.sendMessage(chatId, {
      text: '🔍 اكتب ما تريد البحث عنه.\nمثال:\n.غوغل الذكاء الاصطناعي'
    }, { quoted: m })
  }

  // 🚀 تفاعل عند استقبال الأمر
  try {
    await conn.sendMessage(chatId, {
      react: { text: '🚀', key: m.key }
    })
  } catch {}

  const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}&hl=ar`

  try {
    const { data } = await axios.get(searchUrl, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
      }
    })

    const $ = cheerio.load(data)
    const results = []

    $('div.g').each((i, el) => {
      const title = $(el).find('h3').text()
      const link = $(el).find('a').attr('href')

      if (title && link && results.length < 5) {
        results.push({ title, link })
      }
    })

    if (results.length === 0) {
      results.push({ title: '⚠️ لم يتم العثور على نتائج', link: '' })
    }

    // ✅ تفاعل النجاح
    try {
      await conn.sendMessage(chatId, {
        react: { text: '✅', key: m.key }
      })
    } catch {}

    const textResults = results
      .map(
        (r, i) =>
          `\`#${i + 1}\` ${r.title}\n🔗 ${r.link || '—'}`
      )
      .join('\n\n')

    const decorated =
`*❐═━━━═╊⊰🔎⊱╉═━━━═❐*

*موضوع البحث:* ${query}

*أهم النتائج:*
${textResults}

*❐═━━━═╊⊰🔎⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

    await conn.sendMessage(chatId, {
      text: decorated,
      contextInfo: {
        externalAdReply: {
          thumbnailUrl:
            'https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o'
        }
      }
    }, { quoted: m })

  } catch (err) {
    console.error('Google Search Error:', err?.message || err)

    // ❌ تفاعل الخطأ
    try {
      await conn.sendMessage(chatId, {
        react: { text: '❌', key: m.key }
      })
    } catch {}

    await conn.sendMessage(chatId, {
      text: '⚠️ | حدث خطأ أثناء البحث في Google، حاول لاحقًا.'
    }, { quoted: m })
  }
}

handler.help = ['غوغل <نص>']
handler.tags = ['tools', 'search']
handler.command = ['غوغل', 'غوجل', 'google']

export default handler