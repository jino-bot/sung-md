const handler = async (m, { conn, usedPrefix, command }) => {

  // لازم يكون في رد
  if (!m.quoted) {
    return conn.reply(
      m.chat,
      `✳️ *استخدم الأمر بالرد فقط*\n\n📌 مثال:\n${usedPrefix + command} (بالرد على الشخص)`,
      m
    )
  }

  const who = m.quoted.sender
  const number = who.split('@')[0]

  switch (command) {

    // ===== إضافة مالك =====
    case 'اونر': {
      // تحقق إذا كان موجود
      if (global.owner.some(v => v[0] === number)) {
        return conn.reply(m.chat, '⚠️ هذا الرقم مالك بالفعل', m)
      }

      global.owner.push([number])

      await conn.reply(
        m.chat,
        `✅ *تمت إضافة مالك جديد*\n\n👤 الرقم: @${number}`,
        m,
        { mentions: [who] }
      )
      break
    }

    // ===== إزالة مالك =====
    case 'اناونر': {
      const index = global.owner.findIndex(v => v[0] === number)
      if (index === -1) {
        return conn.reply(m.chat, '❌ هذا الرقم غير موجود ضمن المالكين', m)
      }

      global.owner.splice(index, 1)

      await conn.reply(
        m.chat,
        `❌ *تمت إزالة المالك*\n\n👤 الرقم: @${number}`,
        m,
        { mentions: [who] }
      )
      break
    }
  }
}

handler.command = ['اونر', 'اناونر']
handler.rowner = true
handler.group = true

export default handler