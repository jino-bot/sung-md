import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

let handler = async (m, { conn, usedPrefix }) => {
    try {
        // إرسال تفاعل 🔂
        await conn.sendMessage(m.chat, { react: { text: "🔂", key: m.key } });

        let name = await conn.getName(m.sender)
        
        const messageText = `*مـــرحبــــاً بـــكـ/ﻲ يـا ❪${name}❫ في قسم الملصقات والتحويل*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *شرح القسم: يقدم مجموعة من أدوات الملصقات والتحويل لتسهيل استخدامك*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *｢🔂┊قسم الملصقات والتحويل┊🔂｣*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
┊🔢┊: \`${usedPrefix}ملصقات\`
> صنع حزم ملصقات كاملة.
┊👐┊: \`${usedPrefix}دمج\`
> دمج بين ايموجيين لتوليد استكر مزدوح.
┊✍️┊: \`${usedPrefix}حقوق\`
> كتابة حقوقك الخاص على الملصقات.
┊↪️┊: \`${usedPrefix}لملصق\`
> تحويل الصورة الى ملصق.
┊🎦┊: \`${usedPrefix}لمتحرك\`
> تحويل الفديو او الجيف الى ملصق متحرك.
┊🌐┊: \`${usedPrefix}لرابط\`
> تحويل الوسائط الى روابط لا تنتهي صلاحيتها.
┊📷┊: \`${usedPrefix}لصورة\`
> تحويل الملصق الى صورة.
┊🗣️┊: \`${usedPrefix}لصوت\`
> تحويل الفديو الى صوت.
┊✨┊: \`${usedPrefix}ميسي\`
> توليد ملصق للاسطورة ميسي.
┊🖼┊: \`${usedPrefix}ملصق\`
> توليد ملصق لشخصية معينة.
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

        // مسار الصورة المحدد
        const imagePath = path.join(__dirname, '../src/media/Menu4.jpg')

        if (fs.existsSync(imagePath)) {
            await conn.sendMessage(m.chat, {
                image: { url: imagePath },
                caption: messageText
            }, { quoted: m })
        } else {
            await conn.sendMessage(m.chat, { text: messageText }, { quoted: m })
        }

    } catch (err) {
        console.error('❌ Error in Tools Menu:', err)
    }
}

handler.help = ['الادوات']
handler.tags = ['main']
handler.command = /^(قسم17)$/i 

export default handler
