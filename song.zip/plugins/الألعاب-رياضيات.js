import { prepareWAMessageMedia, generateWAMessageFromContent } from "@whiskeysockets/baileys";

const mathGames = new Map();

const dificultades = {
  noob: { name: "｢👶┊مبتدئ┊👶｣", ops: ['+', '-'], min: 1, max: 10, tiempo: 20000, exp: [100, 200] },
  easy: { name: "｢🟢┊سهل┊🟢｣", ops: ['+', '-', '*'], min: 10, max: 30, tiempo: 25000, exp: [200, 400] },
  medium: { name: "｢🟡┊متوسط┊🟡｣", ops: ['+', '-', '*'], min: 30, max: 70, tiempo: 30000, exp: [400, 700] },
  hard: { name: "｢🔴┊صعب┊🔴｣", ops: ['+', '-', '*'], min: 70, max: 120, tiempo: 35000, exp: [700, 1000] },
  extreme: { name: "｢🔥┊خارق┊🔥｣", ops: ['+', '-', '*', '/'], min: 100, max: 250, tiempo: 40000, exp: [1000, 2000] },
  impossible: { name: "｢💀┊مستحيل┊💀｣", ops: ['+', '-', '*', '/'], min: 200, max: 999, tiempo: 45000, exp: [2000, 5000] }
};

let handler = async (m, { conn, args, command }) => {
    const dificultad = (args[0] || '').toLowerCase();

    // إذا لم يختار مستوى، نرسل الأزرار
    if (!dificultad || !dificultades[dificultad]) {
        const bodyText = `
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*『 🧭┇تحدي الرياضيات┇🧭』*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

\`اختر مستوى الصعوبة لبدء المسابقة:\`

*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`.trim();

        const buttons = Object.keys(dificultades).map(key => ({
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: dificultades[key].name,
                id: `.${command} ${key}`
            })
        }));

        const interactiveMessage = {
            body: { text: bodyText },
            footer: { text: "> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*" },
            header: { title: "", hasMediaAttachment: false },
            nativeFlowMessage: { buttons }
        };

        let msg = generateWAMessageFromContent(
            m.chat,
            { viewOnceMessage: { message: { interactiveMessage } } },
            { userJid: conn.user.jid, quoted: m }
        );

        return await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    }

    // منطق اللعبة
    if (mathGames.has(m.sender)) return m.reply('⚠️ لديك مسألة لم تحلها بعد!');

    const nivel = dificultades[dificultad];
    const a = Math.floor(Math.random() * (nivel.max - nivel.min + 1)) + nivel.min;
    const b = Math.floor(Math.random() * (nivel.max - nivel.min + 1)) + nivel.min;
    const op = nivel.ops[Math.floor(Math.random() * nivel.ops.length)];
    
    let result = op === '/' ? parseFloat((a / b).toFixed(2)) : eval(`${a}${op}${b}`);
    const recompensa = Math.floor(Math.random() * (nivel.exp[1] - nivel.exp[0] + 1)) + nivel.exp[0];
    
    mathGames.set(m.sender, { 
        result, 
        exp: recompensa, 
        intentos: 3, 
        timeout: setTimeout(() => {
            if (mathGames.has(m.sender)) {
                mathGames.delete(m.sender);
                conn.reply(m.chat, `⌛ *انتهى الوقت!*\nالناتج الصحيح هو: *${result}*`, m);
            }
        }, nivel.tiempo)
    });

    return conn.reply(m.chat, `
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
┆ ما هو نتيجة: *${a} ${op} ${b} = ?*
┆┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈
┆🧭 الوقت: *${nivel.tiempo / 1000} ثانية*
┆🏆 الجائزة: *${recompensa} XP*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> *أجب على هذه الرسالة مباشرة*`.trim(), m);
};

handler.before = async (m, { conn }) => {
    if (!mathGames.has(m.sender)) return;
    const data = mathGames.get(m.sender);
    
    // التحقق أن المستخدم يجاوب على رسالة اللعبة
    if (isNaN(m.text)) return; 

    const { result, exp, intentos, timeout } = data;
    const entrada = m.text.trim();
    let correcta = false;

    if (String(result).includes('.') || entrada.includes('.')) {
        correcta = parseFloat(entrada).toFixed(2) === result.toFixed(2);
    } else {
        correcta = parseInt(entrada) === result;
    }

    if (correcta) {
        clearTimeout(timeout);
        mathGames.delete(m.sender);
        
        let user = global.db.data.users[m.sender];
        user.exp = (user.exp || 0) + exp; 

        return conn.reply(m.chat, `✅ *إجابة صحيحة!*\nربحت: *${exp} XP*`, m);
    } else {
        data.intentos--;
        if (data.intentos <= 0) {
            clearTimeout(timeout);
            mathGames.delete(m.sender);
            return conn.reply(m.chat, `❌ *انتهت المحاولات!*\nالإجابة الصحيحة: *${result}*`, m);
        } else {
            return conn.reply(m.chat, `❌ *إجابة خاطئة!*\nتبقى لديك *${data.intentos}* محاولات.`, m);
        }
    }
};

handler.help = ['math'];
handler.tags = ['game'];
handler.command = ['math', 'رياضيات', 'حساب'];

export default handler;
