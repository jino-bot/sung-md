import db from '../lib/database.js'

let handler = m => m

handler.before = async function (m, { conn, isAdmin, isBotAdmin }) {
    if (!m.isGroup) return false

    let chat = global.db.data.chats[m.chat]
    if (!chat || !chat.antifake) return false
    if (!isBotAdmin) return false
    if (isAdmin) return false // لا يطرد الأدمن

    // أكواد الدول الممنوعة
    const blockedCountries = [
        '91',  // الهند
        '92',  // باكستان
        '86',  // الصين
        '82',  // كوريا
        '84',  // فيتنام
        '39',  // إيطاليا
        '880', // بنغلاديش
        '62',  // إندونيسيا
        '63'   // الفلبين
    ]

    // استخراج الرقم بدون @s.whatsapp.net
    let senderNumber = m.sender.split('@')[0]

    // التحقق هل الرقم يبدأ بأحد أكواد الدول
    let isFake = blockedCountries.some(code =>
        senderNumber.startsWith(code)
    )

    if (!isFake) return false

    // التأكد من وجود المستخدم في قاعدة البيانات
    if (!global.db.data.users[m.sender]) {
        global.db.data.users[m.sender] = {}
    }

    // حظر المستخدم
    global.db.data.users[m.sender].block = true

    // طرد المستخدم
    await conn.groupParticipantsUpdate(
        m.chat,
        [m.sender],
        'remove'
    )

    return true
}

export default handler