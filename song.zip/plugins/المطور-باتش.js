import fs from 'fs-extra'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

let handler = async (m, { args, isOwner }) => {
  if (!isOwner) {
    return m.reply('⛔ هذا الأمر مخصص للمطور فقط')
  }

  const pluginsDir = __dirname
  const sub = args[0]?.toLowerCase()
  const target = args[1]

  /* ===== المساعدة ===== */
  if (!sub) {
    return m.reply(
`📌 أوامر الباتش:
.باتش عرض
.باتش عرض <اسم>
.باتش اضف <اسم>
.باتش حذف <اسم>`
    )
  }

  /* ===== عرض جميع الملفات ===== */
  if (sub === 'عرض' && !target) {
    const files = fs.readdirSync(pluginsDir).filter(f => f.endsWith('.js'))
    const list = files.map((f, i) => `┃ ${i + 1}- ${f}`).join('\n')
    return m.reply(
`┏━⬦ قائمة البلجنات:
${list}
┃
┗━⬦ المجموع: ${files.length} ملفات`
    )
  }

  if (!target) {
    return m.reply('❌ حدد اسم الملف.')
  }

  const fileName = target.endsWith('.js') ? target : `${target}.js`
  const fullPath = path.join(pluginsDir, fileName)

  /* ===== عرض ملف ===== */
  if (sub === 'عرض') {
    if (!fs.existsSync(fullPath)) {
      return m.reply(`❌ الملف غير موجود: ${fileName}`)
    }
    return m.reply(`📂 ${fileName}:\n\n${fs.readFileSync(fullPath, 'utf8')}`)
  }

  /* ===== حذف ملف ===== */
  if (sub === 'حذف') {
    if (!fs.existsSync(fullPath)) {
      return m.reply(`❌ الملف غير موجود: ${fileName}`)
    }
    fs.unlinkSync(fullPath)
    return m.reply(`✅ تم حذف الملف: ${fileName}`)
  }

  /* ===== إضافة / استبدال ===== */
  if (sub === 'اضف') {
    const code = m.quoted?.text || ''

    if (!code.trim()) {
      return m.reply(
        '❌ لم أجد كود في الرسالة المقتبسة.\n📌 رد على رسالة الكود.'
      )
    }

    fs.writeFileSync(fullPath, `${code.trim()}\n`, 'utf8')
    return m.reply(`✅ تم حفظ الكود في: ${fileName}`)
  }

  /* ===== أمر غير معروف ===== */
  return m.reply('❌ أمر غير معروف.')
}

/* ===== EMS ===== */
handler.help = ['باتش']
handler.tags = ['owner']
handler.command = /^باتش$/i
handler.owner = true

export default handler