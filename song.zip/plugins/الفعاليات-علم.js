import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

const timeout = 60000;
const reward = 150; // نقاط

let handler = async (m, { conn, command }) => {
    conn.monte = conn.monte || {};
    let id = m.chat;

    if (command.startsWith('اجاب_')) {
        let monte = conn.monte[id];

        if (!monte) {
            return conn.reply(m.chat, '*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*لا توجد لعبة نشطة حالياً ⚠️*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*', m);
        }

        let selectedAnswerIndex = parseInt(command.split('_')[1]);
        let selectedAnswer = monte.options[selectedAnswerIndex - 1];
        let isCorrect = monte.correctAnswer === selectedAnswer;
     
            if (isCorrect) {
        let db = global.db.data;

// تأكد من وجود المستخدم
if (!db.users[m.sender]) {
    db.users[m.sender] = {
        bank: 0,
        exp: 0,
        coin: 0,
        level: 0
    };
}

// إضافة 150 نقطة
db.users[m.sender].bank = (db.users[m.sender].bank || 0) + reward;

// حفظ فعلي
global.db.data = db;

    clearTimeout(monte.timer);  
        delete conn.monte[id];

            const interactiveMessage = {
                body: { text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*🎉 إجابتك صحيحة مبروك 🎉*\n*🏦┊الجائزة┊⇇ 150 نقطة*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*` },
                footer: { text: '𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
                nativeFlowMessage: {
                    buttons: [{ name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🔄 لعبة جديدة', id: '.علم' }) }]
                }
            };
            return conn.relayMessage(m.chat, { viewOnceMessage: { message: { interactiveMessage } } }, {});

        } else {
            monte.attempts -= 1;
            if (monte.attempts > 0) {
                return conn.reply(m.chat, `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*إجابتك خاطئة ❌*\n*لديك محاولة واحدة أخرى ⏳*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`, m);
            } else {
                const correctAnswer = monte.correctAnswer;
                clearTimeout(monte.timer);
                delete conn.monte[id];

                const interactiveMessage = {
                    body: { text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*إجابتك خاطئة ❌*\n*إنتهت المحاولات المتاحة*\n*✅┊الإجابة هي┊⇇ ${correctAnswer}*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*` },
                    footer: { text: '𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
                    nativeFlowMessage: {
                        buttons: [{ name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🔄 حاول مرة أخرى', id: '.علم' }) }]
                    }
                };
                return conn.relayMessage(m.chat, { viewOnceMessage: { message: { interactiveMessage } } }, {});
            }
        }
    } else {
        // بدء لعبة جديدة
        if (conn.monte[id]) {
            return conn.reply(m.chat, '*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*هناك لعبة جارية بالفعل! أجب أولاً ⚠️*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*', m);
        }

        try {
            const response = await fetch('https://raw.githubusercontent.com/ze819/game/master/src/game.js/luffy1.json');
            const monteData = await response.json();
            const monteItem = monteData[Math.floor(Math.random() * monteData.length)];
            const { img, name } = monteItem;

            let options = [name];
            while (options.length < 4) {
                let randomItem = monteData[Math.floor(Math.random() * monteData.length)].name;
                if (!options.includes(randomItem)) options.push(randomItem);
            }
            options.sort(() => Math.random() - 0.5);

            const media = await prepareWAMessageMedia({ image: { url: img } }, { upload: conn.waUploadToServer });

            const interactiveMessage = {
                body: {
                    text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*✧ \`خمن علم الدولة\` ✧*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n\n*❏- 🏳️ الـعـلــم : ⟦ اختار اسم الدولة الصحيحة لهذا العلم الظاهر في الصورة⟧*\n\n*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*\n*❏- ⏱️ الـوقـت: ⟦60 ثانـية⟧*\n*❏- 🏦 الجائزة: ⟦150 نقطة⟧*\n*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*\n> اختار اسم الدولة قبل انتهاء الوقت\n> لديك محاولتين فقط\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`,
                },
                footer: { text: '𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
                header: {
                    hasMediaAttachment: true,
                    imageMessage: media.imageMessage,
                },
                nativeFlowMessage: {
                    buttons: options.map((option, index) => ({
                        name: 'quick_reply',
                        buttonParamsJson: JSON.stringify({
                            display_text: `┊${index + 1}┊⇇${option}`,
                            id: `.اجاب_${index + 1}`
                        })
                    })),
                },
            };

            let msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: { message: { interactiveMessage } },
            }, { userJid: conn.user.jid, quoted: m });

            await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

            conn.monte[id] = {
                correctAnswer: name,
                options: options,
                attempts: 2,
                timer: setTimeout(async () => {
                    if (conn.monte[id]) {
                        await conn.reply(m.chat, `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*⌛ انتهى الوقت المسموح*\n*✅ الإجابة الصحيحة هي: ${name}*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`, m);
                        delete conn.monte[id];
                    }
                }, timeout)
            };

        } catch (e) {
            console.error(e);
            conn.reply(m.chat, '❌ حدث خطأ أثناء تحميل اللعبة، حاول لاحقاً.', m);
        }
    }
};

handler.help = ['علم'];
handler.tags = ['اعلام_الدول'];
handler.command = /^(علم|اعلام|اجاب_\d+)$/i;

export default handler;
