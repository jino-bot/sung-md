import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

let handler = async (m, { conn, usedPrefix }) => {
    try {
        // إرسال تفاعل 👤
        await conn.sendMessage(m.chat, { react: { text: "👤", key: m.key } });

        let name = await conn.getName(m.sender)
        
        const messageText = `*مـــرحبــــاً بـــكـ/ﻲ يـا ❪${name}❫ في قسم الشخصيات*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *شرح القسم: يقدم لك محاكاة للدردشة مع شخصياتك المفضلة بالذكاء الاصطناعي*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *｢👤┊قسم الشخصيات AI┊👤｣*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
┊👑┊: \`${usedPrefix}آرثر\`
> الملك آرثر يجيب عليك بحكمته وشجاعته.
┊👁️‍🗨️┊: \`${usedPrefix}ايتاشي\`
> إيتاشي أوتشيها يجيب عليك بحكمته وغموضه.
┊🎭┊: \`${usedPrefix}اوبيتو\`
> أوبيتو أوتشيها يجيب عليك بقوته الداخلية.
┊🔥┊: \`${usedPrefix}ايرين\`
> إرين ييغر يجيب عليك بحماسه وعزيمته.
┊🦸‍♂️┊: \`${usedPrefix}سوبرمان\`
> سوبرمان يجيب عليك بروحه البطولية.
┊🐉┊: \`${usedPrefix}سونغ\`
> سونغ جين وو، ملك الظلال، بأسلوبه الغامض.
┊👊┊: \`${usedPrefix}غوكو\`
> غوكو يجيب عليك بروحه المرحة وقوته.
┊⚡┊: \`${usedPrefix}كاكاشي\`
> كاكاشي هاتاكي النينجا الناسخ.
┊⚡┊: \`${usedPrefix}كيلوا\`
> كيلوا زولديك بذكائه الساخر المعهود.
┊🌸┊: \`${usedPrefix}هيناتا\`
> هيناتا هيوغا تجيب عليك بخجلها ودفئها.
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

        // تحديد المسار بناءً على هيكلة مشروعك (نعود لمجلد src ثم media)
        const imagePath = path.join(__dirname, '../src/media/Menu4.jpg')

        if (fs.existsSync(imagePath)) {
            await conn.sendMessage(m.chat, {
                image: fs.readFileSync(imagePath),
                caption: messageText
            }, { quoted: m })
        } else {
            // في حال لم يجد الصورة في المسار المحدد، يرسل نص فقط أو رابط احتياطي
            await conn.sendMessage(m.chat, { text: messageText }, { quoted: m })
            console.log('الصورة غير موجودة في: ' + imagePath)
        }

    } catch (err) {
        console.error('❌ Error in Characters Menu:', err)
    }
}

handler.help = ['الشخصيات']
handler.tags = ['main']
handler.command = ['قسم1'] 

export default handler
