import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

let handler = async (m, { conn, usedPrefix }) => {
    try {
        // إرسال تفاعل 🤖
        await conn.sendMessage(m.chat, { react: { text: "🤖", key: m.key } });

        let name = await conn.getName(m.sender)
        
        const messageText = `*مـــرحبــــاً بـــكـ/ﻲ يـا ❪${name}❫ في قسم معلومات البوت*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *شرح القسم: معلومات تقنية عن حالة البوت، سرعته، وطرق التواصل مع المطور*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *｢🤖┊قسم مـعـلـومـات الـنـظـام┊🤖｣*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
┊📩┊: \`${usedPrefix}ابلاغ\`
> إرسال بلاغ أو اقتراح مباشرة للمطور.
┊📜┊: \`${usedPrefix}اشتراك\`
> شروط دخول البوت للمجموعات ونظام الاشتراك.
┊⚡┊: \`${usedPrefix}السرعة\`
> فحص البينغ (Ping) ومدة تشغيل النظام.
┊📜┊: \`${usedPrefix}اوامر\`
> عرض قائمة بجميع أوامر البوت المتاحة.
┊👑┊: \`${usedPrefix}مساعدة\`
> التحدث مع مساعد سونغ جين وو الذكي.
┊🆔┊: \`${usedPrefix}تعريفي\`
> عرض رقم التعريفي المميز لرقمك.
┊🌟┊: \`${usedPrefix}تقييم\`
> قيم أداء البوت بالنجوم لتحسين الخدمة.
┊👨‍💻┊: \`${usedPrefix}المطور\`
> معلومات التواصل مع المطور وروابط الدعم.
┊🚀┊: \`${usedPrefix}احصائيات\`
> عرض معلومات احصائيات البوت.
┊🗂┊: \`${usedPrefix}اسكريبت\`
> الحصول على اسكريبت البوت مجانا عند الوصول للمستوى 100.
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

    const imagePath = path.join(__dirname, '../src/media/Menu4.jpg')

    if (fs.existsSync(imagePath)) {
        await conn.sendMessage(m.chat, { 
            image: { url: imagePath }, 
            caption: messageText 
        }, { quoted: m })
    } else {
        await conn.sendMessage(m.chat, { text: messageText }, { quoted: m })
    }

    } catch (err) {
        console.error('❌ Error in Bot Info Menu:', err)
    }
}

handler.help = ['البوت']
handler.tags = ['main']
handler.command = /^(قسم21)$/i 

export default handler
