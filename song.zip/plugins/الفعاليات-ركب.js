import fs from 'fs';
import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

let timeout = 30000; // 30 ثانية لتناسب سرعة فعاليات الكتابة
let poin = 150;

let handler = async (m, { conn, usedPrefix }) => {
    conn.tekateki = conn.tekateki ? conn.tekateki : {};
    let id = m.chat;

    if (id in conn.tekateki) {
        return conn.reply(m.chat, '*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*مزال هناك كلمة لم يتم تركيبها بعد! ⚠️*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*', conn.tekateki[id][0]);
    }

    // قراءة ملف تركيب الكلمات
    let filePath = `./src/game/unmiku.json`;
    if (!fs.existsSync(filePath)) return conn.reply(m.chat, '❌ ملف الكلمات غير موجود!', m);

    let tekateki = JSON.parse(fs.readFileSync(filePath));
    let json = tekateki[Math.floor(Math.random() * tekateki.length)];
    
    const imageUrl = 'https://files.catbox.moe/jnnsb1.jpg';
    const media = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: conn.waUploadToServer });

    let caption = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*✧ \`فعالية تركيب الكلمات\` ✧*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

*❏- 🧩 الكلمة المبعثرة : ⟦ ${json.question} ⟧*

*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*❏- ⏱️ الـوقـت: ⟦30 ثانـية⟧*
*❏- 🏆 الجائزة: ⟦${poin} xp⟧*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
> أعد ترتيب الحروف لتكوين الكلمة الصحيحة
> اكتب الإجابة مع الرد على هذه الرسالة
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`.trim();

    const interactiveMessage = {
        body: { text: caption },
        footer: { text: '𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
        header: {
            hasMediaAttachment: true,
            imageMessage: media.imageMessage,
        },
        nativeFlowMessage: {
            buttons: [] // لا يوجد أزرار لأنها تعتمد على سرعة الكتابة والرد
        },
    };

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: { message: { interactiveMessage } },
    }, { userJid: conn.user.jid, quoted: m });

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    conn.tekateki[id] = [
        msg,
        json, 
        poin,
        setTimeout(async () => {
            if (conn.tekateki[id]) {
                await conn.reply(m.chat, `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*⌛ انتهى الوقت*\n*✅ الكلمة الصحيحة هي: ${json.response}*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`, conn.tekateki[id][0]);
                delete conn.tekateki[id];
            }
        }, timeout)
    ];
};

handler.help = ['ركب'];
handler.tags = ['game'];
handler.command = /^(ركب|تركيب)$/i;

export default handler;
