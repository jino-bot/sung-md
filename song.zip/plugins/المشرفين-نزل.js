let handler = async (m, { conn, usedPrefix, text, isAdmin, isOwner }) => {
if (!isAdmin && !isOwner) return conn.reply(m.chat, '*[❗] هذا الأمر مخصص للمشرفين فقط!*', m)

let number
if (isNaN(text) && !text.match(/@/g)) {
    // لم يتم إدخال شيء
} else if (isNaN(text)) {
    number = text.split`@`[1]
} else if (!isNaN(text)) {
    number = text
}

if (!text && !m.quoted) return conn.reply(m.chat, `*[❗] الاستخدام الصحيح:*\n\n*┯┷*\n*┠≽ ${usedPrefix}خفض @منشن*\n*┠≽ ${usedPrefix}خفض (بالرد على رسالة)*\n*┷┯*`, m)
if (number && (number.length > 13 || (number.length < 11 && number.length > 0))) return conn.reply(m.chat, `*[ ⚠️ ] الرقم غير صحيح، الرجاء إدخال رقم صالح!*`, m)

try {
let user
if (m.quoted) {
    user = m.quoted.sender
} else if (text) {
    user = number.replace(/\s+/g, '') + '@s.whatsapp.net'
}

if (!user) return conn.reply(m.chat, `*[❗] لم يتم تحديد المستخدم!*`, m)

await conn.groupParticipantsUpdate(m.chat, [user], 'demote')
conn.reply(m.chat, `✅ تم تنزيل المستخدم من الإشراف بنجاح!`, m)

} catch (e) {
console.error(e)
conn.reply(m.chat, `*[ ❌ ] حدث خطأ، تأكد من أن المستخدم مشرف بالفعل!*`, m)
}}

handler.help = ['خفض @منشن', 'خفض (بالرد)'].map(v => v)
handler.tags = ['group']
handler.command = /^(خفض|تنزيل|انزل)$/i
handler.group = true
handler.botAdmin = true

export default handler
