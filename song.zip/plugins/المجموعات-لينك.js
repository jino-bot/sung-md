let handler = async (m, { conn, isAdmin, isOwner, isBotAdmin }) => {
  // الصلاحيات
  if (!isAdmin && !isOwner)
    return m.reply('*[❗] هذا الأمر مخصص للمشرفين والمطور فقط!*')

  if (!isBotAdmin)
    return m.reply('*[❗] يجب أن أكون مشرفاً لإعادة تعيين رابط المجموعة!*')

  try {
    // إعادة تعيين الرابط
    await conn.groupRevokeInvite(m.chat)

    // جلب الرابط الجديد
    let code = await conn.groupInviteCode(m.chat)
    let link = `https://chat.whatsapp.com/${code}`
    let groupName = (await conn.groupMetadata(m.chat)).subject

    let teks = `
*❐═━━━═╊⊰♻️⊱╉═━━━═❐*
✧ \`إعادة تعيين رابط المجموعة\`
*❐═━━━═╊⊰♻️⊱╉═━━━═❐*
💠 *المجموعة:* 『 ${groupName} 』
🔄 *تم إلغاء الرابط القديم بنجاح*
🌐 *الرابط الجديد:* 
${link}
*❐═━━━═╊⊰♻️⊱╉═━━━═❐*
> *تنبيه:* أي رابط قديم لم يعد صالحًا.
*❐═━━━═╊⊰♻️⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`.trim()

    await conn.sendMessage(
      m.chat,
      {
        text: teks,
        contextInfo: {
          ...global.rcanal.contextInfo,
          externalAdReply: {
            title: '𝐒𝐎𝐍Γ 𝐔𝐏𝐃𝐀𝐓𝐄 ꒰🐉⃝⃕꒱',
            body: groupName,
            thumbnailUrl: 'https://files.catbox.moe/zd89n4.jpg',
            sourceUrl: link,
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      },
      { quoted: m }
    )

  } catch (e) {
    console.error(e)
    m.reply('*[❌] حدث خطأ أثناء إعادة تعيين الرابط، تأكد من صلاحياتي.*')
  }
}

handler.help = ['لينك_ريستر']
handler.tags = ['group']
handler.command = /^(لينك_ريستر|ريستر_لينك|resetlink)$/i
handler.group = true
handler.botAdmin = true

export default handler
