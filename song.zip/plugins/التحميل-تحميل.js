import { exec } from 'child_process'
import fs from 'fs'
import path from 'path'
import { promisify } from 'util'

const execAsync = promisify(exec)

let handler = async (m, { conn, args }) => {
  const chatId = m.chat

  if (!args || args.length < 2) {
    return conn.sendMessage(chatId, {
      text: `❌ *| الصيغة ناقصة!*\n\nاستخدم:\n\`.تحميل [فيديو|صوت] [الرابط]\``
    }, { quoted: m })
  }

  const format = args[0].toLowerCase()
  const url = args[1].trim()

  if (!url.startsWith('http')) {
    return conn.sendMessage(chatId, {
      text: `❌ *| الرابط غير صالح!*\n\nأرسل رابط مباشر من أحد المصادر المدعومة.`
    }, { quoted: m })
  }

  const detectSource = url => {
    if (url.includes('tiktok.com')) return 'TikTok'
    if (url.includes('facebook.com')) return 'Facebook'
    if (url.includes('instagram.com')) return 'Instagram'
    if (url.includes('youtube.com') || url.includes('youtu.be')) return 'YouTube'
    return 'مصدر غير معروف'
  }

  const source = detectSource(url)
  const timestamp = Date.now()
  const tempDir = './temp'
  if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true })

  const videoPath = path.join(tempDir, `${timestamp}.mp4`)
  const audioPath = path.join(tempDir, `${timestamp}.mp3`)

  await conn.sendMessage(chatId, {
    text: `⏳ *| جاري تحميل الملف...*\n━━━━━━━━━━━━━━\n🎬 النوع: *${format}*\n📱 المصدر: ${source}`
  }, { quoted: m })

  const formatBytes = bytes => {
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    if (!bytes) return '0 Byte'
    const i = Math.floor(Math.log(bytes) / Math.log(1024))
    return (bytes / Math.pow(1024, i)).toFixed(1) + sizes[i]
  }

  const getMediaMeta = async filePath => {
    try {
      const { stdout } = await execAsync(
        `ffprobe -v quiet -print_format json -show_format -show_streams "${filePath}"`
      )
      const data = JSON.parse(stdout)
      const durationSec = Math.floor(Number(data.format.duration || 0))
      const minutes = Math.floor(durationSec / 60)
      const seconds = durationSec % 60
      return {
        duration: `${minutes.toString().padStart(2, '0')}:${seconds
          .toString()
          .padStart(2, '0')}`,
        size: formatBytes(Number(data.format.size))
      }
    } catch {
      return { duration: 'غير معروف', size: 'غير معروف' }
    }
  }

  const cleanup = file => {
    try {
      if (fs.existsSync(file)) fs.unlinkSync(file)
    } catch {}
  }

  const errorMsg = type =>
    `❌ *| فشل تحميل ${type}!*\n📌 تأكد أن الرابط عام أو صالح.`

  // 🎬 فيديو
  if (format === 'فيديو') {
    exec(`yt-dlp -f mp4 -o "${videoPath}" "${url}"`, async err => {
      if (err || !fs.existsSync(videoPath)) {
        return conn.sendMessage(chatId, { text: errorMsg('الفيديو') }, { quoted: m })
      }

      const { duration, size } = await getMediaMeta(videoPath)

      try {
        await conn.sendMessage(chatId, {
          video: fs.readFileSync(videoPath),
          caption:
            `┏━━━✦ 『 📥 تم التحميل بنجاح 』✦━━━┓\n\n` +
            `🎬 النوع: فيديو\n` +
            `📱 المصدر: ${source}\n` +
            `⏱️ المدة: ${duration}\n` +
            `💾 الحجم: ${size}\n` +
            `🤖 بواسطة: سونغ\n` +
            `┗━━━━━━━━━━━━━━━━━━━━┛`
        }, { quoted: m })
      } finally {
        cleanup(videoPath)
      }
    })
  }

  // 🎧 صوت
  else if (format === 'صوت') {
    exec(`yt-dlp -x --audio-format mp3 -o "${audioPath}" "${url}"`, async err => {
      if (err || !fs.existsSync(audioPath)) {
        return conn.sendMessage(chatId, { text: errorMsg('الصوت') }, { quoted: m })
      }

      const { duration, size } = await getMediaMeta(audioPath)

      try {
        await conn.sendMessage(chatId, {
          audio: fs.readFileSync(audioPath),
          mimetype: 'audio/mpeg',
          caption:
            `┏━━━✦ 『 🎧 تم التحميل بنجاح 』✦━━━┓\n\n` +
            `🔊 النوع: صوت\n` +
            `📱 المصدر: ${source}\n` +
            `⏱️ المدة: ${duration}\n` +
            `💾 الحجم: ${size}\n` +
            `🤖 بواسطة: سونغ\n` +
            `┗━━━━━━━━━━━━━━━━━━━━┛`
        }, { quoted: m })
      } finally {
        cleanup(audioPath)
      }
    })
  }

  else {
    return conn.sendMessage(chatId, {
      text: `❗ *| النوع غير معروف!*\nاختر بين: "فيديو" أو "صوت"`
    }, { quoted: m })
  }
}

handler.help = ['تحميل <فيديو|صوت> <رابط>']
handler.tags = ['downloader']
handler.command = ['تحميل']

export default handler