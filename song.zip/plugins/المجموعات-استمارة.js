let handler = async (m, { conn }) => {
  try {
    const jid = m.chat

    // جلب بيانات المجموعة
    const groupMetadata = await conn.groupMetadata(jid)
    const participants = groupMetadata.participants
    const mentions = participants.map(p => p.id)

    const caption = `
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
      ✧ \`مـعـلـومـات الـدخـول\`
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*

*❏- اللـقــ🎗ـب  ⟦ ⟧*  
*❏- مـن أنـمـيـ🎞️  ⟦ ⟧*  
*❏- الـجنسـ⚧️  ⟦ ⟧*  
*❏- مـن طـرفـ📨  ⟦ ⟧*  

*❏- صـورة لـلـلـقـبـ🖼️↓*

*⟐━───━「⚖️」━───━⟐*  
> يُرجى الالتزام بقوانين النقابة:  
• يُمنع افتعال المشاكل  
• يُمنع الاحتكاك بالجنس الآخر  
• يُمنع السب والشتم  
*⟐━───━「🚫」━───━⟐*

*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
    `.trim()

    await conn.sendMessage(
      jid,
      {
        text: caption,
        contextInfo: {
          mentionedJid: mentions // منشن مخفي لكل الأعضاء
        }
      },
      { quoted: m }
    )

  } catch (e) {
    console.error('❌ خطأ في أمر الاستمارة:', e)
    await m.reply('❌ حدث خطأ أثناء تنفيذ الأمر.')
  }
}

handler.help = ['استمارة']
handler.tags = ['group']
handler.command = ['استمارة']
handler.group = true
handler.admin = true

export default handler