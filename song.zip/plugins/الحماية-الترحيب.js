let handler = async (m, { conn, args, usedPrefix, command }) => {
    // التأكد من وجود سجل للمجموعة
    let chat = global.db.data.chats[m.chat]
    if (!chat) return

    // عرض الحالة
    if (!args[0]) {
        let status = chat.welcome ? 'مفعل ✅' : 'معطل ❌'
        return conn.reply(
            m.chat,
            `*👋 حالة الترحيب:* ${status}\n\n` +
            `*الاستخدام:*\n` +
            `• ${usedPrefix + command} on (تفعيل)\n` +
            `• ${usedPrefix + command} off (تعطيل)`,
            m
        )
    }

    // تفعيل الترحيب
    if (args[0] === 'on') {
        if (chat.welcome) return m.reply('⚠️ الترحيب مفعّل بالفعل في هذه المجموعة.')
        chat.welcome = true
        return m.reply('✅ تم تفعيل الترحيب بنجاح.')
    }

    // تعطيل الترحيب
    if (args[0] === 'off') {
        if (!chat.welcome) return m.reply('⚠️ الترحيب معطّل بالفعل في هذه المجموعة.')
        chat.welcome = false
        return m.reply('❌ تم تعطيل الترحيب بنجاح.')
    }

    // إدخال غير صحيح
    return m.reply(
        `❌ أمر غير صحيح\n\n` +
        `*استخدم:*\n` +
        `• ${usedPrefix + command} on\n` +
        `• ${usedPrefix + command} off`
    )
}

// تعريفات الأمر
handler.help = ['الترحيب']
handler.tags = ['group']
handler.command = ['الترحيب', 'welcome']

// القيود
handler.group = true
handler.admin = true
handler.botAdmin = false

export default handler