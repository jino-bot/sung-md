import { exec } from 'child_process'
import fs from 'fs'
import path from 'path'

let handler = async (m, { conn, args }) => {
  const jid = m.chat

  if (!args || args.length === 0) {
    return conn.sendMessage(jid, {
      text: '🎵 اكتب اسم الأغنية بالإنجليزية لتحميلها.\n\nمثال:\n.اغنية despacito'
    }, { quoted: m })
  }

  const query = args.join(' ').trim()
  const tempDir = './temp'
  if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true })

  const audioPath = path.join(tempDir, `song_${Date.now()}.mp3`)

  // 🎶 تفاعل عند استقبال الأمر
  try {
    await conn.sendMessage(jid, { react: { text: '🎶', key: m.key } })
  } catch {}

  // yt-dlp: بحث + تحميل أول نتيجة
  const ytCommand = `yt-dlp -x --audio-format mp3 "ytsearch1:${query}" -o "${audioPath}"`

  exec(ytCommand, async (err, stdout, stderr) => {
    if (err || !fs.existsSync(audioPath)) {
      console.error('[ERROR] تحميل الأغنية:', err?.message || stderr || stdout)

      try {
        await conn.sendMessage(jid, { react: { text: '❌', key: m.key } })
      } catch {}

      return conn.sendMessage(jid, {
        text: `❌ *| فشل تحميل الأغنية "${query}"*`
      }, { quoted: m })
    }

    // ✅ نجاح
    try {
      await conn.sendMessage(jid, { react: { text: '✅', key: m.key } })
    } catch {}

    const caption = `
*❐═━━━═╊⊰🎶⊱╉═━━━═❐*

\`🎵 النوع:\` *أغنية*
\`📝 البحث عن:\` *${query}*
\`📥 المصدر:\` *YouTube*
\`🤖 بواسطة:\` *سونغ*

*❐═━━━═╊⊰🎶⊱╉═━━━═❐*
`.trim()

    try {
      const audioData = fs.readFileSync(audioPath)

      await conn.sendMessage(jid, {
        audio: audioData,
        mimetype: 'audio/mpeg',
        caption,
        contextInfo: {
          externalAdReply: {
            thumbnailUrl: 'https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o'
          }
        }
      }, { quoted: m })
    } catch (sendErr) {
      console.error('[ERROR] إرسال الأغنية:', sendErr?.message || sendErr)

      try {
        await conn.sendMessage(jid, { react: { text: '❌', key: m.key } })
      } catch {}

      await conn.sendMessage(jid, {
        text: `⚠️ حدث خطأ أثناء إرسال الأغنية "${query}".`
      }, { quoted: m })
    } finally {
      try {
        if (fs.existsSync(audioPath)) fs.unlinkSync(audioPath)
      } catch {}
    }
  })
}

handler.help = ['اغنية <اسم>']
handler.tags = ['downloader']
handler.command = ['اغنية']

export default handler