import Jimp from 'jimp'

const imageCache = new Map()

const animeStyles = [
  { 
    name: 'أنمي كلاسيك (90s)', 
    process: img => img.brightness(0.1).contrast(0.2).posterize(15).color([{ apply: 'saturate', params: [20] }]) 
  },
  { 
    name: 'أنمي حديث (مشرق)', 
    process: img => img.brightness(0.15).contrast(0.1).color([{ apply: 'mix', params: ['#88ccff', 10] }]).convolute([[-1, -1, -1], [-1, 9, -1], [-1, -1, -1]]) 
  },
  { 
    name: 'مانجا (أبيض وأسود)', 
    process: img => img.grayscale().contrast(0.5).posterize(2) 
  },
  { 
    name: 'لوحة زيتية (Ghibli)', 
    process: img => img.blur(1).color([{ apply: 'saturate', params: [40] }]).posterize(10) 
  }
]

const handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ''
    const userId = m.sender

    // 1. عرض القائمة
    if (!text && mime.startsWith('image')) {
      const imgBuffer = await q.download()
      if (!imgBuffer) return conn.reply(m.chat, '❌ فشل تحميل الصورة', m)
      
      imageCache.set(userId, imgBuffer)

      const buttons = animeStyles.map((style, i) => ({
        buttonId: `${usedPrefix + command} ${i + 1}`,
        buttonText: { displayText: style.name },
        type: 1
      }))

      return conn.sendMessage(
        m.chat,
        {
          image: imgBuffer,
          caption: '✨ اختر استايل الأنمي الذي تريد تطبيقه:',
          buttons,
          headerType: 4
        },
        { quoted: m }
      )
    }

    // 2. تنفيذ الفلتر
    if (text) {
      const index = parseInt(text.trim()) - 1
      const selectedStyle = animeStyles[index]

      if (!selectedStyle) return conn.reply(m.chat, '❌ خيار غير صحيح', m)

      let imgBuffer = imageCache.get(userId)
      if (!imgBuffer && mime.startsWith('image')) imgBuffer = await q.download()

      if (!imgBuffer) return conn.reply(m.chat, '❌ ارسل الصورة أولاً', m)

      await conn.reply(m.chat, `⏳ جاري تحويل الصورة إلى ${selectedStyle.name}...`, m)

      const image = await Jimp.read(imgBuffer)
      
      // تطبيق الفلتر الخاص بالاستايل
      await selectedStyle.process(image)

      const out = await image.getBufferAsync(Jimp.MIME_JPEG)

      await conn.sendFile(
        m.chat,
        out,
        'anime.jpg',
        `✅ تم تطبيق استايل: ${selectedStyle.name}\n\n*ملاحظة:* هذا الفلتر يحاكي ألوان الأنمي برمجياً.`,
        m
      )
      return
    }

    conn.reply(m.chat, '❌ رد على صورة واكتب .انمي_استايل', m)

  } catch (e) {
    console.error(e)
    conn.reply(m.chat, '⚠️ حدث خطأ أثناء المعالجة', m)
  }
}

handler.help = ['انمي_استايل']
handler.tags = ['tools']
handler.command = /^(انمي_استايل|أنمي_استايل)$/i

export default handler
