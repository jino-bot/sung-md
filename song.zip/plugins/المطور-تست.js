let handler = async (m, { conn }) => {

  const text = `
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
*┊    🚀『 𝐁𝐎𝐓 - 𝐉𝐈𝐍𝐖𝐎𝐎 』🚀 ┊*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*

*『 👨‍💻 | معلومات البوت 』*
*╭─────────────⟢* 
*│ 🤖 الاسم:* 𝐒𝐎𝐍𝐆
*│ ⚙️ النسخة:* v4
*│ 👤 المطور:* +23595456638
*╰─────────────⟢*

*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
✅ *𝐉𝐈𝐍𝐖𝐎𝐎 𝐁𝐎𝐓 ⚫️*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
`

  await conn.sendMessage(m.chat, { text }, { quoted: m })
}

handler.command = ['تست', 'test']
handler.category = 'info'
export default handler