import fs from 'fs';
import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

let timeout = 30000; // 30 ثانية
let poin = 150;

let handler = async (m, { conn, usedPrefix }) => {
    conn.tekateki = conn.tekateki ? conn.tekateki : {};
    let id = m.chat;

    if (id in conn.tekateki) {
        return conn.reply(m.chat, '*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*مزال هناك كلمة لم يتم تفكيكها بعد! ⚠️*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*', conn.tekateki[id][0]);
    }

    let tekateki = JSON.parse(fs.readFileSync(`./src/game/miku.json`));
    let json = tekateki[Math.floor(Math.random() * tekateki.length)];
    
    const imageUrl = 'https://files.catbox.moe/jnnsb1.jpg';
    const media = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: conn.waUploadToServer });

    let caption = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*✧ \`فعالية تفكيك الكلمات\` ✧*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

*❏- 🧩 الكلمة : ⟦ ${json.question} ⟧*

*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*❏- ⏱️ الـوقـت: ⟦30 ثانـية⟧*
*❏- 🏆 الجائزة: ⟦${poin} xp⟧*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
> أعد كتابة الكلمة مفككة بمسافات قبل انتهاء الوقت
> اكتب الكلمة مع الرد على هذه الرسالة
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`.trim();

    const interactiveMessage = {
        body: { text: caption },
        footer: { text: '𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
        header: {
            hasMediaAttachment: true,
            imageMessage: media.imageMessage,
        },
        nativeFlowMessage: {
            buttons: [] // لا يوجد أزرار لأن الإجابة كتابية
        },
    };

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: { message: { interactiveMessage } },
    }, { userJid: conn.user.jid, quoted: m });

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    conn.tekateki[id] = [
        msg,
        json, 
        poin,
        setTimeout(async () => {
            if (conn.tekateki[id]) {
                await conn.reply(m.chat, `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*⌛ انتهى الوقت*\n*✅ الإجابة الصحيحة هي: ${json.response}*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`, conn.tekateki[id][0]);
                delete conn.tekateki[id];
            }
        }, timeout)
    ];
};

handler.help = ['فكك'];
handler.tags = ['game'];
handler.command = /^(فكك)$/i;

export default handler;
