let handler = async (m, { conn, args }) => {
  let user = global.db.data.users[m.sender]
  if (!user) user = global.db.data.users[m.sender] = {}

  user.bank = user.bank || 0
  user.coin = user.coin || 0

  let points = parseInt(args[0])
  if (!points || points < 150)
    return conn.reply(m.chat, '❌ أدخل عدد نقاط صحيح (150 نقطة على الأقل)', m)

  if (points % 150 !== 0)
    return conn.reply(m.chat, '❌ يجب أن يكون العدد من مضاعفات 150', m)

  let neededCoins = points / 150

  if (user.coin < neededCoins)
    return conn.reply(
      m.chat,
      `❌ رصيدك غير كافٍ\nتحتاج: ${neededCoins} عملة`,
      m
    )

  // التحويل
  user.coin -= neededCoins
  user.bank += points

  return conn.reply(
    m.chat,
`*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*✧ \`تحويل العملات إلى نقاط\` ✧*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
➖ *تم خصم:* ⟦ ${neededCoins} عملة ⟧
➕ *تمت الإضافة:* ⟦ ${points} نقطة ⟧
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

> *رصيدك الحالي:*
> 🪙 العملات: ${user.coin}
> 💳 النقاط: ${user.bank}

*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`,
    m
  )
}

handler.help = ['شراء_النقاط <عدد>']
handler.tags = ['economy']
handler.command = /^شراء_النقاط$/i

export default handler