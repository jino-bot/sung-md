import { prepareWAMessageMedia, generateWAMessageFromContent } from "@whiskeysockets/baileys";

let handler = async (m, { conn }) => {
    try {
        // 🔹 إعدادات التاريخ والوقت
        const dateObj = new Date();
        const locale = 'ar-EG';
        const timeZone = 'Africa/Ndjamena';

        const dayName = new Intl.DateTimeFormat(locale, { weekday: 'long', timeZone }).format(dateObj);
        const fullDate = new Intl.DateTimeFormat(locale, { day: 'numeric', month: 'long', year: 'numeric', timeZone }).format(dateObj);
        const timeNow = new Intl.DateTimeFormat(locale, { hour: 'numeric', minute: 'numeric', hour12: true, timeZone }).format(dateObj);

        // 🔹 نص الرسالة المزخرف
        let caption = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*\`˼🗓️˹ الـتـقـويـم الـيـومـي\`↶*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

*｢🕒┊الـتـوقـيـت والـتـاريـخ┊🕒｣*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*┊⟣ الـيـوم:* 『 ${dayName} 』
*┊⟣ الـتـاريـخ:* 『 ${fullDate} 』
*┊⟣ الـسـاعـة:* 『 ${timeNow} 』
*┊⟣ الـمـنـطـقـة:* 『 تـشـاد (GMT+1) 』
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

*｢✨┊حـكـمـة الـيـوم┊✨｣*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*┊⟣* \`"الوقت كالسيف إن لم تقطعه قطعك"\`
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`.trim();

        // 🔹 إرسال الرسالة مع شكل رابط خارجي فخم
        await conn.sendMessage(m.chat, {
            text: caption,
            contextInfo: {
                externalAdReply: {
                    title: `تـقـويـم 𝚂𝙾𝙽𝙶 𝙱𝙾𝚃 📅`,
                    body: `اليوم: ${dayName} | ${fullDate}`,
                    mediaType: 1,
                    thumbnailUrl: 'https://files.catbox.moe/cplot6.png', // صورة التقويم
                    sourceUrl: 'https://whatsapp.com/channel/0029Vaardwo5vKA95jcDWU3P',
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m });

    } catch (e) {
        console.error('❌ خطأ في أمر التقويم:', e);
        m.reply('⚠️ حدث خطأ أثناء جلب البيانات!');
    }
};

handler.help = ['التقويم'];
handler.tags = ['tools'];
handler.command = /^(التقويم|تاريخ|توقيت|date)$/i;

export default handler;
