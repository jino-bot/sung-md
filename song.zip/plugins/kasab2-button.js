let handler = async (m, { args, conn }) => {

  let type = args[0]
  let to = args[1]
  let amount = parseInt(args[2])
  let from = m.sender

  let db = global.db.data

  if (!db.users[from]) db.users[from] = { coin: 0, gold: 0, exp: 0 }
  if (!db.users[to]) db.users[to] = { coin: 0, gold: 0, exp: 0 }

  let sender = db.users[from]
  let receiver = db.users[to]

  function checkAndMove(key) {
    if ((sender[key] || 0) < amount) return false
    sender[key] -= amount
    receiver[key] += amount
    return true
  }

  let success = true

  if (type === 'bank') success = checkAndMove('bank')
  else if (type === 'coin') success = checkAndMove('coin')
  else if (type === 'exp') success = checkAndMove('exp')
  else if (type === 'all') {
    success =
      checkAndMove('bank') &&
      checkAndMove('coin') &&
      checkAndMove('exp')
  }

  if (!success) {
    return m.reply('*❌┇رصيدك غير كافٍ لإتمام التحويل*')
  }

  // 🔥 الحفظ الحقيقي
  global.db.data = db

  let name = await conn.getName(to)

  await m.reply(`
*『✅┇تم التحويل بنجاح┇✅』*
*👤┇إلى:* ${name}
*📦┇النوع:* ${type.toUpperCase()}
*💰┇الكمية:* ${amount}
`)
}

handler.command = ['تحويل_تنفيذ']
export default handler