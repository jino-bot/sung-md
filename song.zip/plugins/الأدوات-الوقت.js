import moment from 'moment-timezone'
import { generateWAMessageFromContent } from "@whiskeysockets/baileys"

let handler = async (m, { conn }) => {
    // التوقيت العالمي والأساسي
    const gmt = moment().tz('Etc/GMT').format('HH:mm')
    const serverTime = moment().format('HH:mm:ss')
    const serverZone = Intl.DateTimeFormat().resolvedOptions().timeZone
    const date = moment().format('YYYY/MM/DD')

    // مصفوفة المناطق والدول (تم تعديل الـ ID ليكون نصاً بسيطاً يتفادى أخطاء المستشعر)
    const regions = [
        {
            title: "🇸🇦 الخليج واليمن",
            rows: [
                { title: "السعودية / قطر / اليمن", id: "Asia/Riyadh" },
                { title: "الإمارات / سلطنة عمان", id: "Asia/Dubai" },
                { title: "الكويت / البحرين", id: "Asia/Kuwait" }
            ]
        },
        {
            title: "🇪🇬 الشام ومصر والعراق",
            rows: [
                { title: "مصر / ليبيا", id: "Africa/Cairo" },
                { title: "فلسطين / لبنان / سوريا", id: "Asia/Gaza" },
                { title: "الأردن / العراق", id: "Asia/Baghdad" }
            ]
        },
        {
            title: "🇹🇩 أفريقيا العربية وتشاد",
            rows: [
                { title: "تشاد / السودان", id: "Africa/Ndjamena" },
                { title: "الجزائر / تونس / المغرب", id: "Africa/Algiers" },
                { title: "موريتانيا", id: "Africa/Nouakchott" }
            ]
        },
        {
            title: "🇪🇺 أوروبا وأمريكا",
            rows: [
                { title: "بريطانيا (لندن)", id: "Europe/London" },
                { title: "فرنسا (باريس)", id: "Europe/Paris" },
                { title: "أمريكا (نيويورك)", id: "America/New_York" }
            ]
        }
    ]

    const sections = regions.map(reg => ({
        title: reg.title,
        rows: reg.rows.map(row => ({
            header: row.title,
            title: "اضغط لعرض الوقت ⏰",
            id: `.gettime ${row.id}#${row.title}` // استخدام معرف فريد
        }))
    }))

    let caption = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
* \`˼⏰˹ الـتـوقـيـت الـعـالـمـي \` ↶*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

*｢🌐┊تـوقـيـت غـريـنـتـش (GMT)┊🌐｣*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*┊⟣ الـسـاعـة الآن:* 『 ${gmt} 』
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

*｢🖥️┊تـوقـيـت الـسـيـرفـر الـحـالـي┊🖥️｣*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*┊⟣ الـنـطـاق:* 『 ${serverZone} 』
*┊⟣ الـوقـت:* 『 ${serverTime} 』
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

*✨ اختر المنطقة من القائمة لعرض المزيد*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

    const interactiveMessage = {
        body: { text: caption },
        footer: { text: "𝙎𝙊𝙉𝙂 𝘽𝙊𝙏 𝙏𝙄𝙈𝙀" },
        header: { title: "نظام التوقيت العالمي 🌍", hasMediaAttachment: false },
        nativeFlowMessage: {
            buttons: [{
                name: 'single_select',
                buttonParamsJson: JSON.stringify({
                    title: "🌍 قائمة الدول والمدن",
                    sections: sections
                })
            }]
        }
    }

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: { message: { interactiveMessage } }
    }, { userJid: conn.user.jid, quoted: m })

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}

// تعديل المستشعر ليكون أكثر استقراراً وتفادياً للخطأ
handler.before = async (m, { conn }) => {
    if (!m.text || !m.text.startsWith('.gettime')) return 
    
    try {
        let rawData = m.text.replace('.gettime ', '').split('#')
        let zone = rawData[0]
        let name = rawData[1]
        
        let time = moment().tz(zone).format('HH:mm')
        let date = moment().tz(zone).format('YYYY/MM/DD')
        
        let resText = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*📍 الـدولة:* ${name}\n*⏰ الـوقـت:* 『 ${time} 』\n*📅 الـتـاريخ:* 『 ${date} 』\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`
        
        await conn.sendMessage(m.chat, { text: resText }, { quoted: m })
    } catch (e) {
        console.error("Error in time sensor:", e)
    }
    return !0
}

handler.help = ['التوقيت']
handler.tags = ['info']
handler.command = /^(التوقيت|الوقت)$/i

export default handler
