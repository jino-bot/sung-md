import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

let handler = async (m, { conn, usedPrefix }) => {
    try {
        // إرسال تفاعل ✨
        await conn.sendMessage(m.chat, { react: { text: "✨", key: m.key } });

        let name = await conn.getName(m.sender)
        
        const messageText = `*مـــرحبــــاً بـــكـ/ﻲ يـا ❪${name}❫ في قسم الأعضاء*
*❐═━━━═╊⊰👥⊱╉═━━━═❐*
> *شرح القسم: أوامر التسلية، الألعاب، والتفاعل الاجتماعي بين الأعضاء*
*❐═━━━═╊⊰👥⊱╉═━━━═❐*
> *｢✨┊قسم الـتـسـلـية والـتـفـاعـل┊✨｣*
*❐═━━━═╊⊰👥⊱╉═━━━═❐*
┊🧠┊: \`${usedPrefix}اختبرني\`
> اختبارات ذكاء ومعلومات عامة متنوعة.
┊📝┊: \`${usedPrefix}بوست\`
> صناعة بوستات مضحكة أو اقتباسات باسمك.
┊⚔️┊: \`${usedPrefix}تحداني\`
> تحديات حماسية بينك وبين البوت أو الأعضاء.
┊🏆┊: \`${usedPrefix}توب\`
> عرض قائمة الأكثر (تفاعلاً/جمالاً/ذكاءً).
┊❤️┊: \`${usedPrefix}جمال\`
> قياس نسبة جمال العضو أو المنشن.
┊💍┊: \`${usedPrefix}زواج\`
> عمل زواج عشوائي بين عضوين في المجموعة.
┊💬┊: \`${usedPrefix}صراحه\`
> أسئلة صراحة قوية ومحرجة أحياناً.
┊💔┊: \`${usedPrefix}طلاق\`
> إنهاء الزواج الوهمي داخل البوت. 
┊💻┊: \`${usedPrefix}تهكير\`
> محاكاة تهكير حسابات الأصدقاء (للمزح).
┊❓┊: \`${usedPrefix}هل\`
> البوت يجيب على أسئلتك بـ (نعم أو لا).
┊👑┊: \`${usedPrefix}تاج\`
> لعبة منشن الظهور عندك. 
┊🌹┊: \`${usedPrefix}غزل\`
> الغزل وعرض كلمات جميلة.
┊❓┊: \`${usedPrefix}لو\`
> البوت يجيب على أسئلتك بـ (نعم أو لا).
*❐═━━━═╊⊰👥⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

        // تأكد من وجود صورة باسم Menu5.jpg أو غير المسار للصورة التي تريدها
        const imagePath = path.join(__dirname, '../src/media/Menu4.jpg')

        if (fs.existsSync(imagePath)) {
            await conn.sendMessage(m.chat, { 
                image: { url: imagePath }, 
                caption: messageText 
            }, { quoted: m })
        } else {
            await conn.sendMessage(m.chat, { text: messageText }, { quoted: m })
        }
    } catch (e) { 
        console.error('Error in Members Menu:', e) 
    }
}

handler.help = ['اعضاء']
handler.tags = ['main'] 
handler.command = /^(قسم16|اعضاء|أعضاء)$/i 

export default handler
