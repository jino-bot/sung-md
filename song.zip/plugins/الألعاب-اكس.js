const salasTTT = new Map()

const symbols = ['❌', '⭕']
const numerosEmoji = ['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣']
const BET = 10

function getName(jid) {
  return global.db.data.users[jid]?.name || jid.split('@')[0]
}

function tableroTexto(tablero) {
  return `
╔═══ 🎮 إكـس ⭕ ❌ أو ═══╗
   ${tablero.slice(0,3).join('  ')}
   ${tablero.slice(3,6).join('  ')}
   ${tablero.slice(6).join('  ')}
╚═══════════════════╝`
}

function checkWinner(t) {
  const win = [
    [0,1,2],[3,4,5],[6,7,8],
    [0,3,6],[1,4,7],[2,5,8],
    [0,4,8],[2,4,6]
  ]
  for (let [a,b,c] of win)
    if (t[a] === t[b] && t[b] === t[c]) return t[a]

  return t.every(v => symbols.includes(v)) ? 'draw' : null
}

async function sendState(conn, sala, extra = '') {
  const [p1, p2] = sala.players
  let txt = `
🎮 *لعبة إكس أو*

👤 ❌ اللاعب الأول:
➤ ${getName(p1)}

👤 ⭕ اللاعب الثاني:
➤ ${p2 ? getName(p2) : 'بانتظار لاعب...'}

${tableroTexto(sala.board)}

${extra || `⬅️ الدور على: ${getName(sala.turn)}`}

💰 *الرهان:* ${BET} عملات
`
  await conn.sendMessage(sala.chat, { text: txt })
}

/* ================= HANDLER ================= */

let handler = async (m, { conn, command, args }) => {
  const user = global.db.data.users[m.sender]
  if (!user) return m.reply('❌ حسابك غير موجود')

  const action = args[0]

  /* ===== فتح غرفة ===== */
  if (action === 'فتح') {
    if (salasTTT.has(m.chat))
      return m.reply('❌ توجد غرفة مفتوحة بالفعل في هذا الشات')

    if (user.coin < BET)
      return m.reply(`❌ تحتاج ${BET} عملات لفتح لعبة`)

    const openMsg = await conn.sendMessage(m.chat, {
      text: `
🎮 *غرفة إكس أو مفتوحة*

👤 اللاعب الأول:
➤ ${getName(m.sender)}

💰 الرهان: ${BET} عملات

📌 *للدخول:*  
قم بالرد على هذه الرسالة و اكتب  
.اكس_او دخول
`
    })

    salasTTT.set(m.chat, {
      chat: m.chat,
      owner: m.sender,
      players: [m.sender],
      board: [...numerosEmoji],
      turn: m.sender,
      openMsgId: openMsg.key.id,
      started: false
    })
    return
  }

  /* ===== دخول غرفة ===== */
  if (action === 'دخول') {
    const sala = salasTTT.get(m.chat)
    if (!sala) return m.reply('❌ لا توجد غرفة مفتوحة')

    if (!m.quoted || m.quoted.id !== sala.openMsgId)
      return m.reply('❌ يجب الرد على رسالة فتح الغرفة')

    if (sala.players.length >= 2)
      return m.reply('❌ الغرفة ممتلئة')

    if (user.coin < BET)
      return m.reply(`❌ تحتاج ${BET} عملات للدخول`)

    // خصم الرهان من الاثنين
    const u1 = global.db.data.users[sala.owner]
    u1.coin -= BET
    user.coin -= BET

    sala.players.push(m.sender)
    sala.started = true

    return sendState(conn, sala, '🎯 *بدأت اللعبة!*')
  }
}

/* ===== اللعب بالأرقام ===== */
handler.before = async (m, { conn }) => {
  const num = parseInt(m.text)
  if (!num || num < 1 || num > 9) return

  const sala = salasTTT.get(m.chat)
  if (!sala || !sala.started) return
  if (!sala.players.includes(m.sender)) return
  if (sala.turn !== m.sender)
    return m.reply('⛔ ليس دورك')

  const i = num - 1
  if (symbols.includes(sala.board[i]))
    return m.reply('❌ الخانة مستخدمة')

  const idx = sala.players.indexOf(m.sender)
  sala.board[i] = symbols[idx]

  const res = checkWinner(sala.board)

  if (res) {
    let extra = ''
    if (res === 'draw') {
      extra = '🤝 *تعادل!*'
      // إرجاع الرهان
      sala.players.forEach(j => global.db.data.users[j].coin += BET)
    } else {
      const winner = m.sender
      global.db.data.users[winner].coin += BET * 2
      extra = `🏆 *الفائز:* ${getName(winner)}\n💰 +${BET * 2} عملات`
    }

    await sendState(conn, sala, extra)
    salasTTT.delete(m.chat)
    return
  }

  sala.turn = sala.players.find(j => j !== m.sender)
  return sendState(conn, sala)
}

handler.command = /^(اكس_او|ttt)$/i
handler.tags = ['game']
handler.help = ['اكس_او فتح', 'اكس_او دخول']

export default handler