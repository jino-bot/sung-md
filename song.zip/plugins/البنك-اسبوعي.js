const freeCoin = 5000
const freeBank = 1000
const premCoin = 10000
const premBank = 3000

let handler = async (m, { conn, isPrems }) => {
  let user = global.db.data.users[m.sender]
  
  if (user.level < 10) throw `*『⚠️┇تنبيه┇⚠️』*\n\nيجب أن يكون مستواك *10* على الأقل للاستلام الأسبوعي.`
  
  user.lastWeekly ??= 0
  const cooldown = 604800000 // 7 أيام
  if (Date.now() - user.lastWeekly < cooldown) {
    throw `*『⏳┇انتظر┇⏳』*\n\nاستلمت الجائزة الأسبوعية مسبقاً.\n\n*📅 الموعد القادم بعد:* ${msToTime(cooldown - (Date.now() - user.lastWeekly))}`
  }

  let rCoin = isPrems ? premCoin : freeCoin
  let rBank = isPrems ? premBank : freeBank
  
  user.coin += rCoin
  user.bank += rBank
  user.lastWeekly = Date.now()

  let caption = `
*『🗓️┇المكافأة الأسبوعية┇🗓️』*

*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
*❐↞🪙┇العملات المضافة: ${rCoin}*
*❐↞💰┇نقاط البنك المضافة: ${rBank}*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
> *تذكر العودة الأسبوع القادم!*`.trim()

  m.reply(caption)
}
handler.command = ['اسبوعي']
export default handler
