let handler = async (m, { conn, text }) => {
    if (!text) throw `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*┊⇇منشن الشخص لمعرفت جماله*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`

    // تحويل النص إلى كلمات args
    const args = text.split(' ')

    // الحصول على المستخدم المذكور أو الرقم
    const mentionedUser = m.mentionedJid && m.mentionedJid[0]
        ? m.mentionedJid[0]
        : args[0]
            ? (args[0].replace(/[@ .+-]/g, '') + '@s.whatsapp.net')
            : m.sender

    // مصفوفة نسب الجمال 1% إلى 100%
    const userChar = Array.from({ length: 100 }, (_, i) => `${i + 1}%`)

    // اختيار نسبة عشوائية
    const userCharacterSeletion = userChar[Math.floor(Math.random() * userChar.length)]

    // صياغة الرسالة مع الزينة والنصوص بالضبط كما طلبت
    let message = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*┊⇇المنشن ↜ ｢@${mentionedUser.split("@")[0]}｣*
*┊⇇نسبة جماله ↜ ｢${userCharacterSeletion}｣*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

    // إرسال الرسالة مع المنشن
    await conn.sendMessage(m.chat, { text: message, mentions: [mentionedUser] }, { quoted: m })
}

// إعدادات الهاندلر
handler.help = ["جميل @tag"]
handler.tags = ['fun']
handler.command = /^(جمال)$/i

export default handler