import axios from 'axios'

let handler = async (m, { conn, args }) => {
  const chatId = m.chat

  if (!args || args.length === 0) {
    return conn.sendMessage(
      chatId,
      {
        text: `❌ *| الصيغة ناقصة!*\n\nاستخدم:\n\`.بحث_انمي [اسم_الانمي]\``
      },
      { quoted: m }
    )
  }

  const query = args.join(' ').trim()

  try {
    // 🔍 البحث عبر Jikan API
    const url = `https://api.jikan.moe/v4/anime?q=${encodeURIComponent(query)}&limit=1`
    const res = await axios.get(url)

    if (!res.data?.data?.length) {
      return conn.sendMessage(
        chatId,
        { text: `❌ لم يتم العثور على نتائج لـ: *${query}*` },
        { quoted: m }
      )
    }

    const anime = res.data.data[0]

    const caption =
      `*❐═━━━═╊⊰🌸⊱╉═━━━═❐*\n\n` +
      `🎀 • *الاسم:* ${anime.title}\n` +
      `🎋 • *النوع:* ${anime.type || 'غير محدد'}\n` +
      `📈 • *الحالة:* ${anime.status || 'غير معروف'}\n` +
      `🍥 • *عدد الحلقات:* ${anime.episodes || 'غير محدد'}\n` +
      `🎈 • *المدة:* ${anime.duration || 'غير معروف'}\n` +
      `✨ • *المصدر:* ${anime.source || 'غير محدد'}\n` +
      `🏅 • *الترتيب:* ${anime.rank || 'غير متاح'}\n` +
      `🎐 • *الشعبية:* ${anime.popularity || 'غير متاح'}\n` +
      `🌐 • *الرابط:* ${anime.url}\n\n` +
      `🎆 • *الملخص:*\n${anime.synopsis || 'لا يوجد ملخص'}\n\n` +
      `*❐═━━━═╊⊰🌸⊱╉═━━━═❐*`

    await conn.sendMessage(
      chatId,
      {
        image: { url: anime.images.jpg.image_url },
        caption
      },
      { quoted: m }
    )

  } catch (err) {
    console.error('[ANIME ERROR]', err)
    await conn.sendMessage(
      chatId,
      { text: `❌ *| حدث خطأ أثناء جلب معلومات الأنمي!*` },
      { quoted: m }
    )
  }
}

handler.help = ['بحث_انمي <اسم>']
handler.tags = ['anime', 'search']
handler.command = ['بحث_انمي', 'anime']

export default handler