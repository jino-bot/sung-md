import moment from 'moment-timezone'

let handler = async (m, { conn, text, participants, args }) => {
  // الأعضاء فقط (بدون مشرفين)
  let users = participants.filter(p => !p.admin)

  // بيانات المجموعة
  let groupMetadata = await conn.groupMetadata(m.chat)
  let groupName = groupMetadata.subject
  let time = moment.tz('Asia/Riyadh').format('hh:mm A')
  let date = moment.tz('Asia/Riyadh').format('YYYY/MM/DD')
  let messageContent = text ? text : 'لا توجد رسالة محددة'

  // النص (بدون أي تغيير)
  let teks = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
 \`˼🌐˹ منشن أعضاء المجموعة\`↶
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
💠 *اسم المجموعة:* 『 ${groupName} 』
📩 *الرسالة:* 『 ${messageContent} 』
📅 *التاريخ:* 『 ${date} 』
🕰️ *الوقت:* 『 ${time} 』
👥 *عدد المستهدفين:* 『 ${users.length} 』
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> ˼👥˹  *قائمة الأعضاء* ↶
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
${users.map(v => `*┊⟣*｢@${v.id.split('@')[0]}｣`).join('\n')}
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> ˼👑˹  *مسؤول المنشن* ↶
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*┊⟣*｢@${m.sender.split('@')[0]}｣
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

  // ===== القناة + المنشن الصحيح =====
  const channelInfo = {
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: '120363416870755391@newsletter',
      newsletterName: '𝐒𝐔𝐍𝐆 ꒰🐉⃝⃕꒱𝐔𝐏𝐃𝐀𝐓𝐄',
      serverMessageId: -1
    },
    mentionedJid: users.map(u => u.id).concat([m.sender])
  }

  // الإرسال
  await conn.sendMessage(
    m.chat,
    {
      text: teks,
      contextInfo: channelInfo
    },
    { quoted: m }
  )
}

handler.help = ['منشن_اعضاء']
handler.tags = ['group']
handler.command = /^(منشن_اعضاء|منشن_أعضاء)$/i
handler.group = true
handler.admin = true

export default handler