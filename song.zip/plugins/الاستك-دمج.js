import fetch from 'node-fetch'
import { sticker } from '../lib/sticker.js'

let handler = async (m, { conn, text, args, usedPrefix, command }) => {

  if (!text || !text.includes('+'))
    return conn.sendMessage(m.chat, {
      text: `⚠️ الصيغة الصحيحة:\n\n${usedPrefix + command} 😺+😆`
    }, { quoted: m })

  let [emoji1, emoji2] = text.split('+').map(e => e.trim())

  if (!emoji1 || !emoji2)
    return conn.sendMessage(m.chat, {
      text: '❌ لازم تحط إيموجيين صحيحين'
    }, { quoted: m })

  await conn.sendMessage(m.chat, { react: { text: '🧩', key: m.key } })

  try {
    const url = `https://tenor.googleapis.com/v2/featured` +
      `?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ` +
      `&contentfilter=high` +
      `&media_filter=png_transparent` +
      `&component=proactive` +
      `&collection=emoji_kitchen_v5` +
      `&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`

    const res = await fetch(url)
    const json = await res.json()

    if (!json.results || json.results.length === 0)
      throw '❌ هذا الدمج غير مدعوم 😔'

    // نرسل أول نتيجة فقط
    const imgUrl = json.results[0].url

    const stiker = await sticker(
      false,
      imgUrl,
      global.info?.packname || 'Song Bot',
      global.info?.author || 'Ayoub'
    )

    await conn.sendMessage(m.chat, {
      sticker: stiker
    }, { quoted: m })

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

  } catch (e) {
    console.error(e)
    await conn.sendMessage(m.chat, {
      text: '❌ حدث خطأ أو هذا الدمج غير متوفر'
    }, { quoted: m })
  }
}

handler.help = ['دمج 😎+😄']
handler.tags = ['sticker']
handler.command = ['دمج', 'emojimix']
handler.limit = 1

export default handler