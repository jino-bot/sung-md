import axios from 'axios'

const FLAGS = {
  'السعودية': '🇸🇦',
  'مصر': '🇪🇬',
  'المغرب': '🇲🇦',
  'الجزائر': '🇩🇿',
  'تونس': '🇹🇳',
  'الكويت': '🇰🇼',
  'الإمارات': '🇦🇪',
  'قطر': '🇶🇦',
  'عمان': '🇴🇲',
  'لبنان': '🇱🇧',
  'سوريا': '🇸🇾',
  'اليمن': '🇾🇪',
  'العراق': '🇮🇶',
  'الأردن': '🇯🇴',
  'فلسطين': '🇵🇸',
  'تشاد': '🇹🇩',
  'أنجمينا': '🇹🇩',
  'أفريقيا الوسطى': '🇨🇫'
}

let handler = async (m, { conn, args, command }) => {
  if (!args.length) {
    throw `*❍━━━═『 📿 مواقيت الصلاة 』═━━━❍*

📌 *الاستخدام الصحيح:*
.${command} <اسم المدينة>

✧ مثال:
.${command} الرياض
.${command} أنجمينا`
  }

  let city = args.join(' ').trim()
  let country = 'SA'

  if (/تشاد|أنجمينا/i.test(city)) country = 'TD'

  try {
    let res = await axios.get(
      'https://api.aladhan.com/v1/timingsByCity',
      {
        params: {
          city,
          country,
          method: 4
        }
      }
    )

    let data = res.data.data.timings

    // تحديد العلم
    let flag = '🏳️'
    for (let key in FLAGS) {
      if (city.includes(key)) {
        flag = FLAGS[key]
        break
      }
    }

    let caption = `
*❍━━━═『 🕌 أوقات الصلاة 』═━━━❍*

📍 *المدينة:* 『 ${city} ${flag} 』

┌───❖✧❖───┐
✨ *الفجر:*     ${data.Fajr}
🌅 *الشروق:*   ${data.Sunrise}
🕌 *الظهر:*    ${data.Dhuhr}
🕒 *العصر:*    ${data.Asr}
🌇 *المغرب:*   ${data.Maghrib}
🌙 *العشاء:*   ${data.Isha}
└───❖✧❖───┘

*❍━━━═『 📿 』═━━━❍*
`.trim()

    await conn.sendMessage(
      m.chat,
      { text: caption },
      { quoted: m }
    )

  } catch (e) {
    console.error(e)
    await conn.sendMessage(
      m.chat,
      {
        text: `❌ *حدث خطأ أثناء جلب المواقيت.*
📌 تأكد من اسم المدينة وحاول مرة أخرى.`
      },
      { quoted: m }
    )
  }
}

handler.help = ['مواقيت <مدينة>']
handler.tags = ['islam']
handler.command = /^مواقيت$/i

export default handler