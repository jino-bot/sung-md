import { xpRange } from '../lib/levelling.js'
import PhoneNumber from 'awesome-phonenumber'
import fetch from 'node-fetch'

let handler = async (m, { conn, usedPrefix }) => {
  let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
  let user = global.db.data.users[who]
  if (!user) return m.reply('⚠️ المستخدم غير موجود في قاعدة البيانات!')

  let { level, exp, role, name, registered, age } = user
  let { min, xp, max } = xpRange(level, global.multiplier)
  let prem = global.prems.includes(who.split`@`[0])
  let xpToLevelUp = max - exp

  // تحسين شريط التقدم
  let progress = Math.floor(((exp - min) / (max - min)) * 100)
  progress = Math.max(0, Math.min(100, progress))
  let filledBar = Math.floor(progress / 10)
  let bar = '▰'.repeat(filledBar) + '▱'.repeat(10 - filledBar)

  // جلب صورة البروفايل
  let pp = await conn.profilePictureUrl(who, 'image').catch(_ => 'https://qu.ax/fNyJg.jpg')
  
  let now = new Date()
  let date = now.toLocaleDateString('ar-EG', { day: 'numeric', month: 'long', year: 'numeric' })
  let time = now.toLocaleTimeString('ar-EG', { hour: 'numeric', minute: 'numeric' })

  let txt = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
\`˼👤˹ مـلـف الـتـعـريـف الشخصي\` ↶
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

*｢📜┊الـبـيـانـات الأسـاسـيـة┊📜｣*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*┊⟣ الـنـمـوذج:* 『 ${name} 』
*┊⟣ الـعـمـر:* 『 ${registered ? `${age} سنة` : 'غير مسجل'} 』
*┊⟣ الـرقم:* 『 ${PhoneNumber('+' + who.replace('@s.whatsapp.net', '')).getNumber('international')} 』
*┊⟣ الـرتبـة:* 『 ${role} 』
*┊⟣ بـريمـيـوم:* 『 ${prem ? 'نعم ✅' : 'لا ❌'} 』
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

*｢📊┊إحـصـائـيـات الـمـسـتـوى┊📊｣*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*┊⟣ الـمـستوى:* 『 ${level} 』
*┊⟣ الـخـبـرة:* 『 ${exp} / ${max} 』
*┊⟣ الـتـقدم:* [ ${bar} ] ${progress}%
*┊⟣ الـمتبقي:* 『 ${xpToLevelUp} XP 』
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

*｢🕒┊مـعـلومـات الـوقـت┊🕒｣*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*┊⟣ الـتـاريخ:* 『 ${date} 』
*┊⟣ الـتـوقيت:* 『 ${time} 』
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`.trim()

  await conn.sendMessage(m.chat, {
    image: { url: pp },
    caption: txt,
    contextInfo: {
      externalAdReply: {
        title: `𝚂𝙾𝙽𝙶 𝙱𝙾𝚃 𝙿𝚁𝙾𝙵𝙸𝙻𝙴: ${name}`,
        body: `Level: ${level} | Rank: ${role}`,
        thumbnailUrl: pp,
        sourceUrl: 'https://whatsapp.com/channel/0029Vaardwo5vKA95jcDWU3P',
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  }, { quoted: m })
}

handler.help = ['بروفايل']
handler.tags = ['start']
handler.command = /^(معلوماتي|برفايلي)$/i

export default handler
