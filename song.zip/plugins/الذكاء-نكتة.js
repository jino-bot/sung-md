import axios from 'axios'

const GEMINI_KEY = 'AIzaSyBVQ94Sb8l7zXkiWqycDIM8c11qeZ1xfEg'

let handler = async (m, { conn }) => {

  // تفاعل مبدئي
  await conn.sendMessage(m.chat, {
    react: { text: '😂', key: m.key }
  })

  // 🎭 برومبت النكت
  const prompt = `
أنت مولّد نكت عربي.
مهمتك:
- إعطاء نكتة عربية مضحكة جدًا
- قصيرة
- بدون سب
- بدون إساءة
- بدون سياسة أو دين
- نكتة مفهومة لكل الأعمار

أعطني نكتة واحدة فقط.
  `.trim()

  try {
    const res = await axios.post(
      `https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=${GEMINI_KEY}`,
      {
        contents: [
          {
            parts: [{ text: prompt }]
          }
        ]
      },
      {
        headers: { 'Content-Type': 'application/json' }
      }
    )

    let joke =
      res.data?.candidates?.[0]?.content?.parts?.[0]?.text ||
      'كنت بقول نكتة… بس شكلها راحت تشرب شاي ☕'

    joke = joke.replace(/\*\*/g, '').trim()

    // تفاعل نجاح
    await conn.sendMessage(m.chat, {
      react: { text: '🤣', key: m.key }
    })

    return conn.reply(
      m.chat,
      `🤣 *نكتة اليوم:*\n\n${joke}`,
      m
    )

  } catch (err) {
    console.error('❌ خطأ النكتة:', err)

    await conn.sendMessage(m.chat, {
      react: { text: '❌', key: m.key }
    })

    return conn.reply(
      m.chat,
      '😅 حاولت أضحكك… بس السيرفر قرر يكون جدي.',
      m
    )
  }
}

handler.help = ['نكتة']
handler.tags = ['fun']
handler.command = /^نكتة$/i

export default handler
