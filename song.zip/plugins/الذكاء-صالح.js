import axios from 'axios'

const GEMINI_KEY = 'AIzaSyBVQ94Sb8l7zXkiWqycDIM8c11qeZ1xfEg'

let handler = async (m, { text, conn }) => {
  if (!text) {
    return conn.reply(
      m.chat,
      '📖 *صالح هنا للإجابة على الأسئلة الدينية فقط*\n\nمثال:\n.صالح ما حكم صلاة الجماعة؟',
      m
    )
  }

  await conn.sendMessage(m.chat, {
    react: { text: '📖', key: m.key }
  })

  // 🧠 برومبت شخصية صالح
  const prompt = `
أنت شخصية اسمها "صالح".
داعية مسلم هادئ ومتزن.
تجيب فقط على الأسئلة الدينية الإسلامية.
إجاباتك قصيرة وواضحة.
تعتمد القرآن والسنة بفهم أهل السنة والجماعة.
إن كان السؤال غير ديني، اعتذر بلطف وقل إنك مختص بالأسئلة الدينية فقط.
لا تذكر أي شيء عن الذكاء الاصطناعي أو التقنية.
الحد الأقصى للرد: 40 كلمة.

السؤال:
"${text}"
  `.trim()

  try {
    const res = await axios.post(
      `https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=${GEMINI_KEY}`,
      {
        contents: [
          {
            parts: [{ text: prompt }]
          }
        ]
      },
      { headers: { 'Content-Type': 'application/json' } }
    )

    let reply =
      res.data?.candidates?.[0]?.content?.parts?.[0]?.text ||
      'لم أتمكن من الإجابة حالياً.'

    reply = reply.replace(/\*\*/g, '').trim()

    await conn.sendMessage(m.chat, {
      react: { text: '✅', key: m.key }
    })

    return conn.reply(m.chat, `📖 *صالح:*\n${reply}`, m)
  } catch (e) {
    console.error(e)
    await conn.sendMessage(m.chat, {
      react: { text: '❌', key: m.key }
    })
    return conn.reply(
      m.chat,
      '⚠️ حدث خطأ، حاول مرة أخرى لاحقاً.',
      m
    )
  }
}

handler.help = ['صالح <سؤال ديني>']
handler.tags = ['islam', 'ai']
handler.command = /^صالح$/i

export default handler
