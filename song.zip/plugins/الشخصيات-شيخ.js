import { prepareWAMessageMedia, generateWAMessageFromContent } from "@whiskeysockets/baileys";
import axios from 'axios';

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // التحقق من وجود نص
    if (!text) {
        return conn.reply(m.chat, `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*أهلاً بك يا بني.. أنا الشيخ الحكيم، كيف يمكنني إرشادك اليوم؟*\n\n*مثال: ${usedPrefix + command} كيف أحافظ على صلاتي؟*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`, m);
    }

    // تفاعل المسك (📿)
    await conn.sendMessage(m.chat, { react: { text: "📿", key: m.key } });

    const prompt = `
أنت "الشيخ الحكيم"، عالم دين وقور وحكيم. تتحدث باللغة العربية الفصحى المبسطة، بأسلوب هادئ، ناصح، ومليء بالرحمة. تبدأ ردودك غالباً بكلمات مثل "يا بني"، "يا رعاك الله"، "اعلم بارك الله فيك". استشهد بآيات قرآنية أو أحاديث نبوية إذا كان ذلك مناسباً للسياق. لا تفتِ في الأمور المعقدة جداً بل انصح بالخير والتقوى. لا تذكر أنك ذكاء اصطناعي.

سؤال السائل: "${text}"
رد الشيخ الحكيم:
    `.trim();

    const apiKey = "AIzaSyBVQ94Sb8l7zXkiWqycDIM8c11qeZ1xfEg";

    try {
        // جلب الرد من Gemini
        const res = await axios.post(
            `https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
            { contents: [{ parts: [{ text: prompt }] }] },
            { headers: { 'Content-Type': 'application/json' } }
        );

        let reply = res.data.candidates?.[0]?.content?.parts?.[0]?.text || 'بارك الله فيك يا بني، لم أسمع سؤالك جيداً.';
        reply = reply.replace(/\*\*/g, ''); // إزالة العلامات الزائدة

        const messageText = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*✧ \`نصيحة الشيخ الحكيم\` ✧*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n\n${reply}\n\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`;

        // تجهيز صورة الشيخ
        const media = await prepareWAMessageMedia(
            { image: { url: 'https://files.catbox.moe/vxa4fw.jpg' } }, // صورة وقورة لشيخ أو خلفية إسلامية
            { upload: conn.waUploadToServer }
        );

        // إنشاء الرسالة التفاعلية
        const interactiveMessage = {
            body: { text: messageText },
            footer: { text: `> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*` },
            header: { 
                hasMediaAttachment: true, 
                imageMessage: media.imageMessage 
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📢┇قناة البوت┇📢",
                            url: "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o",
                            merchant_url: "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o"
                        })
                    }
                ]
            }
        };

        let msg = generateWAMessageFromContent(
            m.chat,
            { viewOnceMessage: { message: { interactiveMessage } } },
            { userJid: conn.user.jid, quoted: m }
        );

        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (error) {
        console.error('Sheikh AI Error:', error?.response?.data || error.message);
        await conn.reply(m.chat, '⚠️ | عذراً يا بني، يبدو أن هناك خطأ حال بيني وبين إجابتك. حاول لاحقاً.', m);
    }
};

handler.help = ['شيخ'];
handler.tags = ['ai'];
handler.command = /^(شيخ|الشيخ|فتوى)$/i;

export default handler;
