import fetch from 'node-fetch'
import { sticker } from '../lib/sticker.js'

let handler = async (m, { conn, text, usedPrefix, command }) => {

  if (!text) {
    return conn.sendMessage(m.chat, {
      text: `⚠️ اكتب كلمة للبحث عن حزم ملصقات\n\nمثال:\n${usedPrefix + command} قطط`
    }, { quoted: m })
  }

  try {
    const res = await fetch(
      `https://api.dorratz.com/v3/stickerly?query=${encodeURIComponent(text)}`
    )
    const json = await res.json()

    if (!json.success || !json.data || json.data.length === 0) {
      return conn.sendMessage(m.chat, {
        text: `❌ لم يتم العثور على أي حزم لـ: *${text}*`
      }, { quoted: m })
    }

    // 🔐 الحقوق المضمّنة
    const packname = 'Song Bot'
    const author = 'Developer Ayoub'

    const packs = json.data.slice(0, 30)
    const total = packs.length

    await conn.sendMessage(m.chat, {
      text:
        `🎯 *نتائج البحث:* ${text}\n` +
        `🧷 *عدد الملصقات:* ${total}\n` +
        `⏳ *جاري الإرسال...*`
    }, { quoted: m })

    let sent = 0

    for (const pack of packs) {
      try {
        const stkr = await sticker(
          false,
          pack.thumbnailUrl,
          packname,
          author
        )

        if (stkr) {
          await conn.sendMessage(m.chat, {
            sticker: stkr
          }, { quoted: m })

          sent++
          await new Promise(r => setTimeout(r, 700))
        }
      } catch (e) {
        console.error('❌ خطأ في إرسال ملصق:', e)
      }
    }

    if (sent === 0) {
      return conn.sendMessage(m.chat, {
        text: '❌ لم يتم إرسال أي ملصق.'
      }, { quoted: m })
    }

    await conn.sendMessage(m.chat, {
      react: { text: '✅', key: m.key }
    })

  } catch (e) {
    console.error(e)
    await conn.sendMessage(m.chat, {
      text: '❌ حدث خطأ أثناء البحث عن الملصقات.'
    }, { quoted: m })
  }
}

handler.help = ['ملصقات <بحث>']
handler.tags = ['sticker']
handler.command = ['ملصقات']
handler.limit = 1

export default handler