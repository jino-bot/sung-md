let handler = async (m, { conn, args, usedPrefix, command }) => {
    let chat = global.db.data.chats[m.chat]
    if (!args[0]) {
        let status = chat.antiToxic ? 'مفعل ✅' : 'معطل ❌'
        return m.reply(`*🛡️ حالة مانع الشتائم:* ${status}\n\n*استخدم:* \n• ${usedPrefix + command} on\n• ${usedPrefix + command} off`)
    }

    if (args[0] === 'on') {
        chat.antiToxic = true
        m.reply('✅ تم تفعيل نظام مكافحة الشتائم وتحليل السمية.')
    } else if (args[0] === 'off') {
        chat.antiToxic = false
        m.reply('❌ تم تعطيل نظام مكافحة الشتائم.')
    }
}
handler.help = ['شتائم']
handler.tags = ['group']
handler.command = ['شتائم', 'antitoxic'] 
handler.admin = true
handler.group = true

export default handler
