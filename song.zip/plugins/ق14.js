import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

let handler = async (m, { conn, usedPrefix }) => {
    try {
        // إرسال تفاعل 🕹️
        await conn.sendMessage(m.chat, { react: { text: "🕹️", key: m.key } });

        let name = await conn.getName(m.sender)
        
        const messageText = `*مـــرحبــــاً بـــكـ/ﻲ يـا ❪${name}❫ في قسم الفعاليات*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *شرح القسم: فعاليات ومسابقات تفاعلية سريعة للحصول على الجوائز والنقاط*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *｢🎉┊قسم الـفـعـالـيـات الـمـمـيـزة┊🎉｣*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
┊🎨┊: \`${usedPrefix}ايموجي\`
> فعالية ⟦خمن الشخصية من  الإيموجي⟧.
┊🐾┊: \`${usedPrefix}كت\`
> فعالية ⟦اكتب الكلمة الظاهرة الإيموجي⟧.
┊🎭┊: \`${usedPrefix}احزر\`
> فعالية ⟦خمن الشخصية من الصورة⟧.
┊🧩┊: \`${usedPrefix}ركب\`
> فعالية ⟦ركّب الكلمة المبعثرة بشكل صحيح⟧.
┊❓┊: \`${usedPrefix}سؤال\`
> فعالية ⟦أسئلة ذكاء عامة وجوائز⟧.
┊🏴┊: \`${usedPrefix}علم\`
> فعالية ⟦خمن علم الدولة من الإيموجي⟧.
┊👁️‍🗨️┊: \`${usedPrefix}عين\`
> فعالية ⟦خمن الشخصية من صورة العين⟧.
┊✂️┊: \`${usedPrefix}فكك\`
> فعالية ⟦فكك الكلمة المدمجة إلى حروف⟧.
┊🗾┊: \`${usedPrefix}عاصمة\`
> فعالية ⟦خمن عاصمة الدولة الإيموجي⟧.
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

    const imagePath = path.join(__dirname, '../src/media/Menu4.jpg')

    if (fs.existsSync(imagePath)) {
        await conn.sendMessage(m.chat, { 
            image: { url: imagePath }, 
            caption: messageText 
        }, { quoted: m })
    } else {
        await conn.sendMessage(m.chat, { text: messageText }, { quoted: m })
    }

    } catch (err) {
        console.error('❌ Error in Events Menu:', err)
    }
}

handler.help = ['الفعاليات']
handler.tags = ['main']
handler.command = /^(قسم14)$/i 

export default handler
