const free = 10000 // جائزة المستخدم العادي
const prem = 25000 // جائزة المستخدم المميز (بريميوم)

let handler = async (m, { conn, isPrems }) => {
  let user = global.db.data.users[m.sender]
  if (!user) return m.reply('❌ لم يتم العثور على حسابك.')

  // التحقق من المستوى (يجب أن يكون 25 أو أعلى)
  if (user.level < 25) {
    throw `*『⚠️┇تنبيه┇⚠️』*\n\nعذراً، يجب أن يصل مستواك إلى *25* لتتمكن من استلام المكافأة الشهرية.\n\n*🎰 مستواك الحالي:* ${user.level}`
  }

  // تهيئة القيم
  user.lastMonthly ??= 0
  user.coin ??= 0

  const cooldown = 2592000000 // 30 يوم بالملي ثانية
  const now = Date.now()

  if (now - user.lastMonthly < cooldown) {
    let remaining = cooldown - (now - user.lastMonthly)
    throw `*『⏳┇انتظر┇⏳』*\n\nلقد استلمت مكافأتك الشهرية بالفعل.\n\n*📅 الموعد القادم بعد:* ${msToTime(remaining)}`
  }

  let reward = isPrems ? prem : free
  user.coin += reward
  user.lastMonthly = now

  let caption = `
*『🎁┇المكافأة الشهرية┇🎁』*

*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
*❐↞👤┇الــأســـــم: ${conn.getName(m.sender)}*
*❐↞🎖┇الرتــــبـــة: ${user.role || 'محارب'}*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*

*❐↞🪙┇الجوائز المضافة: ${reward} عملة*
*❐↞💰┇إجمالي عملاتك: ${user.coin}*

*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
> *تذكر العودة الشهر القادم للاستلام مرة أخرى!*`.trim()

  await conn.reply(m.chat, caption, m)
}

handler.help = ['monthly', 'شهري']
handler.tags = ['economy']
handler.command = ['شهري']

export default handler

function msToTime(ms) {
  let days = Math.floor(ms / (24 * 60 * 60 * 1000))
  let daysms = ms % (24 * 60 * 60 * 1000)
  let hours = Math.floor(daysms / (60 * 60 * 1000))
  let hoursms = ms % (60 * 60 * 1000)
  let minutes = Math.floor(hoursms / (60 * 1000))
  
  return `${days} يوم و ${hours} ساعة و ${minutes} دقيقة`
}
