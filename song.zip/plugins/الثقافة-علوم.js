import fs from 'fs';
import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

const timeout = 60000;
const poin = 200;

let handler = async (m, { conn, command }) => {
    conn.tekateki = conn.tekateki || {};
    let id = m.chat;

    // معالجة الإجابة عند الضغط على الزر
    if (command.startsWith('اجابة_علوم_')) {
        let game = conn.tekateki[id];
        if (!game) return;

        let selectedAnswerIndex = parseInt(command.split('_')[2]);
        let selectedAnswer = game[4][selectedAnswerIndex - 1];
        let isCorrect = game[1].response.trim().toLowerCase() === selectedAnswer.trim().toLowerCase();

        if (isCorrect) {
            let db = global.db.data

// تأكد من وجود المستخدم
if (!db.users[m.sender]) {
    db.users[m.sender] = {
        bank: 0,
        exp: 0,
        coin: 0,
        level: 0
    }
}

// إضافة 150 نقطة إلى البنك
db.users[m.sender].bank = (db.users[m.sender].bank || 0) + poin

// حفظ فعلي
global.db.data = db
            clearTimeout(game[3]);
            delete conn.tekateki[id];

            const interactiveMessage = {
                body: { text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*🎉 إجابتك صحيحة مبروك 🎉*\n*🏦┊الجائزة┊⇇ ${poin} نقطة*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*` },
                footer: { text: '𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
                nativeFlowMessage: {
                    buttons: [{ name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🔄 سؤال علمي آخر', id: '.علوم' }) }]
                }
            };
            return conn.relayMessage(m.chat, { viewOnceMessage: { message: { interactiveMessage } } }, {});
        } else {
            game[5] -= 1; // تقليل المحاولات
            if (game[5] > 0) {
                return conn.reply(m.chat, `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*إجابتك خاطئة ❌*\n*لديك محاولة واحدة أخرى ⏳*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`, m);
            } else {
                let correct = game[1].response;
                clearTimeout(game[3]);
                delete conn.tekateki[id];

                const interactiveMessage = {
                    body: { text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*إجابتك خاطئة ❌*\n*إنتهت المحاولات المتاحة*\n*✅┊الإجابة هي┊⇇ ${correct}*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*` },
                    footer: { text: '𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
                    nativeFlowMessage: {
                        buttons: [{ name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🔄 حاول مجدداً', id: '.علوم' }) }]
                    }
                };
                return conn.relayMessage(m.chat, { viewOnceMessage: { message: { interactiveMessage } } }, {});
            }
        }
    }

    // بدء لعبة جديدة
    if (id in conn.tekateki) {
        return conn.reply(m.chat, '*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*هناك تحدي علمي لم ينتهِ بعد! ⚠️*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*', conn.tekateki[id][0]);
    }

    let filePath = `./src/game/علوم.json`;
    if (!fs.existsSync(filePath)) return conn.reply(m.chat, '❌ ملف أسئلة العلوم غير موجود!', m);

    let tekateki = JSON.parse(fs.readFileSync(filePath));
    let json = tekateki[Math.floor(Math.random() * tekateki.length)];
    
    // توليد خيارات عشوائية
    let options = [json.response];
    while (options.length < 4) {
        let randomRes = tekateki[Math.floor(Math.random() * tekateki.length)].response;
        if (!options.includes(randomRes)) options.push(randomRes);
    }
    options.sort(() => Math.random() - 0.5);

    const imageUrl = 'https://telegra.ph/file/39fb047cdf23c790e0146.jpg';
    const media = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: conn.waUploadToServer });

    const interactiveMessage = {
        body: {
            text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*✧ \`تحدي العباقرة والعلوم\` ✧*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

*❏- 🔬 الـسـؤال : ⟦ ${json.question} ⟧*

*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*❏- ⏱️ الـوقـت: ⟦60 ثانـية ⟧*
*❏- 🏦 الجائزة: ⟦ ${poin} نقطة ⟧*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
> اختر الإجابة العلمية الصحيحة من الأزرار
> لديك محاولتين فقط
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`,
        },
        footer: { text: '𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
        header: {
            hasMediaAttachment: true,
            imageMessage: media.imageMessage,
        },
        nativeFlowMessage: {
            buttons: options.map((opt, i) => ({
                name: 'quick_reply',
                buttonParamsJson: JSON.stringify({
                    display_text: `🧬 ${opt}`,
                    id: `.اجابة_علوم_${i + 1}`
                })
            })),
        },
    };

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: { message: { interactiveMessage } },
    }, { userJid: conn.user.jid, quoted: m });

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    conn.tekateki[id] = [
        msg,
        json, 
        poin,
        setTimeout(async () => {
            if (conn.tekateki[id]) {
                await conn.reply(m.chat, `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*⌛ انتهى الوقت المسموح*\n*✅ الإجابة الصحيحة هي: ${json.response}*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`, m);
                delete conn.tekateki[id];
            }
        }, timeout),
        options,
        2 // محاولات
    ];
};

handler.help = ['علوم'];
handler.tags = ['game'];
handler.command = /^(علوم|اجابة_علوم_\d+)$/i;

export default handler;
