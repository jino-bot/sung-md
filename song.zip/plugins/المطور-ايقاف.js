let handler = async (m, { conn, isOwner }) => {
  if (!isOwner) {
    return m.reply('⛔ هذا الأمر مخصص للمالك فقط')
  }

  const text = `
*❐═━━━═╊⊰⚫️⊱╉═━━━═❐*
*┊   ⛔️『 𝚂𝙾𝙽𝙶 𝙱𝙾𝚃 مُوقوف 』⛔️ ┊*
*❐═━━━═╊⊰⚫️⊱╉═━━━═❐*
> ⧉↫ تم إيقاف البوت
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*
`.trim()

  await conn.sendMessage(m.chat, { text }, { quoted: m })

  // إغلاق الاتصال وإنهاء البوت
  await conn.ws.close()
  process.exit(0)
}

/* ===== معلومات الأمر ===== */
handler.help = ['إيقاف', 'shutdown']
handler.tags = ['owner']
handler.command = /^(إيقاف|ايقاف|shutdown|stop)$/i
handler.owner = true

export default handler