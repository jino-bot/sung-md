export async function before(m, { conn, isOwner, isROwner }) {
  // فقط الخاص
  if (m.isGroup) return
  if (m.fromMe) return

  const settings = global.db.data.settings[conn.user.jid]
  if (!settings?.blockPrivate) return

  // تجاهل المطورين
  if (isOwner || isROwner) return

  const sender = m.sender

  const text = `
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
✧ \`تم حظر رقمك لمنع الاسبام\`
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*

*❏-🤖 الــبـــوت  ⟦𝐒𝐨𝐧𝐠 𝐣𝐢𝐧𝐨⟧*
*❏-🧑‍💻 المـــطور  ⟦𝐀𝐲𝐨𝐮𝐛 ⟧*

*⟐━───━「✨️✨️」━───━⟐*
> لدي أمر من مطوري بحظر كل من يكلمني في الخاص
> لذا سأقوم بحظرك، للتواصل مع المطور سأترك لك رقمه
*⟐━───━「✨️✨️」━───━⟐*

*❏-📲 رقم المطور ⟦ +23595456638 ⟧*
*❏-🛡 قناة دعم البوت*
⟦ https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o ⟧
*❏-📡 جروب تجربة البوت*
⟦ https://chat.whatsapp.com/JbESH7TP2Zb91zAy2Nb94i ⟧

*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
`.trim()

  try {
    await conn.sendMessage(sender, { text })
    await conn.updateBlockStatus(sender, 'block')
  } catch (e) {
    console.error('خطأ في منع الخاص:', e)
  }

  // يمنع أي أوامر بعدها
  return true
}