export async function before(m, { conn, isBotAdmin }) {
    if (!m.isGroup) return
    if (m.fromMe) return
    
    // الوصول لبيانات المستخدم
    let user = global.db.data.users[m.sender]
    
    // إذا كان المستخدم مكتوم والبوت مشرف
    if (user && user.muto) {
        if (!isBotAdmin) return // إذا البوت مش مشرف ما يقدر يحذف

        // حذف الرسالة
        await conn.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: false,
                id: m.key.id,
                participant: m.key.participant || m.sender
            }
        })
    }
}
