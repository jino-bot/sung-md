import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

let handler = async (m, { conn, usedPrefix }) => {
    try {
        // إرسال تفاعل 🪔
        await conn.sendMessage(m.chat, { react: { text: "🪔", key: m.key } });

        let name = await conn.getName(m.sender)
        
        const messageText = `*مـــرحبــــاً بـــكـ/ﻲ يـا ❪${name}❫ في قسم الانمي والمانجا*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *شرح القسم: القسم خاص بالانميات والمانهوات اليابانية والعربية*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *｢🪔┊قسم الانمي والمانهوا┊🪔｣*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
┊🔍┊: \`${usedPrefix}بحث_انمي\`
> بحث وعرض معلومات الانمي.
┊🔎┊: \`${usedPrefix}بحث_مانجا\`
> بحث وعرض معلومات المانجا والانمي.
┊⏸┊: \`${usedPrefix}انمي\`
> تنزيل ومشاهدة حلقات الانمي.
┊📓┊: \`${usedPrefix}مانجا\`
> تنزيل ومشاهدات جميع المانهوات.
┊🎞┊: \`${usedPrefix}ايديت\`
> تنزيل ايديت لشخصية انمي اسطورية.
┊⏯️┊: \`${usedPrefix}استوريهات\`
> تحميل استوري عشوائي للشخصيات.
┊♻️┊: \`${usedPrefix}مختلط\`
> تحميل ايديت عشوائي لشخصية اسطورية.
┊🎥┊: \`${usedPrefix}فلم\`
> البحث عن الافلام والانمي.
┊✨┊: \`${usedPrefix}كرتون_بحث\`
> البحث عن مسلسلات الكرتونات.
┊🌐┊: \`${usedPrefix}سولو_ليفلينغ\`
> مشاهدة مانجا سولو ليفلينغ.
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

        // مسار الصورة المحدد
        const imagePath = path.join(__dirname, '../src/media/Menu4.jpg')

        if (fs.existsSync(imagePath)) {
            await conn.sendMessage(m.chat, {
                image: { url: imagePath },
                caption: messageText
            }, { quoted: m })
        } else {
            await conn.sendMessage(m.chat, { text: messageText }, { quoted: m })
        }

    } catch (err) {
        console.error('❌ Error in Tools Menu:', err)
    }
}

handler.help = ['الادوات']
handler.tags = ['main']
handler.command = /^(قسم18)$/i 

export default handler
