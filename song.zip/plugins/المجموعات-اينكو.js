import fs from 'fs'
import path from 'path'
import Jimp from 'jimp'
import { downloadMediaMessage } from '@whiskeysockets/baileys'

let handler = async (m, { conn, args }) => {
  if (!m.isGroup)
    throw '🚫┇هذا الأمر خاص بالمجموعات فقط!┇'

  const metadata = await conn.groupMetadata(m.chat)
  const participants = metadata.participants || []

  const sender = participants.find(p => p.id === m.sender)
  if (!sender || (sender.admin !== 'admin' && sender.admin !== 'superadmin'))
    throw `
*❍━━━══━━❪🚫❫━━══━━━❍*
*هذا الأمر مخصص للمشرفين فقط*
*❍━━━══━━❪🚫❫━━══━━━❍*
`.trim()

  const option = (args[0] || '').toLowerCase()

  if (!['صورة', 'اسم', 'وصف'].includes(option))
    throw `
*❍━━━══━━❪ℹ️❫━━══━━━❍*
*الاستخدام الصحيح:*
.اينكو صورة (رد على صورة)
.اينكو اسم (نص أو رد)
.اينكو وصف (نص أو رد)
*❍━━━══━━❪ℹ️❫━━══━━━❍*
`.trim()

  /* ───────── صورة ───────── */
  if (option === 'صورة') {
    const q = m.quoted || m
    const mime = q.mimetype || ''

    if (!/image/.test(mime))
      throw `
*❍━━━══━━❪📷❫━━══━━━❍*
*رد على صورة لتغيير صورة المجموعة*
*❍━━━══━━❪📷❫━━══━━━❍*
`.trim()

    const buffer = await q.download()
    const tempDir = './temp'
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir)

    const imgPath = path.join(tempDir, `group_${Date.now()}.jpg`)
    const image = await Jimp.read(buffer)
    await image.writeAsync(imgPath)

    await conn.updateProfilePicture(m.chat, { url: imgPath })
    fs.unlinkSync(imgPath)

    return m.reply(`
*❍━━━══━━❪🖼❫━━══━━━❍*
*تم تغيير صورة المجموعة بنجاح*
*🤖 بواسطة: سونغ*
*❍━━━══━━❪🖼❫━━══━━━❍*
`.trim())
  }

  /* ───────── اسم ───────── */
  if (option === 'اسم') {
    const newName =
      m.quoted?.text || args.slice(1).join(' ')

    if (!newName)
      throw `
*❍━━━══━━❪📝❫━━══━━━❍*
*اكتب الاسم الجديد أو رد على نص*
*❍━━━══━━❪📝❫━━══━━━❍*
`.trim()

    await conn.groupUpdateSubject(m.chat, newName)

    return m.reply(`
*❍━━━══━━❪📝❫━━══━━━❍*
*تم تغيير اسم المجموعة إلى:*
『 ${newName} 』
*❍━━━══━━❪📝❫━━══━━━❍*
`.trim())
  }

  /* ───────── وصف ───────── */
  if (option === 'وصف') {
    const newDesc =
      m.quoted?.text || args.slice(1).join(' ')

    if (!newDesc)
      throw `
*❍━━━══━━❪🗒❫━━══━━━❍*
*اكتب الوصف الجديد أو رد على نص*
*❍━━━══━━❪🗒❫━━══━━━❍*
`.trim()

    await conn.groupUpdateDescription(m.chat, newDesc)

    return m.reply(`
*❍━━━══━━❪🗒❫━━══━━━❍*
*تم تحديث وصف المجموعة بنجاح*
*❍━━━══━━❪🗒❫━━══━━━❍*
`.trim())
  }
}

handler.help = ['اينكو صورة', 'اينكو اسم', 'اينكو وصف']
handler.tags = ['admin']
handler.command = /^اينكو$/i
handler.admin = true
handler.group = true

export default handler