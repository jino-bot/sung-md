import fs from 'fs';
import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

const timeout = 60000;
const poin = 200;

let handler = async (m, { conn, command }) => {
    conn.tekateki = conn.tekateki || {};
    let id = m.chat;

    // معالجة الإجابة عند الضغط على الزر
    if (command.startsWith('اجابة_تاريخ_')) {
        let game = conn.tekateki[id];
        if (!game) return;

        let selectedAnswerIndex = parseInt(command.split('_')[2]);
        let selectedAnswer = game[4][selectedAnswerIndex - 1];
        let isCorrect = game[1].response.trim().toLowerCase() === selectedAnswer.trim().toLowerCase();

        if (isCorrect) {
            let db = global.db.data

    if (!db.users[m.sender]) {
        db.users[m.sender] = { bank: 0, exp: 0, coin: 0, level: 0 }
    }

    // إضافة النقاط (bank)
    db.users[m.sender].bank = (db.users[m.sender].bank || 0) + poin

    // 🔥 حفظ فعلي
    global.db.data = db
            clearTimeout(game[3]);
            delete conn.tekateki[id];

            const interactiveMessage = {
                body: { text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*🎉 إجابتك صحيحة مبروك 🎉*\n*🏦┊الجائزة┊⇇ ${poin} نقطة*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*` },
                footer: { text: '𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
                nativeFlowMessage: {
                    buttons: [{ name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🔄 سؤال تاريخي آخر', id: '.تاريخ' }) }]
                }
            };
            return conn.relayMessage(m.chat, { viewOnceMessage: { message: { interactiveMessage } } }, {});
        } else {
            game[5] -= 1; // تقليل المحاولات
            if (game[5] > 0) {
                return conn.reply(m.chat, `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*إجابتك خاطئة ❌*\n*لديك محاولة واحدة أخرى ⏳*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`, m);
            } else {
                let correct = game[1].response;
                clearTimeout(game[3]);
                delete conn.tekateki[id];

                const interactiveMessage = {
                    body: { text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*إجابتك خاطئة ❌*\n*إنتهت المحاولات المتاحة*\n*✅┊الإجابة هي┊⇇ ${correct}*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*` },
                    footer: { text: '𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
                    nativeFlowMessage: {
                        buttons: [{ name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🔄 حاول مجدداً', id: '.تاريخ' }) }]
                    }
                };
                return conn.relayMessage(m.chat, { viewOnceMessage: { message: { interactiveMessage } } }, {});
            }
        }
    }

    // بدء لعبة جديدة
    if (id in conn.tekateki) {
        return conn.reply(m.chat, '*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*هناك سؤال تاريخي لم يتم حله بعد! ⚠️*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*', conn.tekateki[id][0]);
    }

    let filePath = `./src/game/تاريخ.json`;
    if (!fs.existsSync(filePath)) return conn.reply(m.chat, '❌ ملف أسئلة التاريخ غير موجود!', m);

    let tekateki = JSON.parse(fs.readFileSync(filePath));
    let json = tekateki[Math.floor(Math.random() * tekateki.length)];
    
    // توليد خيارات عشوائية
    let options = [json.response];
    while (options.length < 4) {
        let randomRes = tekateki[Math.floor(Math.random() * tekateki.length)].response;
        if (!options.includes(randomRes)) options.push(randomRes);
    }
    options.sort(() => Math.random() - 0.5);

    const imageUrl = 'https://files.catbox.moe/2wrlj4.jpg';
    const media = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: conn.waUploadToServer });

    const interactiveMessage = {
        body: {
            text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*✧ \`أسئلة تاريخية\` ✧*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n\n*❏- 🏛️ الـسـؤال : ⟦ ${json.question} ⟧*\n\n*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*\n*❏- ⏱️ الـوقـت: ⟦60 ثانـية⟧*\n*❏-🏦 الجائزة: ⟦${poin} نقطة⟧*\n*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*\n> اختر التاريخ أو الإجابة الصحيحة من الأزرار\n> لديك محاولتين فقط\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`,
        },
        footer: { text: '𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
        header: {
            hasMediaAttachment: true,
            imageMessage: media.imageMessage,
        },
        nativeFlowMessage: {
            buttons: options.map((opt, i) => ({
                name: 'quick_reply',
                buttonParamsJson: JSON.stringify({
                    display_text: `🔹 ${opt}`,
                    id: `.اجابة_تاريخ_${i + 1}`
                })
            })),
        },
    };

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: { message: { interactiveMessage } },
    }, { userJid: conn.user.jid, quoted: m });

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    conn.tekateki[id] = [
        msg,
        json, 
        poin,
        setTimeout(async () => {
            if (conn.tekateki[id]) {
                await conn.reply(m.chat, `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*⌛ انتهى الوقت*\n*✅ الإجابة الصحيحة هي: ${json.response}*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`, m);
                delete conn.tekateki[id];
            }
        }, timeout),
        options,
        2 // محاولات
    ];
};

handler.help = ['تاريخ'];
handler.tags = ['game'];
handler.command = /^(تاريخ|اجابة_تاريخ_\d+)$/i;

export default handler;
