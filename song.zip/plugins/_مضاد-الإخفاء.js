import { downloadContentFromMessage } from '@whiskeysockets/baileys'

let handler = m => m
handler.before = async function (m, { conn }) {
    if (!m.isGroup || !m.message) return

    // التأكد من تفعيل خاصية كشف العرض مرة واحدة
    let chat = global.db.data.chats[m.chat]
    if (!chat?.antiver || chat?.isBanned) return

    // إضافة تأخير لمدة ثانيتين لضمان استلام مفاتيح التشفير وفك الرسالة
    await new Promise(resolve => setTimeout(resolve, 2000))

    // محاولة استخراج الرسالة من كل الأماكن الممكنة في نظام واتساب الجديد
    const msg = m.message.viewOnceMessageV2?.message || 
                m.message.viewOnceMessage?.message || 
                m.message.viewOnceMessageV2Extension?.message

    // إذا لم يجد الرسالة بعد التأخير، يتوقف لتجنب الخطأ
    if (!msg) return

    const type = Object.keys(msg)[0]
    if (!['imageMessage', 'videoMessage', 'audioMessage'].includes(type)) return

    let buffer
    try {
        // تحميل المحتوى
        const stream = await downloadContentFromMessage(
            msg[type], 
            type === 'imageMessage' ? 'image' : type === 'videoMessage' ? 'video' : 'audio'
        )
        let chunks = []
        for await (const chunk of stream) {
            chunks.push(chunk)
        }
        buffer = Buffer.concat(chunks)
    } catch (e) {
        console.error('فشل في تحميل الوسائط المخفية:', e)
        return
    }

    const name = m.pushName || 'غير معروف'
    const userTag = `@${m.sender.split('@')[0]}`

    const caption = `
*❐═━━━═╊⊰ كشف المستور ⊱╉═━━━═❐*
👤 *❏- العضو:* 『${name}』
📦 *❏- النوع:* ${type === 'imageMessage' ? 'صورة 📷' : type === 'videoMessage' ? 'فيديو 🎥' : 'تسجيل صوتي 🎤'}
*❐═━━━═╊⊰🐍⊱╉═━━━═❐*
> *تم فك التشفير وإعادة الإرسال بنجاح ✅*
    `.trim()

    // إرسال الصورة أو الفيديو
    if (type === 'imageMessage' || type === 'videoMessage') {
        return conn.sendMessage(m.chat, { 
            [type.replace('Message', '')]: buffer, 
            caption, 
            mentions: [m.sender] 
        }, { quoted: m })
    }

    // إرسال المقطع الصوتي
    if (type === 'audioMessage') {
        await conn.sendMessage(m.chat, { text: caption, mentions: [m.sender] }, { quoted: m })
        return conn.sendMessage(m.chat, { 
            audio: buffer, 
            mimetype: 'audio/mpeg', 
            ptt: true 
        }, { quoted: m })
    }
}

export default handler
