import fs from 'fs'
import path from 'path'
import process from 'process'

let handler = async (m, { conn, command }) => {

  // 🗂️ تنظيف الجلسة
  if (command === 'تنظيف_session') {
    try {
      const sessionPath = './sessions'
      fs.rmSync(sessionPath, { recursive: true, force: true })
      return m.reply('✅ تم تنظيف ملف الجلسة بنجاح.\n🔄 أعد تشغيل البوت.')
    } catch (e) {
      return m.reply('❌ فشل تنظيف ملف الجلسة.')
    }
  }

  // 🧠 تنظيف قاعدة البيانات (تفريغ بدون حذف)
  if (command === 'تنظيف_db') {
    try {
      global.db.data = {
        users: {},
        chats: {},
        settings: {},
        stats: {}
      }
      await global.db.write()
      return m.reply('✅ تم تنظيف قاعدة البيانات بدون حذفها.')
    } catch (e) {
      return m.reply('❌ حدث خطأ أثناء تنظيف قاعدة البيانات.')
    }
  }

  // ♻️ إعادة ضبط قاعدة البيانات
  // ♻️ إعادة ضبط قاعدة البيانات (صحيح 100%)
if (command === 'تنظيف_resetdb') {
  try {
    // 1️⃣ تفريغ البيانات من الذاكرة
    global.db.data = {
      users: {},
      chats: {},
      settings: {},
      stats: {}
    }

    // 2️⃣ حفظ القاعدة الفارغة
    await global.db.write()

    // 3️⃣ رسالة + إعادة تشغيل
    await m.reply(
      '♻️ تم إعادة ضبط قاعدة البيانات بالكامل.\n' +
      '🔄 سيتم الآن إعادة تشغيل البوت...'
    )

    // 4️⃣ إعادة تشغيل
    process.exit(0)

  } catch (e) {
    console.error(e)
    return m.reply('❌ فشل إعادة ضبط قاعدة البيانات.')
  }
}
  // 🔄 إعادة تشغيل البوت
  if (command === 'تنظيف_restart') {
    await m.reply('🔄 جاري إعادة تشغيل البوت...')
    process.exit(0)
  }
}

handler.command = [
  'تنظيف_session',
  'تنظيف_db',
  'تنظيف_resetdb',
  'تنظيف_restart'
]

handler.owner = true

export default handler
