import WAMessageStubType from '@whiskeysockets/baileys'

export async function before(m, { conn }) {
  if (!m.isGroup) return
  if (!m.messageStubType) return

  const chat = global.db.data.chats[m.chat]
  if (!chat?.protect) return

  // ===== منع اللوب =====
  if (chat.protectLock) return

  // تجاهل رسائل البوت نفسه
  if (m.sender === conn.user.jid) return

  const usuario = `@${m.sender.split('@')[0]}`
  const mentionedSender = [m.sender]

  // ===== معلومات القناة =====
  const channelInfo = {
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363416870755391@newsletter",
      newsletterName: "𝐒𝐔𝐍𝐆 ꒰🐉⃝⃕꒱𝐔𝐏𝐃𝐀𝐓𝐄",
      serverMessageId: -1
    },
    isForwarded: true,
    forwardingScore: 999,
    mentionedJid: mentionedSender
  }

  const fkontak = {
    key: {
      participants: "0@s.whatsapp.net",
      remoteJid: "status@broadcast",
      fromMe: false,
      id: "Protect"
    },
    message: {
      contactMessage: {
        vcard: `BEGIN:VCARD
VERSION:3.0
N:Protect;Bot;;;
FN:Protect
item1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}
item1.X-ABLabel:Ponsel
END:VCARD`
      }
    },
    participant: "0@s.whatsapp.net"
  }

  // ===== رسائل الحماية =====
  const warnName = `
*❐═━━━═╊⊰🛡️⊱╉═━━━═❐*
*❐⇇ المجموعة محمية*
*❐⇇ ❌ لا يمكن تغيير اسم المجموعة*
*❐⇇ 👤 بواسطة ↜ ❪${usuario}❫*
*❐═━━━═╊⊰🛡️⊱╉═━━━═❐*`.trim()

  const warnDesc = `
*❐═━━━═╊⊰🛡️⊱╉═━━━═❐*
*❐⇇ المجموعة محمية*
*❐⇇ ❌ لا يمكن تغيير وصف المجموعة*
*❐⇇ 👤 بواسطة ↜ ❪${usuario}❫*
*❐═━━━═╊⊰🛡️⊱╉═━━━═❐*`.trim()

  const warnPhoto = `
*❐═━━━═╊⊰🛡️⊱╉═━━━═❐*
*❐⇇ المجموعة محمية*
*❐⇇ ❌ لا يمكن تغيير صورة المجموعة*
*❐⇇ 👤 بواسطة ↜ ❪${usuario}❫*
*❐═━━━═╊⊰🛡️⊱╉═━━━═❐*`.trim()

  // ===== التنفيذ =====
  try {
    chat.protectLock = true

    // تغيير اسم المجموعة
    if (m.messageStubType === 21 && chat.groupState?.name) {
      await conn.groupUpdateSubject(m.chat, chat.groupState.name)
      await conn.sendMessage(m.chat, {
        text: warnName,
        contextInfo: channelInfo
      }, { quoted: fkontak })
    }

    // تغيير صورة المجموعة
    else if (m.messageStubType === 22 && chat.groupState?.photo) {
      await conn.updateProfilePicture(m.chat, { url: chat.groupState.photo })
      await conn.sendMessage(m.chat, {
        text: warnPhoto,
        contextInfo: channelInfo
      }, { quoted: fkontak })
    }

    // تغيير وصف المجموعة
    else if (m.messageStubType === 24) {
      await conn.groupUpdateDescription(m.chat, chat.groupState?.desc || '')
      await conn.sendMessage(m.chat, {
        text: warnDesc,
        contextInfo: channelInfo
      }, { quoted: fkontak })
    }

  } catch (e) {
    console.error('Protect error:', e)
  }

  // ===== فك القفل =====
  setTimeout(() => {
    chat.protectLock = false
  }, 4000)
}