import { sticker } from '../lib/sticker.js'

let handler = async (m, { conn }) => {

  if (!m.quoted)
    throw '🖼️┇لازم ترد على صورة عشان أحولها لملصق!┇😅'

  let mime = m.quoted.mimetype || ''
  if (!/image/.test(mime))
    throw '❌┇الرسالة اللي رديت عليها مو صورة!┇🚫'

  let img = await m.quoted.download()
  if (!img)
    throw '📥┇فشل تحميل الصورة، حاول مرة ثانية!┇⚠️'

  const packname = 'Song Bot'
  const author = 'Developer Ayoub'

  let stiker = await sticker(img, false, packname, author)

  if (!stiker)
    throw '❌┇فشل تحويل الصورة إلى ملصق!┇🚨'

  await conn.sendMessage(m.chat, {
    sticker: stiker
  }, { quoted: m })
}

handler.help = ['لملصق ']
handler.tags = ['sticker']
handler.command = ['لملصق', 'لاستكر', 'تحويل_ملصق']

export default handler