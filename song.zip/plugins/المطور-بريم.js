//import db from '../lib/database.js'

let handler = async (m, { conn, usedPrefix, command }) => {

  // لازم يكون في رد
  if (!m.quoted) {
    throw `✳️ *رد على رسالة الشخص*\n\n📌 مثال:\n${usedPrefix + command} (بالرد)`
  }

  let who = m.quoted.sender
  let user = global.db.data.users[who]
  if (!user) throw '❌ المستخدم غير موجود في قاعدة البيانات'

  let number = who.split('@')[0]

  // تحقق إذا كان بريميام مسبقاً
  if (global.prems.includes(number)) {
    throw '⚠️ هذا المستخدم بريميام بالفعل'
  }

  // إضافة للبريميام
  global.prems.push(number)

  await conn.reply(
    m.chat,
    `
✅ *تمت الإضافة إلى البريميام*

👤 المستخدم: ${user.name || 'غير معروف'}
📞 الرقم: @${number}

🎉 الآن أصبح مستخدم بريميام
    `.trim(),
    m,
    { mentions: [who] }
  )
}

handler.help = ['addprem (بالرد)']
handler.tags = ['owner']
handler.command = ['addprem', 'بريم']

handler.group = true
handler.rowner = true

export default handler