import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

let handler = async (m, { conn, usedPrefix }) => {
    await conn.sendMessage(m.chat, { react: { text: "🎮", key: m.key } });
    let name = await conn.getName(m.sender)
    
    const messageText = `*مـــرحبــــاً بـــكـ/ﻲ يـا ❪${name}❫ في قسم الألعاب*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *شرح القسم: يقدم القسم ألعاب تفاعلية تقضي على الملل وتجمع النقاط*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *｢🎮┊قسم الألعاب والتحدي┊🎮｣*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
┊❌┊: \`${usedPrefix}اكس_او\` | لعبة XO الشهيرة بين لاعبين.
┊🤖┊: \`${usedPrefix}اكس_بوت\` | تحدى الذكاء الاصطناعي في XO.
┊📈┊: \`${usedPrefix}تداول\` | خاطر بنقاطك في سوق الأسهم.
┊✂️┊: \`${usedPrefix}جاجاكين_بوت\` | حجر ورقة مقص ضد البوت.
┊💱┊: \`${usedPrefix}روليت\` | الرهان على المبالغ.
┊🎰┊: \`${usedPrefix}كازينو\` | جرب حظك في كازينو الماكينة.
┊🗡️┊: \`${usedPrefix}رياضيات\` | تحدي الذكاء في الحسابات.
┊📦┊: \`${usedPrefix}قنبلة\` | لعبة التحدي للصمود على الصناديق.
┊🧞┊: \`${usedPrefix}مارد\` |انا المارد سوف اقرأ عقلك.
┊❤‍🔥┊: \`${usedPrefix}قلوب\` |لعبة القلوب للإدارة الألعاب الجماعية.
┊🔢┊: \`${usedPrefix}تخمين\` | لعبة تخمين الرقم الصحيح
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

    const imagePath = path.join(__dirname, '../src/media/Menu4.jpg')
    await conn.sendMessage(m.chat, { image: fs.existsSync(imagePath) ? fs.readFileSync(imagePath) : { url: 'https://qu.ax/yXYsp' }, caption: messageText }, { quoted: m })
}
handler.command = /^(قسم7)$/i
export default handler
