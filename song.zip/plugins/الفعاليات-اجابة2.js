import similarity from 'similarity'
const threshold = 0.72

let handler = m => m
handler.before = async function (m) {
    let id = m.chat
    this.tekateki = this.tekateki ? this.tekateki : {}
    
    if (!(id in this.tekateki) || !m.quoted || !m.quoted.fromMe) return !0

    // التحقق من أن الرد موجه لرسالة اللعبة
    if (m.quoted.id == this.tekateki[id][0].id || (this.tekateki[id][0].key && m.quoted.id == this.tekateki[id][0].key.id)) {
        let json = JSON.parse(JSON.stringify(this.tekateki[id][1]))
        let reward = this.tekateki[id][2]

        // حالة الإجابة الصحيحة
        if (m.text.toLowerCase().trim() == json.response.toLowerCase().trim()) {
            let db = global.db.data;

// تأكد من وجود المستخدم
if (!db.users[m.sender]) {
    db.users[m.sender] = {
        bank: 0,
        exp: 0,
        coin: 0,
        level: 0
    };
}

// إضافة النقاط
db.users[m.sender].bank = (db.users[m.sender].bank || 0) + reward;

// حفظ
global.db.data = db;
            
            await m.reply(`*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*🎉 إجابتك صحيحة مبروك 🎉*\n*🏦┊الجائزة┊⇇ 150 نقطة*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`)
            
            clearTimeout(this.tekateki[id][3])
            delete this.tekateki[id]

        // حالة الإجابة القريبة (التشابه)
        } else if (similarity(m.text.toLowerCase(), json.response.toLowerCase().trim()) >= threshold) {
            m.reply(`*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*إجابتك قريبة جداً! 🤏*\n*ركز قليلاً وأعد المحاولة ✨*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`)
        
        // حالة الإجابة الخاطئة
        } else {
            m.reply(`*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*إجابة خاطئة ❌*\n*حاول مرة أخرى قبل انتهاء الوقت!*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`)
        }
    }
    return !0
}

handler.exp = 0

export default handler
