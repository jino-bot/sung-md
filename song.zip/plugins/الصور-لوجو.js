import axios from "axios"
import fetch from "node-fetch"
import cheerio from 'cheerio'

let handler = async (m, {
    conn,
    args,
    usedPrefix,
    text,
    command
}) => {
    // التحقق من وجود نص
    if (!text) throw `هذا الامر خاص بعمل شعارات باسمك \nمثال:\n*${usedPrefix + command}* tarboo bot`
    
    try {
        // إرسال رسالة انتظار (تأكد أن متغير wait معرف عالمياً في بوتك أو استبدله بنص)
        await m.reply('_جاري تصميم اللوجو الخاص بك..._')
        
        let res = await BrandCrowd(text)
        
        if (!res || res.length === 0) throw "❌ لم يتم العثور على نتائج لهذا الاسم."
        
        // اختيار صورة عشوائية من النتائج
        let rdm = res[Math.floor(Math.random() * res.length)]
        
        await conn.sendMessage(m.chat, {
            image: {
                url: rdm
            }, 
            caption: `✨ النتيجة لاسم: *${text}*`
        }, {
            quoted: m
        })

    } catch (e) {
        console.error(e)
        throw "⚠️ حدث خطأ أثناء جلب البيانات، تأكد من اتصال الإنترنت أو حاول لاحقاً."
    }
}

handler.help = ["لوجو"]
handler.tags = ["logo"]
handler.command = /^لوجو$/i

export default handler

/* دالة جلب الشعارات باستخدام Cheerio بدلاً من JSDOM */
async function BrandCrowd(query) {
    try {
        let res = await fetch('https://www.brandcrowd.com/maker/logos/page1?Text=' + encodeURIComponent(query) + '&TextChanged=true&SearchText&KeywordChanged=true&LogoStyle=0&FontStyles&Colors&FilterByTags')
        let html = await res.text()
        
        // تحميل الصفحة باستخدام cheerio
        const $ = cheerio.load(html)
        let img = []
        
        // البحث عن جميع عناصر img واستخراج الروابط
        $('img').each((i, el) => {
            let src = $(el).attr('src')
            if (src && src.startsWith('https://dynamic.brandcrowd.com')) {
                img.push(src)
            }
        })
        
        return img
    } catch (e) {
        console.error("Error in BrandCrowd function:", e)
        return []
    }
}
