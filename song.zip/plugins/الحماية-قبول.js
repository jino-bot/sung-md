let handler = async (m, { args, usedPrefix, command }) => {
    let chat = global.db.data.chats[m.chat]

    // عرض الحالة
    if (!args[0]) {
        let status = chat.autoAceptar ? 'مفعل ✅' : 'معطل ❌'
        return m.reply(
            `*🛂 القبول التلقائي لطلبات الانضمام*\n\n` +
            `• الحالة: ${status}\n\n` +
            `*الاستخدام:*\n` +
            `• ${usedPrefix + command} on\n` +
            `• ${usedPrefix + command} off`
        )
    }

    // تفعيل
    if (args[0] === 'on') {
        if (chat.autoAceptar) return m.reply('⚠️ القبول التلقائي مفعل بالفعل.')
        chat.autoAceptar = true
        return m.reply('✅ تم تفعيل القبول التلقائي لطلبات الانضمام.')
    }

    // تعطيل
    if (args[0] === 'off') {
        if (!chat.autoAceptar) return m.reply('⚠️ القبول التلقائي معطل بالفعل.')
        chat.autoAceptar = false
        return m.reply('❌ تم تعطيل القبول التلقائي لطلبات الانضمام.')
    }

    // خطأ
    return m.reply(
        `❌ أمر غير صحيح\n\n` +
        `استخدم:\n` +
        `• ${usedPrefix + command} on\n` +
        `• ${usedPrefix + command} off`
    )
}

handler.help = ['قبول']
handler.tags = ['group']
handler.command = ['قبول', 'autoaceptar', 'joinauto']

handler.group = true
handler.admin = true

export default handler