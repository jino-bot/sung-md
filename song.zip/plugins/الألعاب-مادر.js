import axios from "axios";
import pkg from "@whiskeysockets/baileys";
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg;

const api_obito = "https://mr-obito-api.vercel.app/api";

let handler = async function (m, { text, conn, usedPrefix }) {
  if (!conn.aki) conn.aki = {};
  const sessionKey = `${m.chat}-${m.sender}`;
  const session = conn.aki[sessionKey];

  // القائمة الرئيسية (عند كتابة .مارد بدون نص)
  if (!text) {
    const buttons = [
      {
        name: "quick_reply",
        buttonParamsJson: JSON.stringify({ display_text: "🎮 بدء التحدي", id: ".مارد ابدا" }),
      },
      {
        name: "quick_reply",
        buttonParamsJson: JSON.stringify({ display_text: "📘 المساعدة", id: ".مارد المساعدة" }),
      },
    ];

    const msg = generateWAMessageFromContent(
      m.chat,
      {
        viewOnceMessage: {
          message: {
            interactiveMessage: proto.Message.InteractiveMessage.create({
              body: proto.Message.InteractiveMessage.Body.create({
                text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*أهلاً بك يا بشر في عرين المارد.. 🧞‍♂️*\n*هل تجرؤ على تحدي ذكائي والتفكير في شخصية؟*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`,
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
                text: "𝚂𝙾𝙽𝙶 𝙱𝙾𝚃 • 𝙰𝙺𝙸𝙽𝙰𝚃𝙾𝚁",
              }),
              header: proto.Message.InteractiveMessage.Header.create({
                hasMediaAttachment: false,
                title: "✧ `تحدي المارد الأزرق` ✧",
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons,
              }),
            }),
          },
        },
      },
      { userJid: conn.user.jid, quoted: m }
    );

    return await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
  }

  // شرح المساعدة
  if (text === "المساعدة") {
    return conn.reply(m.chat, `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*📘 دليل أوامر المارد :*\n\n*- ${usedPrefix}مارد ابدا ← بدء اللعبة*\n*- ${usedPrefix}مارد حذف ← إلغاء التحدي*\n*- ${usedPrefix}مارد رجوع ← السؤال السابق*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`, m);
  }

  // بدء اللعبة
  if (text === "ابدا") {
    try {
      const { data } = await axios.post(`${api_obito}/akinator_start`);
      if (!data.session || !data.signature) return m.reply("🧞‍♂️: يبدو أن طاقتي ضعيفة الآن، حاول لاحقاً.");

      conn.aki[sessionKey] = {
        session: data.session,
        signature: data.signature,
        step: 0,
        progression: 0,
      };

      return sendQuestion(m.chat, data.question, data.akitude_url || null, m);
    } catch (err) {
      return m.reply("⚠️ حدث خطأ في استدعاء المارد.");
    }
  }

  // حذف الجلسة
  if (text === "حذف") {
    if (!session) return m.reply("🧞‍♂️: لا يوجد تحدٍ قائم لأقوم بإلغائه!");
    delete conn.aki[sessionKey];
    return conn.reply(m.chat, `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*تم إنهاء التحدي بنجاح 🧞‍♂️*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅╔*`, m);
  }

  // الرجوع للسؤال السابق
  if (text === "رجوع") {
    if (!session) return m.reply("🧞‍♂️: لا توجد جلسة نشطة.");
    try {
      const { data } = await axios.post(`${api_obito}/akinator_back`, {
        session: session.session,
        signature: session.signature,
        step: session.step,
        progression: session.progression,
        cm: "false",
      });
      conn.aki[sessionKey].step = data.step;
      conn.aki[sessionKey].progression = data.progression;
      return sendQuestion(m.chat, data.question, data.akitude_url || null, m);
    } catch (err) {
      return m.reply("🧞‍♂️: لا يمكنني العودة أكثر من ذلك.");
    }
  }

  // معالجة الإجابات
  const answers = { "نعم": 0, "لا": 1, "لا أعرف": 2, "ربما": 3, "ربما لا": 4 };
  if (answers.hasOwnProperty(text)) {
    if (!session) return m.reply("🧞‍♂️: انتهى التحدي، ابدأ من جديد بـ .مارد ابدا");

    try {
      const { data } = await axios.post(`${api_obito}/akinator_answer`, {
        session: session.session,
        signature: session.signature,
        step: session.step,
        progression: session.progression,
        answer: answers[text],
        cm: "false",
        sid: "NaN",
        question_filter: "string",
      });

      // إذا وجد المارد الشخصية
      if (data.name_proposition) {
        delete conn.aki[sessionKey];
        
        const interactiveMessage = {
          body: { text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*🧞‍♂️ لقد قرأت أفكارك! الشخصية هي:*\n\n*📌 الاسم : ⟦ ${data.name_proposition} ⟧*\n*📝 الوصف : ⟦ ${data.description_proposition || "لا يوجد وصف"} ⟧*\n\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*` },
          footer: { text: "𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃" },
          header: { 
            hasMediaAttachment: true, 
            imageMessage: (await prepareWAMessageMedia({ image: { url: data.photo } }, { upload: conn.waUploadToServer })).imageMessage 
          },
          nativeFlowMessage: {
            buttons: [{ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔄 تحدي جديد", id: ".مارد ابدا" }) }]
          }
        };

        let msg = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { interactiveMessage } } }, { userJid: conn.user.jid, quoted: m });
        return await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
      }

      conn.aki[sessionKey].step = data.step;
      conn.aki[sessionKey].progression = data.progression;
      return sendQuestion(m.chat, data.question, data.akitude_url || null, m);
    } catch (err) {
      return m.reply("⚠️ حدث خطأ أثناء قراءة أفكارك.");
    }
  }

  // دالة إرسال الأسئلة
  async function sendQuestion(jid, question, imgUrl, quoted) {
    const buttons = [
      { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "✅ نـعـم", id: ".مارد نعم" }) },
      { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "❌ لا", id: ".مارد لا" }) },
      { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🤔 لا أعرف", id: ".مارد لا أعرف" }) },
      { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "❓ ربما", id: ".مارد ربما" }) },
      { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "📉 ربما لا", id: ".مارد ربما لا" }) },
      { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔙 تراجع", id: ".مارد رجوع" }) },
      { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🗑️ إلغاء", id: ".مارد حذف" }) },
    ];

    const media = imgUrl ? await prepareWAMessageMedia({ image: { url: imgUrl } }, { upload: conn.waUploadToServer }) : null;

    const msg = generateWAMessageFromContent(jid, {
      viewOnceMessage: {
        message: {
          interactiveMessage: proto.Message.InteractiveMessage.create({
            body: proto.Message.InteractiveMessage.Body.create({
              text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*🧞‍♂️ المارد يسألك :*\n\n*❏- الـسـؤال : ⟦ ${question} ⟧*\n\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`,
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({ text: "جـاري قـراءة الـعـقـول....🧞‍♂️" }),
            header: proto.Message.InteractiveMessage.Header.create({
              ...(media ? { hasMediaAttachment: true, ...media } : { hasMediaAttachment: false }),
              title: "✧ `تحدي الذكاء مع المارد` ✧",
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons }),
          }),
        },
      },
    }, { userJid: conn.user.jid, quoted });

    return await conn.relayMessage(jid, msg.message, { messageId: msg.key.id });
  }
};

handler.help = ['مارد'];
handler.tags = ['game'];
handler.command = /^مارد$/i;

export default handler;
