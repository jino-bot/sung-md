import { prepareWAMessageMedia, generateWAMessageFromContent } from "@whiskeysockets/baileys";

// دالة مساعدة لربط الحروف بالستايل
const mapStyle = (...chars) => {
    const alphabet = 'abcdefghijklmnopqrstuvwxyz'.split('');
    return Object.fromEntries(alphabet.map((char, i) => [char, chars[i]]));
};

const styles = [
    { name: "𝒶𝓃𝒹𝓎 𝓈𝒸𝓇𝒾𝓅𝓉", map: mapStyle('𝒶','𝒷','𝒸','𝒹','𝑒','𝒻','𝒼','𝒽','𝒾','𝒿','𝓀','𝓁','𝓂','𝓃','𝑜','𝓅','𝓆','𝓇','𝓈','𝓉','𝓊','𝓋','𝓌','𝓍','𝓎','𝓏') },
    { name: "𝘐𝘵𝘢𝘭𝘪𝘤", map: mapStyle('𝘢','𝘣','𝘤','𝘥','𝘦','𝘧','𝘨','𝘩','𝘪','𝘫','𝘬','𝘭','𝘮','𝘯','𝘰','𝘱','𝘲','𝘳','𝘴','𝘵','𝘶','ｖ','𝘸','𝘹','𝘺','𝘻') },
    { name: "𝕯𝖔𝖚𝖇𝖑𝖊", map: mapStyle('𝕒','𝕓','𝕔','𝕕','𝕖','𝕗','𝕘','𝕙','𝕚','𝕛','𝕜','𝕝','𝕞','𝕟','𝕠','𝕡','𝕢','𝕣','𝕤','𝕥','𝕦','𝕧','𝕨','𝕩','𝕪','𝕫') },
    { name: "𝖇𝖑𝖆𝖈𝖐𝖑𝖊𝖙𝖙𝖊𝖗", map: mapStyle('𝖆','𝖇','▖','𝖉','𝖊','𝖋','𝖌','𝖍','𝖎','𝖏','𝖐','𝖑','𝖒','𝖓','𝖔','𝖕','𝖖','𝖗','𝖘','𝖙','𝖚','𝖛','𝖜','𝖝','𝖞','𝖟') },
    { name: "𝙈𝙤𝙣𝙤𝙨𝙥𝙖𝙘𝙚", map: mapStyle('𝙖','𝙖','𝙘','𝙙','𝙚','𝙛','𝙜','𝙝','𝙞','𝙟','𝙠','𝙡','𝙢','𝙣','𝙤','𝙥','𝙦','𝙧','𝙨','𝙩','𝙪','𝙫','𝙬','𝙭','𝙮','𝙯') },
    { name: "𝐁𝐨𝐥𝐝", map: mapStyle('𝐚','𝐛','𝐜','𝐝','𝐞','𝐟','𝐠','𝐡','𝐢','𝐣','𝐤','𝐥','𝐦','𝐧','进','𝐩','𝐪','𝐫','𝐬','𝐭','𝐮','𝐯','𝐰','𝐱','𝐲','𝐳') },
    { name: "𝑩𝒐𝒍𝒅 𝑰𝒕𝒂𝒍𝒊𝒄", map: mapStyle('𝑨','𝑩','𝑪','𝑫','𝑬','𝑭','𝑮','𝑯','𝑰','𝑱','𝑲','𝑳','𝑴','𝑵','𝑶','𝑷','𝑸','𝑹','𝑺','𝑻','𝑼','𝑽','𝑾','𝑿','𝒀','𝒁') },
    { name: "𝓟𝓮𝓻𝓲𝓯𝓽", map: mapStyle('𝓪','𝓫','𝓬','𝓭','𝓮','𝓯','𝓰','𝓱','𝓲','𝓳','𝓴','𝓵','𝓶','𝓷','𝓸','𝓹','𝓺','𝓻','𝓼','𝓽','𝓾','𝓿','𝔀','𝔁','𝔂','𝔃') },
    { name: "『v』『o』『g』『u』", map: mapStyle('『a』','『b』','『c』','『d』','『e』','『f』','『g』','『h』','『i』','『j』','『k』','『l』','『m』','『n』','『o』','『p』','『q』','『r』','『s』','『t』','『u』','『v』','『w』','『x』','『y』','『z』') },
    { name: "𝐒𝐞𝐫𝐢𝐟", map: mapStyle('𝐀','𝐁','𝐂','𝐃','𝐄','𝐅','𝐆','𝐇','𝐈','𝐉','𝐊','𝐋','𝐌','𝐍','𝐎','𝐏','𝐐','𝐑','𝐒','𝐓','𝐔','𝐕','𝐖','𝐗','𝐘','𝐉') },
    { name: "🅑🅞🅧🅔🅓", map: mapStyle('🅐','🅑','🅒','🅓','🅔','🅕','🅖','🅗','🅘','🅙','🅚','🅛','🅜','🅝','🅞','🅟','🅠','🅡','🅢','🅣','🅤','🅥','🅦','🅧','🅨','🅩') }
];

let handler = async (m, { conn, text, command }) => {
    // جلب النص سواء من الرسالة أو الرد
    let content = text ? text : (m.quoted && m.quoted.text ? m.quoted.text : '');
    if (!content) return m.reply(`*⚠️ يرجى كتابة نص بعد الأمر أو الرد على رسالة لزخرفتها.*\n*مثال: .خط Song Bot*`);

    // إذا كان المستخدم قد اختار نوع الخط (سيتم إرسال اسم الستايل في النص المخفي للزر)
    let selectedStyle = styles.find(s => content.startsWith(s.name + " | "));
    if (selectedStyle) {
        let originalText = content.replace(selectedStyle.name + " | ", "");
        let stylizedText = originalText.replace(/[a-z]/gi, char => {
            let lower = char.toLowerCase();
            return selectedStyle.map[lower] || char;
        });
        return m.reply(stylizedText);
    }

    // عرض قائمة الأزرار
    const rows = styles.map(style => ({
        header: style.name,
        title: "تطبيق هذا الستايل",
        description: `زخرفة النص بأسلوب ${style.name}`,
        id: `.${command} ${style.name} | ${content}`
    }));

    const interactiveMessage = {
        body: { text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n\`˼🎨˹ مـزخـرف الـنـصـوص\`↶\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n\n📝 *النص المراد زخرفته:* \n『 ${content} 』\n\n*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*\n> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*` },
        footer: { text: "𝙎𝙊𝙉𝙂 𝘽𝙊𝙏 𝙀𝘿𝙄𝙏𝙄𝙊𝙉" },
        header: { title: "تزيين الخطوط الإنجليزية", hasMediaAttachment: false },
        nativeFlowMessage: {
            buttons: [{
                name: 'single_select',
                buttonParamsJson: JSON.stringify({
                    title: "✨ اختر الزخرفة من هنا",
                    sections: [{ title: "قائمة الخطوط المتاحة", rows }]
                })
            }]
        }
    };

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: { message: { interactiveMessage } }
    }, { userJid: conn.user.jid, quoted: m });

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
};

handler.help = ['خط'];
handler.tags = ['tools'];
handler.command = /^(خط|زخرف)$/i;

export default handler;
