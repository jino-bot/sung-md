import { exec } from 'child_process'
import fs from 'fs'
import path from 'path'

let handler = async (m, { conn }) => {
  if (!m.quoted)
    throw '🎞️┇لازم ترد على فيديو قصير أو GIF عشان أحوله لملصق متحرك!┇😅'

  let mime = m.quoted.mimetype || ''
  if (!/video|gif/.test(mime))
    throw '❌┇الرسالة اللي رديت عليها مو فيديو أو GIF!┇🚫'

  const tempDir = './temp'
  if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true })

  const input = path.join(tempDir, `${Date.now()}.mp4`)
  const output = path.join(tempDir, `${Date.now()}.webp`)

  let media = await m.quoted.download()
  if (!media)
    throw '📥┇فشل تحميل الفيديو، حاول مرة ثانية!┇⚠️'

  fs.writeFileSync(input, media)

  await conn.sendMessage(m.chat, {
    text: '⏳ *جاري تحويل المقطع إلى ملصق متحرك...*'
  }, { quoted: m })

  // تحويل إلى WebP متحرك (متوافق مع واتساب)
  exec(
    `ffmpeg -i "${input}" -vf "scale=512:512:force_original_aspect_ratio=decrease,fps=15,pad=512:512:-1:-1:color=white@0.0" -loop 0 -an -vsync 0 "${output}"`,
    async err => {
      if (err || !fs.existsSync(output)) {
        console.error(err)
        return conn.sendMessage(m.chat, {
          text: '❌ فشل تحويل المقطع إلى ملصق متحرك!'
        }, { quoted: m })
      }

      try {
        await conn.sendMessage(m.chat, {
          sticker: fs.readFileSync(output)
        }, { quoted: m })
      } finally {
        try {
          fs.unlinkSync(input)
          fs.unlinkSync(output)
        } catch {}
      }
    }
  )
}

handler.help = ['لمتحرك']
handler.tags = ['sticker']
handler.command = ['لمتحرك', 'متحرك', 'gif2sticker']

export default handler