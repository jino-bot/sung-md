import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import pkg from '@whiskeysockets/baileys'

const { generateWAMessageFromContent, proto } = pkg

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const REPORTS_FILE = path.join(__dirname, '../src/JSON/البلاغات.json')
const DEVELOPER_JID = '23595456638@s.whatsapp.net'

let handler = async (m, { conn, text, usedPrefix, command }) => {

  /* ====== تجهيز التخزين ====== */
  let dir = path.dirname(REPORTS_FILE)
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
  if (!fs.existsSync(REPORTS_FILE))
    fs.writeFileSync(REPORTS_FILE, JSON.stringify([], null, 2))

  /* ====== بدون نص ====== */
  if (!text) {
    const menu =
`*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
*❒ ⇇ قسم الإبلاغ عن مشكلة 🚨*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*

✏️ *اكتب بلاغك بالتفصيل*
مثال:
\`${usedPrefix + command} تم حظري من البوت بدون سبب\`

*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

    return m.reply(menu)
  }

  if (text.length < 10)
    return m.reply('❌ البلاغ قصير جدًا')
  if (text.length > 1500)
    return m.reply('❌ البلاغ طويل جدًا')

  /* ====== حفظ البلاغ ====== */
  let reports = JSON.parse(fs.readFileSync(REPORTS_FILE))
  reports.push({
    user: m.sender,
    name: m.pushName || 'مستخدم',
    chat: m.chat,
    text,
    time: new Date().toLocaleString()
  })
  fs.writeFileSync(REPORTS_FILE, JSON.stringify(reports, null, 2))

  /* ====== رسالة المستخدم بالأزرار المتقدمة ====== */
  const userMsg = generateWAMessageFromContent(
    m.chat,
    proto.Message.fromObject({
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "🚨 تم إرسال بلاغك بنجاح",
              subtitle: "Song Bot"
            },
            body: {
              text:
`*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
✅ *شكراً لك، تم استلام البلاغ*
سيتم مراجعته في أقرب وقت

*❐═━━━═╊⊰🐲⊱╉═━━━═❐*`
            },
            footer: { text: "BY | SONG BOT" },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "cta_url",
                  buttonParamsJson: JSON.stringify({
                    display_text: "📢┇قناة البوت┇📢",
                    url: "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o",
                    merchant_url: "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o"
                  })
                },
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "👑┇مطور البوت┇👑",
                    id: ".مطور"
                  })
                }
              ]
            }
          }
        }
      }
    }),
    {}
  )

  await conn.relayMessage(m.chat, userMsg.message, { messageId: userMsg.key.id })

  /* ====== تقرير المطور ====== */
  const devReport =
`*❍━━══━━✦🚨✦━━══━━❍*
*┊     بلاغ جديد     ┊*
*❍━━══━━✦🚨✦━━══━━❍*

👤 المستخدم:
wa.me/${m.sender.split('@')[0]}
(${m.pushName || 'بدون اسم'})

📝 البلاغ:
${text}

💬 الدردشة:
${m.chat}

🕒 التاريخ:
${new Date().toLocaleString()}

*❍━━══━━✦🚨✦━━══━━❍*`

  await conn.sendMessage(DEVELOPER_JID, { text: devReport })
}

handler.command = /^(بلاغ|ابلاغ|report|bug)$/i
export default handler