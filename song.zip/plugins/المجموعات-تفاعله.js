import fs from 'fs'
import path from 'path'

const FILE_PATH = path.resolve('src/datatms.json')

const channelInfo = {
  isForwarded: true,
  forwardedNewsletterMessageInfo: {
    newsletterJid: '120363416870755391@newsletter',
    newsletterName: '𝐒𝐔𝐍𝐆 ꒰🐉⃝⃕꒱𝐔𝐏𝐃𝐀𝐓𝐄',
    serverMessageId: -1
  }
}

let handler = async (m, { conn, participants, isAdmin, isOwner }) => {
  try {
    if (!m.isGroup) return m.reply('❌ هذا الأمر يعمل في المجموعات فقط.')
    if (!isAdmin && !isOwner) return m.reply('❌ هذا الأمر مخصص للمشرفين فقط.')

    if (!fs.existsSync(FILE_PATH))
      return m.reply('⚠️ لا توجد بيانات تفاعل بعد.')

    const data = JSON.parse(fs.readFileSync(FILE_PATH))
    const chatId = m.chat

    if (!data[chatId] || !data[chatId].enabled)
      return m.reply('⚠️ نظام الحسبة غير مفعل.\nاستخدم `.حسبة on`')

    /* استخراج العضو (منشن أو رد) */
    let userId = null

    if (m.mentionedJid?.length) {
      userId = m.mentionedJid[0]
    } else if (m.quoted?.sender) {
      userId = m.quoted.sender
    }

    if (!userId)
      return m.reply('❌ منشن العضو أو رد على رسالته.')

    const groupData = data[chatId]
    const users = groupData.users || {}
    const totalMessages = groupData.total || 0
    const memberCount = users[userId] || 0
    const percent =
      totalMessages > 0
        ? ((memberCount / totalMessages) * 100).toFixed(1)
        : 0

    let text = `*❐═━━━═╊⊰🐉⊱╉═━━━═❐*\n`
    text += `*『📊┇ تفاعل العضو ┇📊』*\n`
    text += `*❐═━━━═╊⊰🐉⊱╉═━━━═❐*\n\n`
    text += `📌 *إجمالي رسائل المجموعة:* \`${totalMessages}\`\n`
    text += `*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*\n`
    text += `👤 *العضو:* @${userId.split('@')[0]}\n`
    text += `📩 *عدد الرسائل:* \`${memberCount}\`\n`
    text += `📊 *نسبة التفاعل:* 『 \`${percent}%\` 』\n`
    text += `*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*\n`
    text += `*❐═━━━═╊⊰🐉⊱╉═━━━═❐*\n`
    text += `> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

    await conn.sendMessage(
      chatId,
      {
        text,
        contextInfo: {
          ...channelInfo,
          mentionedJid: [userId]
        }
      },
      { quoted: m }
    )

  } catch (e) {
    console.error('❌ خطأ في أمر تفاعله:', e)
    m.reply('❌ حدث خطأ أثناء جلب تفاعل العضو.')
  }
}

handler.help = ['تفاعله']
handler.tags = ['group']
handler.command = ['تفاعله']
handler.group = true
handler.admin = true

export default handler