import fs from 'fs'
import path from 'path'

const FILE_PATH = path.resolve('src/datatms.json')

// إنشاء الملف إذا غير موجود
if (!fs.existsSync(FILE_PATH)) {
  fs.writeFileSync(FILE_PATH, JSON.stringify({}, null, 2))
}

let handler = async (m) => {
  if (!m.isGroup || !m.message) return
  if (m.fromMe || m.isBaileys) return

  const data = JSON.parse(fs.readFileSync(FILE_PATH))
  const chatId = m.chat
  const userId = m.sender

  // تهيئة بيانات المجموعة
  if (!data[chatId]) {
    data[chatId] = {
      enabled: false,
      total: 0,
      users: {}
    }
  }

  // إذا الميزة غير مفعلة لا نحسب
  if (!data[chatId].enabled) return

  // تهيئة المستخدم
  if (!data[chatId].users[userId]) {
    data[chatId].users[userId] = 0
  }

  // العدّ
  data[chatId].users[userId]++
  data[chatId].total++

  fs.writeFileSync(FILE_PATH, JSON.stringify(data, null, 2))
}

handler.before = handler
export default handler