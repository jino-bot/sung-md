import fetch from 'node-fetch'

const defaultImage = 'https://qu.ax/ueisS.IPG'

export async function before(m, { conn }) {
  if (!m.isGroup) return
  if (!global.db.data.chats[m.chat]) global.db.data.chats[m.chat] = {}
  const chat = global.db.data.chats[m.chat]
  if (!chat.welcome) return

  if (![27, 28, 32].includes(m.messageStubType)) return

  const groupMetadata = await conn.groupMetadata(m.chat)
  const groupName = groupMetadata.subject
  const groupSize = groupMetadata.participants.length
  const userId = m.messageStubParameters?.[0] || m.sender
  const userMention = `@${userId.split('@')[0]}`
  let profilePic = defaultImage

  try {
    profilePic = await conn.profilePictureUrl(userId, 'image').catch(() => defaultImage)
  } catch {}

  // ===== القناة + المنشن (نفس الطريقة) =====
  const channelInfo = {
  isForwarded: true,
  forwardedNewsletterMessageInfo: {
    newsletterJid: "120363416870755391@newsletter",
    newsletterName: "𝐒𝐔𝐍𝐆 ꒰🐉⃝⃕꒱𝐔𝐏𝐃𝐀𝐓𝐄",
    serverMessageId: -1
  },
  mentionedJid: [userId]
}

  // رسالة اتصال وهمية
  const fkontak = {
    key: {
      participants: "0@s.whatsapp.net",
      remoteJid: "status@broadcast",
      fromMe: false,
      id: "Halo"
    },
    message: {
      contactMessage: {
        vcard: `BEGIN:VCARD
VERSION:3.0
N:Sy;Bot;;;
FN:y
item1.TEL;waid=${userId.split('@')[0]}:${userId.split('@')[0]}
item1.X-ABLabel:Ponsel
END:VCARD`
      }
    },
    participant: "0@s.whatsapp.net"
  }

  // 🟢 ترحيب
  if (m.messageStubType === 27) {
    const welcomeText = `
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
      ✧ \`𝐖𝐄𝐋𝐂𝐎𝐌𝐄\`
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*

*❏- المنشـ📧ـن ⟦ ${userMention} ⟧*
*❏- اسم الجـروب ⟦ ${groupName} ⟧*
*❏- عدد الأعضـاء ⟦ ${groupSize} ⟧*

*⟐━───━「✨️✨️」━───━⟐*
> أهلاً وسهلاً بك في مجموعتنا
> نتمنى لك وقتًا ممتعًا بيننا
*⟐━───━「✨️✨️」━───━⟐*

*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*`.trim()

    await conn.sendMessage(m.chat, {
      image: { url: profilePic },
      caption: welcomeText,
      contextInfo: channelInfo
    }, { quoted: fkontak })
  }

  // 🔴 مغادرة
  if (m.messageStubType === 28 || m.messageStubType === 32) {
    const byeText = `
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
      ✧ \`𝐆𝐎𝐎𝐃 𝐁𝐘𝐄\`
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*

*❏- المنشـ📧ـن ⟦ ${userMention} ⟧*
*❏- عدد الأعضـاء ⟦ ${groupSize} ⟧*

*⟐━───━「✨️」━───━⟐*
> غادر أحد الأعضاء المجموعة او تم طرده
> نتمنى له التوفيق
*⟐━───━「✨️」━───━⟐*

*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*`.trim()

    await conn.sendMessage(m.chat, {
      image: { url: profilePic },
      caption: byeText,
      contextInfo: channelInfo
    }, { quoted: fkontak })
  }
}