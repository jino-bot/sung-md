let handler = async (m, { conn, participants, groupMetadata }) => {
  const chat = global.db.data.chats[m.chat] || {}

  const pp = await conn.profilePictureUrl(m.chat, 'image')
    .catch(_ => './avatar_contact.png')

  const groupAdmins = participants.filter(p => p.admin)
  const owner =
    groupMetadata.owner ||
    groupAdmins.find(p => p.admin === 'superadmin')?.id ||
    m.chat.split('-')[0] + '@s.whatsapp.net'

  const listAdmin = groupAdmins
    .map((v, i) => `*┊⟣* ${i + 1}. @${v.id.split('@')[0]}`)
    .join('\n')

  let teks = `
*⎔⋅• ━╼╃ ⌬〔 🏡 معلومات القروب 〕⌬ ╄╾ ━ •⋅⎔*

💠 *اسم القروب:* 『 ${groupMetadata.subject} 』
🆔 *آيدي القروب:* 『 ${groupMetadata.id} 』
👥 *عدد الأعضاء:* 『 ${participants.length} 』
👑 *مالك القروب:* 『 @${owner.split('@')[0]} 』

*⎔⋅• ━╼╃ ⌬〔 👑 المشرفون 〕⌬ ╄╾ ━ •⋅⎔*
${listAdmin || 'لا يوجد'}

*⎔⋅• ━╼╃ ⌬〔 ⚙️ الإعدادات 〕⌬ ╄╾ ━ •⋅⎔*
💌 *الترحيب:* ${chat.welcome ? '✅' : '❌'}
🕵🏻 *المراقبة:* ${chat.detect ? '✅' : '❌'}
🔗 *مضاد الروابط:* ${chat.antiLink ? '✅' : '❌'}
🔞 *NSFW:* ${chat.nsfw ? '✅' : '❌'}
💰 *الاقتصاد:* ${chat.economy ? '✅' : '❌'}
🎲 *القاتشا:* ${chat.gacha ? '✅' : '❌'}
🛑 *وضع المشرف فقط:* ${chat.modoadmin ? '✅' : '❌'}

*⎔⋅• ━╼╃ ⌬〔 📝 الوصف 〕⌬ ╄╾ ━ •⋅⎔*
${groupMetadata.desc || 'لا يوجد وصف'}

*⎔⋅• ━╼╃ ⌬〔 🐉 〕⌬ ╄╾ ━ •⋅⎔*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*
`.trim()

  await conn.sendMessage(
    m.chat,
    {
      image: { url: pp },
      caption: teks,
      contextInfo: {
        mentionedJid: [...groupAdmins.map(v => v.id), owner]
      }
    },
    { quoted: m }
  )
}

handler.help = ['infogp']
handler.tags = ['group']
handler.command = ['قروبي', 'جروبي', 'معلومات', 'groupinfo', 'infogp']
handler.group = true
handler.admin = true

export default handler