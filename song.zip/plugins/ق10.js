import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

let handler = async (m, { conn, usedPrefix }) => {
    try {
        // إرسال تفاعل 🖼️
        await conn.sendMessage(m.chat, { react: { text: "🖼️", key: m.key } });

        let name = await conn.getName(m.sender)
        
        const messageText = `*مـــرحبــــاً بـــكـ/ﻲ يـا ❪${name}❫ في قسم الصور*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *شرح القسم: أدوات متقدمة لتوليد الصور بالذكاء الاصطناعي وتحسين الجودة*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *｢🖼️┊قسم الصور والتصاميم┊🖼️｣*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
┊🎨┊: \`${usedPrefix}ارسم\`
> رسم يدوي (أبيض وأسود) من النص.
┊⛩️┊: \`${usedPrefix}انميشن\`
> توليد صور بأسلوب الأنمي الياباني.
┊✨┊: \`${usedPrefix}الدقة\`
> رفع دقة وجودة الصورة (تلقائي).
┊🛠️┊: \`${usedPrefix}تصميم\`
> تصميم جرافيك من خلال الوصف.
┊💞┊: \`${usedPrefix}تطقييم\`
> صور تطقيم للمرتبطين والاصحاب.
┊☁️┊: \`${usedPrefix}تليجراف\`
> رفع ميديا والحصول على رابط مباشر.
┊📍┊: \`${usedPrefix}صور\`
> بحث متقدم عن الصور في Pinterest.
┊📍┊: \`${usedPrefix}صور2\`
> بحث متقدم عن الصور في Pinterest2.
┊🔍┊: \`${usedPrefix}صوره\`
> جلب أول نتيجة بحث من Google.
┊🎭┊: \`${usedPrefix}طقمي\`
> تطقيم أنمي (بنت + بنت) منسق.
┊🎎┊: \`${usedPrefix}انمي_ستايل\`
> تحويل صورتك الشخصية لستايل أنمي.
┊🖋️┊: \`${usedPrefix}لوجو\`
> صناعة لوجو نصي بعدة أشكال.
┊📸┊: \`${usedPrefix}تحسين\`
> تطبيق فلاتر مع نظام وتحسين الصور.
┊😂┊: \`${usedPrefix}لصديق\`
> فديو محرج ومضحك لصديقي.
┊🎴┊: \`${usedPrefix}خلفيات\`
> تحميل ملفات خلفيات 4k اسطورية.
┊😂┊: \`${usedPrefix}ميمز\`
> صورة لميمز مضحك 😂.
 
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

        // مسار الصورة الموحد
        const imagePath = path.join(__dirname, '../src/media/Menu4.jpg')

        if (fs.existsSync(imagePath)) {
            await conn.sendMessage(m.chat, {
                image: { url: imagePath },
                caption: messageText
            }, { quoted: m })
        } else {
            await conn.sendMessage(m.chat, { text: messageText }, { quoted: m })
        }

    } catch (err) {
        console.error('❌ Error in Image Menu:', err)
    }
}

handler.help = ['الصور']
handler.tags = ['main']
handler.command = /^(قسم10)$/i 

export default handler
