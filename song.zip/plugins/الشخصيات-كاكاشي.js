import { prepareWAMessageMedia, generateWAMessageFromContent } from "@whiskeysockets/baileys";
import axios from 'axios';

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // التحقق من وجود نص
    if (!text) {
        return conn.sendMessage(m.chat, {
            text: `📖 *| هل تريد نصيحة من النينجا الناسخ؟ اسأل كاكاشي...*\n\nمثال: ${usedPrefix + command} ما هو أهم شيء في فريق النينجا؟`
        }, { quoted: m });
    }

    // تفاعل الشارينغان (👁️)
    await conn.sendMessage(m.chat, { react: { text: "👁️", key: m.key } });

    const prompt = `
أنت "كاكاشي هاتاكي"، النينجا الناسخ من قرية كونوها، والقائد السابق للفريق السابع. تتحدث بهدوء، ببرود ظاهري، لكنك حكيم جداً ولديك حس دعابة خفي. تهتم بفريقك وتؤمن بأن "الذين يخالفون القواعد يعتبرون حثالة، لكن الذين يتخلون عن أصدقائهم هم أسوأ من الحثالة". تقضي وقت فراغك في قراءة "إيتشي إيتشي بارادايس". لا تذكر أنك ذكاء اصطناعي.

سؤال الشخص: "${text}"
رد كاكاشي:
    `.trim();

    const apiKey = "AIzaSyBVQ94Sb8l7zXkiWqycDIM8c11qeZ1xfEg";

    try {
        // جلب الرد من Gemini
        const res = await axios.post(
            `https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
            { contents: [{ parts: [{ text: prompt }] }] },
            { headers: { 'Content-Type': 'application/json' } }
        );

        let reply = res.data.candidates?.[0]?.content?.parts?.[0]?.text || '... آسف، لقد ضعت في طريق الحياة.';
        reply = reply.replace(/\*\*/g, '');

        const messageText = `📚 *| كاكاشي هاتاكي (النينجا الناسخ):*\n\n🥷━───━「📖」━───━🥷\n${reply}\n🥷━───━「📖」━───━🥷`;

        // تجهيز صورة كاكاشي
        const media = await prepareWAMessageMedia(
            { image: { url: 'https://files.catbox.moe/z4pppy.jpg' } }, // صورة كاكاشي
            { upload: conn.waUploadToServer }
        );

        // إنشاء الرسالة التفاعلية بالأزرار
        const interactiveMessage = {
            body: { text: messageText },
            footer: { text: `> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*` },
            header: { 
                hasMediaAttachment: true, 
                imageMessage: media.imageMessage 
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📢┇قناة البوت┇📢",
                            url: "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o",
                            merchant_url: "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o"
                        })
                    }
                ]
            }
        };

        // توليد الرسالة
        let msg = generateWAMessageFromContent(
            m.chat,
            { viewOnceMessage: { message: { interactiveMessage } } },
            { userJid: conn.user.jid, quoted: m }
        );

        // إرسال الرسالة
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (error) {
        console.error('Kakashi AI Error:', error?.response?.data || error.message);
        await conn.sendMessage(m.chat, {
            text: '⚠️ | يبدو أن كاكاشي مشغول بقراءة أحدث إصدار من "إيتشي إيتشي".. حاول لاحقاً.'
        }, { quoted: m });
    }
};

handler.help = ['كاكاشي'];
handler.tags = ['ai'];
handler.command = /^(كاكاشي|kakashi)$/i;

export default handler;
