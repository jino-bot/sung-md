let handler = async (m, { conn, command, text }) => {
    // التأكد من وجود بيانات المستخدم في قاعدة البيانات
    let user = global.db.data.users[m.sender]
    if (!user) {
        user = global.db.data.users[m.sender] = {
            credit: 0,
            guessGame: {}
        }
    }

    // دالة بدء اللعبة
    const startGame = async () => {
        if (user.guessGame?.started) {
            return conn.reply(m.chat, '⚠️ لديك لعبة جارية بالفعل! استخدم: *تخمين [الرقم]*', m)
        }

        let secretNumber = Math.floor(Math.random() * 100) + 1;
        user.guessGame = {
            secretNumber: secretNumber,
            attempts: 0,
            maxAttempts: 10,
            started: true
        };

        let caption = `*⎔⋅• ━╼╃ ⌬〔 🐲 〕⌬ ╄╾ ━ •⋅⎔*\n`
        caption += `*✧ \`لعبة تخمين الرقم الملكية\` ✧*\n`
        caption += `*⎔⋅• ━╼╃ ⌬〔 🐲 〕⌬ ╄╾ ━ •⋅⎔*\n\n`
        caption += `🎯 تم اختيار رقم بين *1 و 100*\n`
        caption += `🧠 لديك *10* محاولات للفوز\n\n`
        caption += `> 📝 ابدأ بالتخمين باستخدام: *.تخمين [رقم]*`

        await conn.reply(m.chat, caption, m);
    };

    // دالة معالجة التخمين
    const endGame = async (guess) => {
        let game = user.guessGame;
        if (!game || !game.started) {
            return conn.reply(m.chat, '❌ لا توجد لعبة جارية حالياً. ابدأ بـ: *.رقم_سري*', m);
        }

        if (!guess) {
            return conn.reply(m.chat, '⚠️ يرجى كتابة الرقم بعد الأمر. مثال: *.تخمين 50*', m);
        }

        guess = parseInt(guess);
        if (isNaN(guess) || guess < 1 || guess > 100) {
            return conn.reply(m.chat, '🚫 يرجى إدخال رقم صحيح بين 1 و 100.', m);
        }

        game.attempts++;

        if (guess === game.secretNumber) {
            let reward = 500; // مقدار النقاط التي يربحها
            user.credit = (user.credit || 0) + reward; // إضافة نقاط بدلاً من XP
            
            let winMsg = `*🎉 مبروك! لقد فزت 🎉*\n\n`
            winMsg += `🔐 الرقم الصحيح: [ ${game.secretNumber} ]\n`
            winMsg += `💰 الجائزة: *${reward}* نقطة\n`
            winMsg += `🧠 عدد المحاولات: ${game.attempts}\n\n`
            winMsg += `> رصيدك الحالي: ${user.credit} نقطة`
            
            await conn.reply(m.chat, winMsg, m);
            user.guessGame = {}; // إنهاء اللعبة
        } else if (game.attempts >= game.maxAttempts) {
            await conn.reply(m.chat, `❌ انتهت محاولاتك! الرقم الصحيح كان *${game.secretNumber}*.\nحظاً أوفر في المرة القادمة!`, m);
            user.guessGame = {}; // إنهاء اللعبة
        } else {
            let hint = guess < game.secretNumber ? 'أعلى 🔼' : 'أقل 🔽';
            await conn.reply(m.chat, `❌ تخمين خاطئ!\n💡 جرب رقم *${hint}*\n🧠 محاولاتك: ${game.attempts}/10`, m);
        }
    };

    // دالة الشرح
    const showHelp = async () => {
        const helpMessage = `
🌟 *شرح لعبة تخمين الرقم* 🌟

1️⃣ *البدء*: اكتب *.رقم_سري*
2️⃣ *التخمين*: اكتب *.تخمين [رقمك]*
3️⃣ *الفوز*: إذا عرفت الرقم تربح *500 نقطة*

🔎 *تلميح*: بعد كل تخمين، سأخبرك إذا كان الرقم المطلوب "أعلى" أو "أقل".

*BY -ZEREF*`;
        await conn.reply(m.chat, helpMessage, m);
    };

    // التحكم بالأوامر
    if (command === 'رقم_سري') {
        await startGame();
    } else if (command === 'تخمين') {
        await endGame(text.trim());
    } else if (command === 'شرح') {
        await showHelp();
    }
};

handler.help = ['رقم_سري', 'تخمين', 'شرح'];
handler.tags = ['game'];
handler.command = ['رقم_سري', 'تخمين', 'شرح'];

export default handler;
