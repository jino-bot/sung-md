import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

let handler = async (m, { conn, usedPrefix }) => {
    try {
        // إرسال تفاعل 🛠️
        await conn.sendMessage(m.chat, { react: { text: "🛠️", key: m.key } });

        let name = await conn.getName(m.sender)
        
        const messageText = `*مـــرحبــــاً بـــكـ/ﻲ يـا ❪${name}❫ في قسم الإدارة*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *شرح القسم: أدوات التحكم في الأعضاء وضبط إعدادات المجموعة للمشرفين*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *｢🛠️┊قسم إدارة المشرفين┊🛠️｣*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
┊🎗️┊: \`${usedPrefix}ترقيه\`
> ترقية العضو الى رتبة المشرف.
┊📣┊: \`${usedPrefix}المشرفين\`
> عمل منشن لجميع طاقم الإدارة فقط.
┊⚠️┊: \`${usedPrefix}انذار\`
> إعطاء تحذير للعضو المخالف للقوانين.
┊👟┊: \`${usedPrefix}طرد\`
> إزالة عضو من المجموعة بشكل فوري.
┊👥┊: \`${usedPrefix}خفض\`
> تنزيل عضو من منصب المشرف.
┊🗑┊: \`${usedPrefix}حذف\`
> حذف رسالة معينة عند الرد عليها.
┊🔇┊: \`${usedPrefix}كتم\`
> كتم عضو من التكلم براحة في الجروب.
┊🔈┊: \`${usedPrefix}كتم_فك\`
> الغاء الكتم عن العضو والتكلم براحة.
┊⚰️┊: \`${usedPrefix}الأشباح\`
> طرد الاعضاء الميتين غير المتفاعلين.
┊⛓️┊: \`${usedPrefix}لينكي\`
> اظهار رابط الجروب الحالي للدعوة.
┊👥┊: \`${usedPrefix}دعوة\`
> دعوة عضو للإنضمام للمجموعة. 
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

        const imagePath = path.join(__dirname, '../src/media/Menu4.jpg')

        if (fs.existsSync(imagePath)) {
            await conn.sendMessage(m.chat, { 
                image: { url: imagePath }, 
                caption: messageText 
            }, { quoted: m })
        } else {
            await conn.sendMessage(m.chat, { text: messageText }, { quoted: m })
        }
    } catch (e) { 
        console.error('Error in Admin Menu:', e) 
    }
}

handler.help = ['قسم4']
handler.tags = ['main'] // تم تغييرها من admin إلى main ليشتغل للجميع
handler.command = /^(قسم4)$/i 

// لا تضع أي قيود هنا نهائياً
export default handler
