import { exec } from 'child_process'
import fs from 'fs'
import path from 'path'

let handler = async (m, { conn, args }) => {
  const chatId = m.chat

  // ❌ التحقق من الصيغة
  if (!args || args.length === 0) {
    return conn.sendMessage(chatId, {
      text:
        `❌ *| الصيغة ناقصة!*\n\n` +
        `استخدم:\n` +
        `.ايديت [اسم_الشخصية]`
    }, { quoted: m })
  }

  const query = args.join(' ').trim()
  const searchQuery = `edit ${query}` // 🔹 إضافة كلمة edit تلقائياً

  const tempDir = './temp'
  if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true })

  const videoPath = path.join(tempDir, `tiktok_${Date.now()}.mp4`)

  await conn.sendMessage(chatId, {
    text: `⏳ *| جاري البحث وتحميل ايديت "${query}" من TikTok...*`
  }, { quoted: m })

  const errorMsg =
    `❌ *| فشل تحميل الاديت!*\n` +
    `📌 تأكد من أن TikTok متاح أو جرب لاحقاً.`

  const command = `yt-dlp "ytsearch1:${searchQuery}" -f mp4 -o "${videoPath}"`

  exec(command, async err => {
    if (err || !fs.existsSync(videoPath)) {
      console.error('[ERROR] TikTok Edit:', err?.message)
      return conn.sendMessage(chatId, { text: errorMsg }, { quoted: m })
    }

    const caption =
`*❐═━━━═╊⊰🐍⊱╉═━━━═❐*

\`🎬 النوع:\` *فيديو*
\`📱 المصدر:\` *TikTok*
\`📝 الإيديت:\` *${query}*
\`🤖 بواسطة:\` *سونغ*

> عملية التحميل ناجحة
*❐═━━━═╊⊰🐍⊱╉═━━━═❐*`

    try {
      await conn.sendMessage(chatId, {
        video: fs.readFileSync(videoPath),
        caption
      }, { quoted: m })
    } finally {
      fs.unlinkSync(videoPath)
    }
  })
}

handler.help = ['ايديت <اسم الشخصية>']
handler.tags = ['tools']
handler.command = ['ايديت']

export default handler