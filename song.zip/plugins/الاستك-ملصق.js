import fetch from 'node-fetch'
import { sticker } from '../lib/sticker.js'

let handler = async (m, { conn, text, usedPrefix, command }) => {

  if (!text) {
    return conn.sendMessage(m.chat, {
      text: `⚠️ اكتب اسم شخصية أو أنمي\n\nمثال:\n${usedPrefix + command} نارتو`
    }, { quoted: m })
  }

  try {
    // 🔎 البحث عن صورة
    const url = `https://api.dorratz.com/v2/googleimage?query=${encodeURIComponent(
      text + ' anime sticker png'
    )}`

    const res = await fetch(url)
    const json = await res.json()

    if (!json || !json.results || json.results.length === 0) {
      return conn.sendMessage(m.chat, {
        text: `❌ لم أجد ملصقًا لـ: *${text}*`
      }, { quoted: m })
    }

    // 🎯 اختيار صورة واحدة عشوائية
    const img = json.results[Math.floor(Math.random() * json.results.length)]

    // 🔐 الحقوق
    const packname = 'Song Bot'
    const author = 'Developer Ayoub'

    const stkr = await sticker(
      false,
      img.url,
      packname,
      author
    )

    if (!stkr) throw 'فشل إنشاء الملصق'

    await conn.sendMessage(m.chat, {
      sticker: stkr
    }, { quoted: m })

  } catch (e) {
    console.error(e)
    await conn.sendMessage(m.chat, {
      text: '❌ حدث خطأ أثناء إنشاء الملصق.'
    }, { quoted: m })
  }
}

handler.help = ['ملصق <اسم>']
handler.tags = ['sticker']
handler.command = /^ملصق$/i
handler.limit = 1

export default handler