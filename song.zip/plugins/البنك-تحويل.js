let handler = async (m, { conn, text, command }) => {

  let to = m.mentionedJid?.[0] || m.quoted?.sender
  if (!to) {
    return m.reply(`*⚠️┇يرجى منشن الشخص أو الرد على رسالته*\n\n*مثال:* .${command} @user 200`)
  }

  let amount = parseInt(text.replace(/[^0-9]/g, ''))
  if (!amount || amount <= 0) {
    return m.reply(`*⚠️┇يرجى تحديد مبلغ صحيح*`)
  }

  // نخزن البيانات مؤقتًا في الرسالة
  let buttons = [
    {
      name: 'quick_reply',
      buttonParamsJson: JSON.stringify({
        display_text: '💰 نقاط',
        id: `.تحويل_تنفيذ bank ${to} ${amount}`
      })
    },
    {
      name: 'quick_reply',
      buttonParamsJson: JSON.stringify({
        display_text: '🪙 عملات',
        id: `.تحويل_تنفيذ coin ${to} ${amount}`
      })
    },
    {
      name: 'quick_reply',
      buttonParamsJson: JSON.stringify({
        display_text: '💡 خبرة',
        id: `.تحويل_تنفيذ exp ${to} ${amount}`
      })
    },
    {
      name: 'quick_reply',
      buttonParamsJson: JSON.stringify({
        display_text: '🎁 الكل',
        id: `.تحويل_تنفيذ all ${to} ${amount}`
      })
    }
  ]

  await conn.relayMessage(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: { text: '*💸┇يرجى تحديد نوع العمولة للتحويل*' },
          footer: { text: '> 𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
          nativeFlowMessage: { buttons }
        }
      }
    }
  }, {})
}

handler.command = ['تحويل']
handler.group = true
export default handler