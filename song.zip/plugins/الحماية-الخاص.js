let handler = async (m, { conn, args, usedPrefix, command }) => {
  let settings = global.db.data.settings[conn.user.jid]
  if (!settings) global.db.data.settings[conn.user.jid] = {}

  // عرض الحالة
  if (!args[0]) {
    let status = settings.blockPrivate ? 'مفعل ✅' : 'معطل ❌'
    return m.reply(
      `*🔒 حالة منع الخاص:* ${status}\n\n` +
      `*الاستخدام:*\n` +
      `• ${usedPrefix + command} on\n` +
      `• ${usedPrefix + command} off`
    )
  }

  // تفعيل
  if (args[0] === 'on') {
    if (settings.blockPrivate) return m.reply('⚠️ منع الخاص مفعل بالفعل.')
    settings.blockPrivate = true
    return m.reply('✅ تم تفعيل منع التحدث مع البوت في الخاص.')
  }

  // تعطيل
  if (args[0] === 'off') {
    if (!settings.blockPrivate) return m.reply('⚠️ منع الخاص معطل بالفعل.')
    settings.blockPrivate = false
    return m.reply('❌ تم تعطيل منع الخاص.')
  }

  return m.reply(`❌ استخدم فقط:\n${usedPrefix + command} on\n${usedPrefix + command} off`)
}

handler.help = ['الخاص']
handler.tags = ['owner']
handler.command = ['الخاص', 'blockpm']
handler.owner = true

export default handler