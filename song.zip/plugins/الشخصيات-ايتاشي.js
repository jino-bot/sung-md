import { prepareWAMessageMedia, generateWAMessageFromContent } from "@whiskeysockets/baileys";
import axios from 'axios';

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // التحقق من وجود نص
    if (!text) {
        return conn.sendMessage(m.chat, {
            text: `🩸 *| اسأل إيتاشي سؤالك بصوت هادئ...*\n\nمثال: ${usedPrefix + command} لماذا تركت كونوها؟`
        }, { quoted: m });
    }

    // تفاعل الشارينغان
    await conn.sendMessage(m.chat, { react: { text: "🐦‍⬛", key: m.key } });

    const prompt = `
أنت "إيتاشي أوتشيها" من عالم ناروتو. تتحدث بهدوء، حكمة، وغموض. تجيب بذكاء عميق وبدون سخرية. لا تذكر أنك ذكاء اصطناعي.
سؤال الشخص: "${text}"
رد إيتاشي:`.trim();

    const apiKey = "AIzaSyBVQ94Sb8l7zXkiWqycDIM8c11qeZ1xfEg";

    try {
        // جلب الرد من Gemini
        const res = await axios.post(
            `https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
            { contents: [{ parts: [{ text: prompt }] }] },
            { headers: { 'Content-Type': 'application/json' } }
        );

        let reply = res.data.candidates?.[0]?.content?.parts?.[0]?.text || '... الصمت أبلغ من الكلام أحيانًا.';
        reply = reply.replace(/\*\*/g, '');

        const messageText = `🔥 *| إيتاشي أوتشيها:*\n\n⟐━───━「🐦‍⬛」━───━⟐\n${reply}\n⟐━───━「🐦‍⬛」━───━⟐`;

        // تجهيز الصورة (بما أنها رابط خارجي)
        const media = await prepareWAMessageMedia(
            { image: { url: 'https://files.catbox.moe/z4pppy.jpg' } },
            { upload: conn.waUploadToServer }
        );

        // إنشاء الرسالة التفاعلية بالأزرار
        const interactiveMessage = {
            body: { text: messageText },
            footer: { text: `> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*` },
            header: { 
                hasMediaAttachment: true, 
                imageMessage: media.imageMessage 
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📢┇قناة البوت┇📢",
                            url: "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o",
                            merchant_url: "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o"
                        })
                    }
                ]
            }
        };

        // توليد الرسالة بالكامل
        let msg = generateWAMessageFromContent(
            m.chat,
            { viewOnceMessage: { message: { interactiveMessage } } },
            { userJid: conn.user.jid, quoted: m }
        );

        // إرسال الرسالة عبر نظام relayMessage
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (error) {
        console.error('Itachi AI Error:', error?.response?.data || error.message);
        await conn.sendMessage(m.chat, {
            text: '⚠️ | لم يتمكن إيتاشي من الرد الآن. ربما اختفى في الظلال...'
        }, { quoted: m });
    }
};

handler.help = ['ايتاشي'];
handler.tags = ['ai'];
handler.command = /^(ايتاشي)$/i;

export default handler;
