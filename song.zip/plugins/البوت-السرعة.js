import os from 'os'

let handler = async (m, { conn }) => {
  const start = Date.now()

  // نحسب الـ ping الحقيقي
  const msg = await conn.sendMessage(m.chat, { text: '⏳ فحص السرعة...' }, { quoted: m })
  const ping = Date.now() - start

  // مدة التشغيل
  const uptimeMs = process.uptime() * 1000
  const uptime = clockString(uptimeMs)

  const text = `
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
*┊    🚀『 𝐁𝐎𝐓 - 𝐉𝐈𝐍𝐖𝐎𝐎 』🚀 ┊*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*

*『 ⚙️ | حالة البوت 』*
*╭─────────────⟢* 
*│ 🚀 السرعة: ${ping}ms*
*│ ⏱️ مدة التشغيل: ${uptime}*
*╰─────────────⟢*

> البوت يعمل بكفاءة عالية 🚀
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*
`

  await conn.sendMessage(m.chat, { text }, { quoted: m })
}

handler.command = ['ping', 'السرعة']
handler.category = 'info'
export default handler

// ───── دالة تحويل الوقت ─────
function clockString(ms) {
  let h = Math.floor(ms / 3600000)
  let m = Math.floor(ms / 60000) % 60
  let s = Math.floor(ms / 1000) % 60

  return [
    h > 0 ? `${h} ساعة` : null,
    m > 0 ? `${m} دقيقة` : null,
    `${s} ثانية`
  ].filter(Boolean).join(' ')
}