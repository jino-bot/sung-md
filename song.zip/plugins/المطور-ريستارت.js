let handler = async (m, { conn }) => {

  await conn.sendMessage(m.chat, { 
    react: { text: '🔄', key: m.key } 
  })

  await conn.reply(
    m.chat,
    `*❐═━━━═╊⊰🔄⊱╉═━━━═❐*
✧ جارِ إعادة تشغيل البوت…
*❐═━━━═╊⊰🤖⊱╉═━━━═❐*
> سيتم الاتصال تلقائيًا بعد التشغيل
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*`,
    m
  )

  // تأخير بسيط لضمان إرسال الرسالة
  setTimeout(() => {
    process.exit(0)
  }, 1500)
}

handler.help = ['ريستارت']
handler.tags = ['owner']
handler.command = ['ريستارت', 'restart']
handler.owner = true

export default handler