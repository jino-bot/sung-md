let handler = m => m

handler.before = async function (m, { conn, isBotAdmin }) {
    if (!m.isGroup) return
    let chat = global.db.data.chats[m.chat]

    if (!chat.autoAceptar) return
    if (!isBotAdmin) return

    // قبول جميع الطلبات المعلقة
    try {
        const participants = await conn.groupRequestParticipantsList(m.chat)
        if (participants.length) {
            const jids = participants.map(p => p.jid)
            await conn.groupRequestParticipantsUpdate(m.chat, jids, 'approve')
        }
    } catch (e) {}

    // قبول الطلب فور وصوله
    if (m.messageStubType === 172 && m.messageStubParameters) {
        const [jid] = m.messageStubParameters
        if (jid) {
            try {
                await conn.groupRequestParticipantsUpdate(m.chat, [jid], 'approve')
            } catch (e) {}
        }
    }
}

export default handler