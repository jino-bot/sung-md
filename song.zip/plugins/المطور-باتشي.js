import fs from 'fs'
import path from 'path'

const handler = async (m, { conn, text }) => {
  if (!text) {
    return conn.reply(
      m.chat,
      '🕵 ⇦ اكـتـب اسـم الأمـر الـي تـبـحـث عـنـه\n\nمثال:\n.باتشي تست',
      m
    )
  }

  await conn.reply(
    m.chat,
    '🐉⇦ جـاري الـبـحـث عـن الأمـر فـي الـمـلـفـات 🔍',
    m
  )

  const basePath = 'plugins'
  const files = fs.readdirSync(basePath).filter(f => f.endsWith('.js'))
  const results = []

  for (let i = 0; i < files.length; i++) {
    const fileName = files[i]
    const filePath = path.join(basePath, fileName)

    try {
      const content = fs.readFileSync(filePath, 'utf-8')
      const lines = content.split('\n')

      lines.forEach((line, index) => {
        // البحث عن الأمر داخل handler.command
        if (
          line.includes('handler.command') &&
          line.includes(text)
        ) {
          results.push({
            fileIndex: i + 1,
            fileName,
            lineNumber: index + 1,
            lineContent: line.trim()
          })
        }
      })
    } catch {}
  }

  if (results.length === 0) {
    return conn.reply(
      m.chat,
      `❄️ ⇦ ≺مـا لـقـيـت أمـر بـاسـم "${text}" فـي أي مـلـف😢≺`,
      m
    )
  }

  let msg = `
🐉⇦ تـم الـعـثـور عـلـى أمـر "${text}" فـي هـذه الـمـلـفـات 
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
`

  results.forEach(r => {
    msg += `
📂 ⇦ رقـم الـمـلـف : ${r.fileIndex}
📄 ⇦ اسـم الـمـلـف : ${r.fileName}
🔢 ⇦ رقـم الـسـطـر : ${r.lineNumber}
✒️ ⇦ الـسـطـر : ${r.lineContent}
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
`
  })

  await conn.reply(m.chat, msg.trim(), m)
}

handler.help = ['باتشي <اسم_الأمر>']
handler.tags = ['owner']
handler.command = /^باتشي$/i

export default handler