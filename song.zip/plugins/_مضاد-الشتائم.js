const toxicRegex = /(كسمك|طيز|زب|نيك|متناك|خول|شرموطه|لبوه|عرص|بضان)/i

export async function before(m, { conn, isAdmin, isBotAdmin, isOwner, isROwner }) {
    if (!m.isGroup) return
    if (!m.text) return
    if (m.fromMe || isOwner || isROwner) return

    let chat = global.db.data.chats[m.chat]
    if (!chat || !chat.antiToxic) return

    const match = m.text.match(toxicRegex)
    if (!match) return

    const badWord = match[0]
    const user = global.db.data.users[m.sender] ||= {}
    user.warn = (user.warn || 0) + 1

    const userId = m.sender
    const userMention = `@${userId.split('@')[0]}`

    // ===== إعدادات القناة والمنشن الذكي =====
    const channelInfo = {
  isForwarded: true,
  forwardedNewsletterMessageInfo: {
    newsletterJid: "120363416870755391@newsletter",
    newsletterName: "𝐒𝐎𝐍Γ 𝐔𝐏𝐃𝐀𝐓𝐄 ꒰🐉⃝⃕꒱",
    serverMessageId: -1
  },
  mentionedJid: [userId]
}

    // رسالة اتصال وهمية لضمان ظهور المنشن كاسم
    const fkontak = {
        key: { participants: "0@s.whatsapp.net", remoteJid: "status@broadcast", fromMe: false, id: "ToxicLog" },
        message: {
            contactMessage: {
                vcard: `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${userId.split('@')[0]}:${userId.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
            }
        },
        participant: "0@s.whatsapp.net"
    }

    // حذف الرسالة المسيئة
    if (isBotAdmin) {
        await conn.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: false,
                id: m.key.id,
                participant: m.key.participant || m.sender
            }
        })
    }

    // ===== حالة الإنذار (أقل من 3) =====
    if (user.warn < 3) {
        const warnMsg = `
*❐═━━━═╊⊰🐍⊱╉═━━━═❐*
✧ \`إنــذار مـن قِبل الإدارة\`
*❐═━━━═╊⊰🐍⊱╉═━━━═❐*
👤 *❏- العـــضـــو : 『${userMention}』*
🚨 *❏- الكلمة السيئة: 『${badWord}』*
📌 *❏- عدد الإنذارات : 『${user.warn}/3』*
*❐═━━━═╊⊰🐍⊱╉═━━━═❐*
*❏- المـلاحـظـة : ⟦ تم إعطاء إنذار تلقائي، التكرار يؤدي إلى الطرد ⟧*
*❐═━━━═╊⊰🐍⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`.trim()

        await conn.sendMessage(m.chat, { 
            text: warnMsg, 
            contextInfo: channelInfo 
        }, { quoted: fkontak })

        return true
    }

    // ===== حالة الطرد (الإنذار الثالث) =====
    const kickMsg = `
*❐═━━━═╊⊰🐍⊱╉═━━━═❐*
✧ \`طرد من قبل البوت\`
*❐═━━━═╊⊰🐍⊱╉═━━━═❐*
👤 *❏- العـــضـــو : 『${userMention}』*
🚨 *❏- الكلمة السيئة: 『${badWord}』*
📌 *❏- عدد الإنذارات : 『${user.warn}/3』*
*❐═━━━═╊⊰🐍⊱╉═━━━═❐*
*❏- المـلاحـظـة : ⟦ تم طرد العضو بسبب تجاوز حد الإنذارات ⟧*
*❐═━━━═╊⊰🐍⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`.trim()

    await conn.sendMessage(m.chat, { 
        text: kickMsg, 
        contextInfo: channelInfo 
    }, { quoted: fkontak })

    // تنفيذ الطرد
    if (isBotAdmin && !isAdmin) {
        await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
        user.warn = 0 // تصفير الإنذارات بعد الطرد
    }

    return true
}
