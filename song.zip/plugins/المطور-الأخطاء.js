import fs from 'fs'
import path from 'path'
import url from 'url'

const handler = async (m, { conn }) => {
  await conn.reply(m.chat, '*『🔍┇جـاري فـحـص الـمـلـفات...┇🔍』*', m)

  try {
    const __dirname = path.dirname(url.fileURLToPath(import.meta.url))
    const pluginsDir = path.resolve(__dirname, '../plugins')

    if (!fs.existsSync(pluginsDir)) {
      await conn.reply(m.chat, '*【❌┇لم يتم العثور على مجلد الإضافات!┇❌】*', m)
      return
    }

    const files = fs.readdirSync(pluginsDir).filter(f => f.endsWith('.js'))
    let results = []

    for (const file of files) {
      const filePath = path.join(pluginsDir, file)
      let error = null
      let commandInfo = null

      try {
        const code = fs.readFileSync(filePath, 'utf8')
        const match =
          code.match(/handler\.command\s*=\s*([^\n;]+)/i) ||
          code.match(/\.command\s*=\s*([^\n;]+)/i)
        if (match) commandInfo = match[0].trim()

        const dynamicPath = `${path.resolve(filePath)}?t=${Date.now()}`
        await import(dynamicPath)

      } catch (e) {
        error = e.message.split('\n')[0] || String(e)
      }

      results.push({
        file,
        error,
        commandInfo: commandInfo || 'لا يوجد أمر محدد'
      })
    }

    const total = results.length
    const errors = results.filter(r => r.error)
    const errorCount = errors.length

    let msg = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n`
    msg += `*『🛠️┇نتـائـج الـفـحـص الـفـنـي┇🛠️』*\n\n`
    msg += `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n`
    msg += `*【📂┇إجمالي الملفات : ${total}┇📂】*\n`
    msg += `*【⚠️┇ملفات بها أخطاء : ${errorCount}┇⚠️】*\n`
    msg += `*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*\n`

    if (errorCount === 0) {
      msg += `*『✅┇الوضع الحالي: جميع الملفات سليمة┇✅』*\n`
    } else {
      msg += `*『❌┇تفاصيل الملفات المعطوبة┇❌』*\n`
      for (const r of errors) {
        msg += `\n*【📄┇الملف : ${r.file}┇📄】*\n`
        msg += `*【💢┇الخطأ : ${r.error}┇💢】*\n`
        msg += `*【🧩┇الأمر : ${r.commandInfo}┇🧩】*\n`
        msg += `*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*`
      }
    }

    msg += `\n\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n`
    msg += `*> 𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

    await conn.reply(m.chat, msg.trim(), m)
  } catch (err) {
    await conn.reply(m.chat, `*【🚨┇حدث خطأ في النظام: ${err.message}┇🚨】*`, m)
  }
}

handler.help = ['افحص']
handler.tags = ['owner']
handler.command = /^الأخطاء$/i

export default handler
