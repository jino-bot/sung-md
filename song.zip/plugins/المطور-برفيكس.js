import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CONFIG_FILE = path.join(__dirname, '../src/JSON/config.json');

// برفيكس افتراضي
const DEFAULT_PREFIX = '.';

let handler = async (m, { conn, text, usedPrefix }) => {
  // التأكد من وجود ملف الإعدادات
  if (!await fs.pathExists(CONFIG_FILE)) {
    await fs.writeJSON(CONFIG_FILE, { prefix: DEFAULT_PREFIX }, { spaces: 2 });
  }

  const config = await fs.readJSON(CONFIG_FILE);

  // إذا لم يتم إدخال أي نص => عرض البرفيكس الحالي
  if (!text) {
    return conn.sendMessage(m.chat, {
      text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*📌 البرفيكس الحالي:* ${config.prefix || '(فارغ)'}\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`
    }, { quoted: m });
  }

  // التعامل مع إعادة البرفيكس الافتراضي
  if (text.trim() === '.') {
    config.prefix = DEFAULT_PREFIX;
    await fs.writeJSON(CONFIG_FILE, config, { spaces: 2 });
    return conn.sendMessage(m.chat, {
      text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n✅ تم إعادة البرفيكس إلى الافتراضي: ${DEFAULT_PREFIX}\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`
    }, { quoted: m });
  }

  // التعامل مع برفيكس فارغ
  if (text.trim().toLowerCase() === 'فارغ') {
    config.prefix = '';
    await fs.writeJSON(CONFIG_FILE, config, { spaces: 2 });
    return conn.sendMessage(m.chat, {
      text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n✅ تم حذف البرفيكس، الآن البوت يعمل بدون أي برفيكس\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`
    }, { quoted: m });
  }

  // تغيير البرفيكس إلى أي نص آخر
  config.prefix = text.trim();
  await fs.writeJSON(CONFIG_FILE, config, { spaces: 2 });

  return conn.sendMessage(m.chat, {
    text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n✅ تم تغيير البرفيكس بنجاح إلى: ${config.prefix}\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`
  }, { quoted: m });
};

handler.command = ['برفيكس'];
handler.tags = ['المطور'];
handler.owner = true;
export default handler;
