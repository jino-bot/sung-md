import axios from 'axios'
import fs from 'fs'
import path from 'path'
import ffmpeg from 'fluent-ffmpeg'
import crypto from 'crypto'

let handler = async (m, { conn, text }) => {
  if (!text) {
    return m.reply('❌ اكتب نصًا لتحويله إلى صوت')
  }

  const lang = 'ar'

  try {
    // مسار مطلق (مهم جدًا)
    const baseTmp = path.resolve('./tmp')
    if (!fs.existsSync(baseTmp)) fs.mkdirSync(baseTmp)

    const id = crypto.randomBytes(6).toString('hex')
    const mp3 = path.join(baseTmp, `${id}.mp3`)
    const ogg = path.join(baseTmp, `${id}.ogg`)

    // Google TTS
    const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(text)}&tl=${lang}&client=tw-ob`

    // تحميل mp3
    const res = await axios.get(url, { responseType: 'stream' })
    const write = fs.createWriteStream(mp3)
    res.data.pipe(write)

    await new Promise((resolve, reject) => {
      write.on('finish', resolve)
      write.on('error', reject)
    })

    // تحويل إلى ogg opus
    await new Promise((resolve, reject) => {
      ffmpeg(mp3)
        .outputOptions([
          '-c:a libopus',
          '-b:a 64k'
        ])
        .toFormat('ogg')
        .save(ogg)
        .on('end', resolve)
        .on('error', reject)
    })

    // تأكد أن الملف موجود
    if (!fs.existsSync(ogg)) {
      throw new Error('OGG_NOT_CREATED')
    }

    // إرسال
    await conn.sendMessage(m.chat, {
      audio: fs.readFileSync(ogg),
      mimetype: 'audio/ogg; codecs=opus',
      ptt: true
    }, { quoted: m })

    // تنظيف
    fs.unlinkSync(mp3)
    fs.unlinkSync(ogg)

  } catch (e) {
    console.error('TTS ERROR:', e)
    m.reply('❌ فشل إنشاء الصوت (تأكد من ffmpeg)')
  }
}

handler.command = ['انطق', 'تكلم']
handler.tags = ['tools']
handler.help = ['انطق <نص>']

export default handler