import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

let handler = async (m, { conn, usedPrefix }) => {
    try {
        // إرسال تفاعل 👨‍💻
        await conn.sendMessage(m.chat, { react: { text: "👨‍💻", key: m.key } });

        let name = await conn.getName(m.sender)
        
        const messageText = `*مـــرحبــــاً بـــكـ/ﻲ يـا ❪${name}❫ في قسم المطور*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *شرح القسم: يحتوي على أوامر الإدارة والتحكم الكامل في نظام البوت*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *｢👨‍💻┊قسم المطور والخلفاء┊👨‍💻｣*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
┊🚪┊: \`${usedPrefix}اخرج\`
> مغادرة البوت للمجموعة الحالية.
┊🔍┊: \`${usedPrefix}باتشي\`
> البحث عن كلمة تنفيذ الأمر.
┊🔍┊: \`${usedPrefix}باتشو\`
> البحث عن كلمة في البلجنات.
┊🔍┊: \`${usedPrefix}باتشا\`
> البحث عن كلمة في البلجنات وتبديلها.
┊🛑┊: \`${usedPrefix}ايقاف\`
> إيقاف تشغيل نظام البوت بالكامل.
┊🛠️┊: \`${usedPrefix}باتش\`
> إدارة ملفات البلجنات (إضافة/حذف/تعديل).
┊⚠️┊: \`${usedPrefix}الأخطاء\`
> فحص سجل الأخطاء البرمجية في النظام.
┊🔧┊: \`${usedPrefix}بريفكس\`
> تغيير رمز الأوامر الخاص بالبوت.
┊📑┊: \`${usedPrefix}بلاغات\`
> عرض وإدارة بلاغات المستخدمين.
┊🧪┊: \`${usedPrefix}تست\`
> فحص سرعة واستجابة النظام.
┊🔁┊: \`${usedPrefix}تفاعل\`
> التحكم في التفاعل التلقائي مع الرسائل.
┊🧹┊: \`${usedPrefix}تنظيف\`
> مسح مخلفات الجلسة والملفات الزائدة.
┊📂┊: \`${usedPrefix}ادمني\`
> رفع المطور للإشراف.
┊📥┊: \`${usedPrefix}ادخل\`
> دخول البوت لمجموعة عبر رابط دعوة.
┊🔄┊: \`${usedPrefix}ريستارت\`
> إعادة تشغيل نظام البوت بالكامل.
┊💰┊: \`${usedPrefix}كسب\`
> تحويل نقاط أو ذهب لحساب مستخدم.
┊🌐┊: \`${usedPrefix}مجموعات\`
> عرض قائمة بجميع المجموعات المتواجد بها.
┊👑┊: \`${usedPrefix}اونر\`
> إضافة أو إزالة مطورين من القائمة.
🛑┊: \`${usedPrefix}بان\`
> حظر مستخدم من استعمال البوت
⭕┊: \`${usedPrefix}باند فك\`
> إلغاء الحظر عن المستخدم.
⛔┊: \`${usedPrefix}بانشات\`
> حظر او فك الشات عن استعمال البوت.
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

        // مسار الصورة الموحد
        const imagePath = path.join(__dirname, '../src/media/Menu4.jpg')

        if (fs.existsSync(imagePath)) {
            await conn.sendMessage(m.chat, {
                image: { url: imagePath },
                caption: messageText
            }, { quoted: m })
        } else {
            await conn.sendMessage(m.chat, { text: messageText }, { quoted: m })
        }

    } catch (err) {
        console.error('❌ Error in Owner Menu:', err)
    }
}

handler.help = ['المطور']
handler.tags = ['main']
handler.command = /^(قسم3)$/i 
handler.rowner = true // تفعيل هذا السطر إذا كنت تريد للأمر أن يظهر للمطور فقط

export default handler
