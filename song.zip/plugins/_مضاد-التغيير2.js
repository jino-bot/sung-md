import WAMessageStubType from '@whiskeysockets/baileys'

export async function before(m, { conn }) {
  if (!m.isGroup) return
  if (!m.messageStubType) return

  const chat = global.db.data.chats[m.chat]
  if (!chat?.protectAll) return

  // تجاهل رسائل البوت
  if (m.sender === conn.user.jid) return

  // منع التكرار (anti loop)
  if (chat._protectLock) return
  chat._protectLock = true
  setTimeout(() => chat._protectLock = false, 1500)

  const usuario = `@${m.sender.split('@')[0]}`
  const mentionedJid = [m.sender]

  // ===== معلومات القناة =====
  const channelInfo = {
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363416870755391@newsletter",
      newsletterName: "𝐒𝐔𝐍𝐆 ꒰🐉⃝⃕꒱𝐔𝐏𝐃𝐀𝐓𝐄",
      serverMessageId: -1
    },
    isForwarded: true,
    forwardingScore: 999,
    mentionedJid
  }

  // ===== رسالة موحدة =====
  const sendWarn = async (text) => {
    await conn.sendMessage(
      m.chat,
      { text, contextInfo: channelInfo },
      { quoted: m }
    )
  }

  // ===== منع الترقية / الخفض =====
  if (
    m.messageStubType === WAMessageStubType.GROUP_PARTICIPANT_PROMOTE ||
    m.messageStubType === WAMessageStubType.GROUP_PARTICIPANT_DEMOTE
  ) {
    let meta = await conn.groupMetadata(m.chat)
    let target = m.messageStubParameters?.[0]
    if (target) {
      let isAdmin = meta.participants.find(p => p.id === target)?.admin
      if (isAdmin === 'admin') {
        await conn.groupParticipantsUpdate(m.chat, [target], 'demote')
      } else {
        await conn.groupParticipantsUpdate(m.chat, [target], 'promote')
      }
    }

    return sendWarn(
`*❐═━━━═╊⊰🛡️⊱╉═━━━═❐*
*❐⇇ المجموعة محمية*
*❐⇇ ❌ لا يمكن ترقية أو خفض الأعضاء*
*❐⇇ 👤 بواسطة ↜ ❪${usuario}❫*
*❐═━━━═╊⊰🛡️⊱╉═━━━═❐*`
    )
  }

  // ===== منع إعدادات المجموعة =====
  if (m.messageStubType === WAMessageStubType.GROUP_CHANGE_SETTINGS) {
    if (chat.groupState?.settings) {
      await conn.groupSettingUpdate(m.chat, chat.groupState.settings)
    }

    return sendWarn(
`*❐═━━━═╊⊰🛡️⊱╉═━━━═❐*
*❐⇇ المجموعة محمية*
*❐⇇ ❌ لا يمكن تغيير إعدادات المجموعة*
*❐⇇ 👤 بواسطة ↜ ❪${usuario}❫*
*❐═━━━═╊⊰🛡️⊱╉═━━━═❐*`
    )
  }

  // ===== منع الاسم =====
  if (m.messageStubType === WAMessageStubType.GROUP_CHANGE_SUBJECT) {
    if (chat.groupState?.name) {
      await conn.groupUpdateSubject(m.chat, chat.groupState.name)
    }

    return sendWarn(
`*❐═━━━═╊⊰🛡️⊱╉═━━━═❐*
*❐⇇ المجموعة محمية*
*❐⇇ ❌ لا يمكن تغيير اسم المجموعة*
*❐⇇ 👤 بواسطة ↜ ❪${usuario}❫*
*❐═━━━═╊⊰🛡️⊱╉═━━━═❐*`
    )
  }

  // ===== منع الوصف =====
  if (m.messageStubType === WAMessageStubType.GROUP_CHANGE_DESCRIPTION) {
    if (chat.groupState?.desc) {
      await conn.groupUpdateDescription(m.chat, chat.groupState.desc)
    }

    return sendWarn(
`*❐═━━━═╊⊰🛡️⊱╉═━━━═❐*
*❐⇇ المجموعة محمية*
*❐⇇ ❌ لا يمكن تغيير وصف المجموعة*
*❐⇇ 👤 بواسطة ↜ ❪${usuario}❫*
*❐═━━━═╊⊰🛡️⊱╉═━━━═❐*`
    )
  }

  // ===== منع الصورة =====
  if (m.messageStubType === WAMessageStubType.GROUP_CHANGE_ICON) {
    if (chat.groupState?.photo) {
      await conn.updateProfilePicture(m.chat, { url: chat.groupState.photo })
    }

    return sendWarn(
`*❐═━━━═╊⊰🛡️⊱╉═━━━═❐*
*❐⇇ المجموعة محمية*
*❐⇇ ❌ لا يمكن تغيير صورة المجموعة*
*❐⇇ 👤 بواسطة ↜ ❪${usuario}❫*
*❐═━━━═╊⊰🛡️⊱╉═━━━═❐*`
    )
  }
}