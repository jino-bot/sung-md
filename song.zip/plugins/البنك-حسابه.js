let handler = async (m, { conn, usedPrefix, command }) => {

  // تحديد الشخص: رد ← منشن ← لا شيء
  let who = m.quoted
    ? m.quoted.sender
    : m.mentionedJid && m.mentionedJid[0]
    ? m.mentionedJid[0]
    : null

  if (!who) {
    return m.reply(`*⚠️┇يرجى الرد على رسالة الشخص أو منشنه*\n\n*مثال:* .${command} @user`)
  }

  let users = global.db.data.users
  if (!users[who]) {
    return m.reply('🟨 المستخدم غير موجود في قاعدة البيانات')
  }

  let user = users[who]
  let username = await conn.getName(who)

  let caption = `
*『💳┇معلومات الحساب┇💳』*

*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
*❐↞👤┇الــأســـــم:* ${username}
*❐↞🎖┇الرتــــبـــة:* ${user.role || 'لا توجد رتبة'}
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*

*❐↞💰┇النقــــــاط:* ${user.bank || 0}
*❐↞💡┇الخـــبـــرة:* ${user.exp || 0}
*❐↞🪙┇الـعـمـلات:* ${user.coin || 0}
*❐↞🎰┇المسـتـوى:* ${user.level || 0}

*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
> *⌫┇معلومات حساب المستخدم ┇〄*
`.trim()

  await conn.sendButton(
    m.chat,
    caption,
    '> 𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃',
    null,
    [['🏦 الـبـنـك', '.قسم11']],
    m,
    { mentions: [who] }
  )
}

handler.help = ['حسابه']
handler.tags = ['economy']
handler.command = ['حسابه']

export default handler