import pkg from "@whiskeysockets/baileys";
const { generateWAMessageFromContent } = pkg;

const cooldown = 30000;
const retos = new Map();
const jugadas = new Map();
const cooldowns = new Map();

let handler = async (m, { conn, args, usedPrefix, command }) => {
    const now = Date.now();
    const userId = m.sender;
    const user = global.db.data.users[userId];

    if (!user) return;

    const cooldownRestante = (cooldowns.get(userId) || 0) + cooldown - now;
    if (cooldownRestante > 0)
        return conn.reply(m.chat, `*🕓 مهلاً، انتظر ${Math.ceil(cooldownRestante / 1000)} ثانية قبل التحدي مجدداً.*`, m);

    const opponent = m.mentionedJid?.[0];

    // أزرار اللعب
    const sendPptButtons = async (jid, text, footer) => {
        const buttons = [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🗿 حجر", id: `${usedPrefix + command} حجر` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "📄 ورقة", id: `${usedPrefix + command} ورقة` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "✂️ مقص", id: `${usedPrefix + command} مقص` }) }
        ];

        const msg = generateWAMessageFromContent(jid, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text },
                        footer: { text: footer },
                        header: { title: "✧ `مبارزة الحجر والورقة والمقص` ✧" },
                        nativeFlowMessage: { buttons }
                    }
                }
            }
        }, { userJid: conn.user.jid, quoted: m });

        await conn.relayMessage(jid, msg.message, { messageId: msg.key.id });
    };

    // ضد البوت
    const input = args[0];
    if (input && ['حجر', 'ورقة', 'مقص'].includes(input)) {
        cooldowns.set(userId, now);

        const bot = ['حجر', 'ورقة', 'مقص'][Math.floor(Math.random() * 3)];
        const result = evaluar(input, bot);

        let resText = '';
        if (result === 'gana') {
            user.coin += 6;
            resText = '🎉 *لقد هزمت البوت وحصلت على 6 عملات!*';
        } else if (result === 'pierde') {
            user.coin = Math.max(0, user.coin - 3);
            resText = '💀 *هزمك البوت وتم خصم 3 عملات*';
        } else {
            resText = '🤝 *تعادل! لا ربح ولا خسارة.*';
        }

        return conn.reply(
            m.chat,
            `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*أنـت:* ⟦ ${input} ⟧
*الـبوت:* ⟦ ${bot} ⟧

${resText}
*💰 رصيدك الحالي:* ⟦ ${user.coin} عملة ⟧
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`,
            m
        );
    }

    // تحدي لاعب
    if (opponent) {
        if (opponent === userId) return m.reply('*⚠️ لا يمكنك تحدي نفسك!*');

        retos.set(opponent, {
            retador: userId,
            chat: m.chat,
            timeout: setTimeout(() => {
                retos.delete(opponent);
                conn.reply(m.chat, `*⏳ انتهى وقت قبول التحدي.*`, m);
            }, 60000)
        });

        const buttons = [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "✅ قبول التحدي", id: "قبول_تحدي" }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "❌ رفض", id: "رفض_تحدي" }) }
        ];

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: `*👤 @${userId.split('@')[0]} يطلب مبارزتك!*` },
                        footer: { text: "𝚂𝙾𝙽𝙶 𝙱𝙾𝚃 • 𝙿𝚅𝙿" },
                        nativeFlowMessage: { buttons }
                    }
                }
            }
        }, { userJid: conn.user.jid, quoted: m, mentions: [userId, opponent] });

        return conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    }

    await sendPptButtons(
        m.chat,
        `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*أهلاً بك في تحدي الموت.. اختر سلاحك!*
*💰 الجائزة:* +6 عملات | *الخسارة:* -3
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`,
        "اختر حركتك"
    );
};

handler.before = async (m, { conn }) => {
    const text = m.text;
    const userId = m.sender;

    if (retos.has(userId) && (text === 'قبول_تحدي' || text === 'رفض_تحدي')) {
        const { retador, chat, timeout } = retos.get(userId);
        clearTimeout(timeout);
        retos.delete(userId);

        if (text === 'رفض_تحدي')
            return conn.reply(chat, `*❌ تم رفض المبارزة.*`, m);

        jugadas.set(chat, { jugadores: [retador, userId], eleccion: {} });

        const sendPrivate = async (jid) => {
            const buttons = [
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🗿 حجر", id: ".حجر_سر" }) },
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "📄 ورقة", id: ".ورقة_سر" }) },
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "✂️ مقص", id: ".مقص_سر" }) }
            ];

            const msg = generateWAMessageFromContent(jid, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: "*اختر حركتك سراً:*" },
                            nativeFlowMessage: { buttons }
                        }
                    }
                }
            }, { userJid: conn.user.jid });

            await conn.relayMessage(jid, msg.message, {});
        };

        await sendPrivate(retador);
        await sendPrivate(userId);
    }

    if (text?.endsWith('_سر')) {
        const move = text.replace('_سر', '').replace('.', '');
        for (const [chat, partida] of jugadas) {
            const { jugadores, eleccion } = partida;
            if (!jugadores.includes(userId)) continue;

            eleccion[userId] = move;

            if (Object.keys(eleccion).length === 2) {
                const [j1, j2] = jugadores;
                const r = evaluar(eleccion[j1], eleccion[j2]);
                jugadas.delete(chat);

                let msg = `*✧ نتيجة المبارزة ✧*\n\n`;
                if (r === 'empate') msg += '🤝 *تعادل!*\n';
                else {
                    const win = r === 'gana' ? j1 : j2;
                    const lose = win === j1 ? j2 : j1;
                    global.db.data.users[win].coin += 6;
                    global.db.data.users[lose].coin = Math.max(0, global.db.data.users[lose].coin - 3);
                    msg += `🏆 @${win.split('@')[0]} +6 عملات\n💀 @${lose.split('@')[0]} -3 عملات`;
                }

                await conn.sendMessage(chat, { text: msg, mentions: [j1, j2] });
            }
        }
    }
};

handler.help = ['جاجاكين_بوت'];
handler.tags = ['game'];
handler.command = /^(جاجاكين_بوت)$/i;
export default handler;

function evaluar(a, b) {
    if (a === b) return 'empate';
    if ((a === 'حجر' && b === 'مقص') || (a === 'مقص' && b === 'ورقة') || (a === 'ورقة' && b === 'حجر')) return 'gana';
    return 'pierde';
}