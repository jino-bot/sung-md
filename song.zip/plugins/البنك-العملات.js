let handler = async (m, { conn, args }) => {

  if (!global.db.data.users) global.db.data.users = {}

  if (!global.db.data.users[m.sender]) {
    global.db.data.users[m.sender] = {
      bank: 0,
      coin: 0
    }
  }

  let user = global.db.data.users[m.sender]

  if (!args[0]) {
    return conn.reply(m.chat, '❌ الاستخدام:\n.شراء_العملات 5', m)
  }

  let amount = parseInt(args[0])
  if (isNaN(amount) || amount <= 0) {
    return conn.reply(m.chat, '❌ أدخل رقمًا صحيحًا', m)
  }

  const price = 150
  const total = amount * price

  if (user.bank < total) {
    return conn.reply(
      m.chat,
`*⎔⋅• ━╼╃ ⌬〔 🐲 〕⌬ ╄╾ ━ •⋅⎔*
❌ *نقاطك غير كافية*
💰 المطلوب: ${total}
📉 رصيدك: ${user.bank}
*⎔⋅• ━╼╃ ⌬〔 🐲 〕⌬ ╄╾ ━ •⋅⎔*`,
      m
    )
  }

  user.bank -= total
  user.coin += amount

  return conn.reply(
    m.chat,
`*⎔⋅• ━╼╃ ⌬〔 🐲 〕⌬ ╄╾ ━ •⋅⎔*
*✧ \`تمت عملية الشراء\` ✧*
*⎔⋅• ━╼╃ ⌬〔 🐲 〕⌬ ╄╾ ━ •⋅⎔*

🛒 *الكمية:* ⟦ ${amount} ⟧
💸 *التكلفة:* ${total} نقطة

*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
💰 نقاطك: ${user.bank}
🪙 عملاتك: ${user.coin}
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

*⎔⋅• ━╼╃ ⌬〔 🐲 〕⌬ ╄╾ ━ •⋅⎔*`,
    m
  )
}

handler.help = ['شراء_العملات <عدد>']
handler.tags = ['economy']
handler.command = ['شراء_العملات']

export default handler