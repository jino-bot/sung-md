let handler = m => m;

handler.all = async function (m) {
  if (m.key.fromMe) return; // منع البوت من الرد على نفسه

  let chat = global.db.data.chats[m.chat];

  if (chat.isBanned) return;

  let fake = {
    key: {
      fromMe: false,
      participant: '23595456638@s.whatsapp.net',
      remoteJid: '120363424744378732@g.us',
    },
    message: {
      conversation: '> 𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃'
    },
    participant: '23595456638@s.whatsapp.net',
  };

  // **الردود المسجلة**
  if (/^احتين$/i.test(m.text)) { 
    conn.reply(m.chat, `*خدها و شلحها😆*`, fake);
  }

  if (/^جينو$/i.test(m.text)) { 
    conn.reply(m.chat, `*شـبـيك لـبـيك الصياد سونغ ايـديـك 🥷*`, fake);
  }

  if (/^حمدا لله$/i.test(m.text)) { 
    conn.reply(m.chat, `*ادام الله حمدك*`, fake);
  }

  if (/^عبيط|يا عبيط|اهبل|غبي$/i.test(m.text)) { 
    conn.reply(m.chat, `*َمفيش اغـبـى منك فـي الـعالـم🥷ٌٍََََََُِّْ*`, fake);
  }

  if (/^بوتات$/i.test(m.text)) { 
    conn.reply(m.chat, `*سونغ مـوجـود 🥷*`, fake);
  }

  if (/^ييب$/i.test(m.text)) { 
    conn.reply(m.chat, `*يعم استرجل وقول نعم 🐦‍⬛*`, fake);
  }

  if (/^مطور$/i.test(m.text)) { 
    conn.reply(m.chat, `*مطوري أيوب*`, fake);
  }

  if (/^بوت خرا|بوت زفت|خرا عليك$/i.test(m.text)) { 
    conn.reply(m.chat, `*بص يسطا لم نفسك بدل ما انسي اني بوت  و امسح بيك بلاط الشات😒🗿*`, fake);
  }

  if (/^منور|منوره$/i.test(m.text)) { 
    conn.reply(m.chat, `*بنوري انا 🫠💔*`, fake);
  }

  if (/^بنورك|دا نورك|نورك الاصل|نور نورك$/i.test(m.text)) { 
    conn.reply(m.chat, `*يعم بنوري انا 🫠🐦*`, fake);
  }

  if (/^امزح|بهزر$/i.test(m.text)) { 
    conn.reply(m.chat, `*دمك تقيل متهزرش تاني😒*`, fake);
  }

  if (/^في اي|في ايه$/i.test(m.text)) { 
    conn.reply(m.chat, `*انا معرفش حاجه🙂*`, fake);
  }

  if (/^تست$/i.test(m.text)) { 
    conn.reply(m.chat, `*سونغ جينو في الخدمة*`, fake);
  }

  if (/^بتعمل ايه دلوقتي|بتعمل اي$/i.test(m.text)) { 
    conn.reply(m.chat, `*انت مالك😒*`, fake);
  }

  if (/^انا جيت$/i.test(m.text)) { 
    conn.reply(m.chat, `*امشي تاني*`, fake);
  }

  if (/^حرامي|سارق$/i.test(m.text)) { 
    conn.reply(m.chat, `*تتهم بريء بالسرقة من دون تحري او بحث عن حقيقة ليست ملموسة ارحنا واعمل شرطي ثم افتح فمك وثرثر فكلامك كـجاهل واحد بل جهلاً ارحم من حديثك تتصنع دور الشرطي وكأنك محقق بالله اصمت ولا تحرج نفسك ارحنا وارح أعصابك ان اكرمك الله بعقل فبسكوتك اقتل جهلك*`, fake);
  }

  if (/^ملل|مللل|ملللل|زهق$/i.test(m.text)) { 
    conn.reply(m.chat, `*لانك موجود🗿*`, fake);
  }

  if (/^🤖$/i.test(m.text)) { 
    conn.reply(m.chat, `انت بوت عشان ترسل الملصق ده 🐦`, fake);
  }

  if (/^🐦‍⬛$/i.test(m.text)) { 
    conn.reply(m.chat, `🐦`, fake);
  }

  if (/^ايه$/i.test(m.text)) { 
    conn.reply(m.chat, `*بلاش ارد احسن🌝🤣*`, fake);
  }

  if (/^نعم$/i.test(m.text)) { 
    conn.reply(m.chat, `*حد ناداك 🌚🐦*`, fake);
  }

  if (/^كيفك|شخبارك|علوك|عامل ايه|اخبارك|اي الدنيا$/i.test(m.text)) { 
    conn.reply(m.chat, `*ملكش فيه🗿*`, fake);
  }

  if (/^🐤$/i.test(m.text)) { 
    conn.reply(m.chat, `🐦`, fake);
  }
  
  if (/^تصبح علي خير|تصبحوا علي خير$/i.test(m.text)) { 
    conn.reply(m.chat, `وانت من اهل الخير حبيبي✨💜`, fake);
  }
  
  if (/^ببحبك بوت|حبك|بوت بحبك$/i.test(m.text)) { 
    conn.reply(m.chat, `اسكت بدل ما انادي مطوري يفشخك`, fake);
  }
   
  if (/^🙂$/i.test(m.text)) { 
    conn.reply(m.chat, `بص بعيد🙂`, fake);
  }
  
  if (/^باي$/i.test(m.text)) { 
    conn.reply(m.chat, `*غور ما بطيقه🗿*`, fake);
  }
   
  if (/^هلا$/i.test(m.text)) { 
    conn.reply(m.chat, `*اهلـيـن كـيـف حـالـك 🐤🌹*`, fake);
  }

if (/^🦦$/i.test(m.text)) { 
    conn.reply(m.chat, `🐧`, fake);
  }
  if (/يا بضان|دانت بضان|بضاني$/i.test(m.text)) { 
    conn.reply(m.chat, `يعم لما يبقا عندك الاول تعالا اتكلم😂🐦‍⬛`, fake);
  }
  return !0;
}

export default handler;