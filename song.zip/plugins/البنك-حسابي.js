let handler = async (m, { conn, usedPrefix }) => {
    let who = m.quoted ? m.quoted.sender : m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
    let user = global.db.data.users[who]
    let username = conn.getName(who)

    if (!(who in global.db.data.users)) throw `🟨 المستخدم غير موجود في قاعدة بياناتي`

    let caption = `
*『💳┇معلومات الحساب┇💳』*

*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
*❐↞👤┇الــأســـــم: ${username}*
*❐↞🎖┇الرتــــبـــة: ${user.role || 'لا توجد رتبة'}*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*

*❐↞💰┇النقــــــاط: ${user.bank}*
*❐↞💡┇الخـــبـــرة: ${user.exp}*
*❐↞🪙┇الـعـمـلات: ${user.coin}*
*❐↞🎰┇المسـتـوى: ${user.level}*

*❐═━━━═╊⊰🐲⊱╉═━━━═❐*

> *⌫┇اهـلا يمكنك اختيار زر من القائمة ┇〄*`.trim()

    // إرسال الرسالة مع زر البنك الذي ينفذ أمر .قسم11
    await conn.sendButton(m.chat, caption, '> 𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃', null, [
        ['🏦 الـبـنـك', `.قسم11`]
    ], m, { mentions: [who] })
}

handler.help = ['wallet']
handler.tags = ['economy']
handler.command = ['محفظة', 'حسابي'] 

export default handler
