let handler = async (m, { conn }) => {
  if (!m.quoted)
    throw '🖼️┇لازم ترد على ملصق عشان أحوله لصورة!┇😅'

  let mime = m.quoted.mimetype || ''
  if (!/webp/.test(mime))
    throw '❌┇الرسالة اللي رديت عليها مو ملصق!┇🚫'

  let sticker = await m.quoted.download()
  if (!sticker)
    throw '📥┇فشل تحميل الملصق، حاول مرة ثانية!┇⚠️'

  await conn.sendMessage(m.chat, {
    image: sticker,
    caption:
      '*❐═━━━═╊⊰🖼️⊱╉═━━━═❐*\n\n' +
      '✅ *تم تحويل الملصق إلى صورة بنجاح*\n' +
      '🤖 بواسطة: سونغ\n\n' +
      '*❐═━━━═╊⊰🖼️⊱╉═━━━═❐*'
  }, { quoted: m })
}

handler.help = ['لصورة']
handler.tags = ['sticker']
handler.command = ['لصورة', 'تحويل_صورة']

export default handler