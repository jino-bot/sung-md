import { canLevelUp, xpRange } from '../lib/levelling.js'

const handler = async (m, { conn, usedPrefix }) => {
  let { exp, level, role, coin, bank } = global.db.data.users[m.sender]
  let { xp, max } = xpRange(level, global.multiplier)
  let name = conn.getName(m.sender)
  let user = global.db.data.users[m.sender]
  let before = user.level

  // الحالة الأولى: إذا لم يرتفع المستوى (عرض البروفايل)
  if (!canLevelUp(user.level, user.exp, global.multiplier)) {
    let caption = `
*『💳┇معلومات الحساب┇💳』*

*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
*❐↞👤┇الــأســـــم: ${name}*
*❐↞🎖┇الرتــــبـــة: ${role}*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*

*❐↞💰┇النقــــــاط: ${user.bank || 0}*
*❐↞🪙┇العمـــــلات: ${user.coin || 0}*
*❐↞💡┇الخـــبـــرة: ${user.exp} / ${max}*
*❐↞🎰┇المسـتـوى: ${user.level}*

*❐═━━━═╊⊰🐲⊱╉═━━━═❐*

> *⌫┇اهـلا يمكنك اختيار زر من القائمة ┇〄*`.trim()

    return await conn.sendButton(m.chat, caption, '> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*', null, [
        ['🏦 الـبـنـك', `.قسم11`]
    ], m)
  }

  // الحالة الثانية: عند ارتفاع المستوى
  while (canLevelUp(user.level, user.exp, global.multiplier)) user.level++
  if (before !== user.level) {
    let nextLevelExp = xpRange(user.level, global.multiplier).max
    let remainingPoints = nextLevelExp - user.exp

    let str = `
*『🎉┇مـبـروك الـارتـقـاء┇🎉』*

*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
*❐↞👤┇الــأســـــم: ${name}*
*❐↞🎖┇الرتــــبـــة: ${role}*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*

*❐↞🆙┇المستوى السابق: ${before}*
*❐↞🆕┇المستوى الحالي: ${user.level}*
*❐↞🎰┇المستوى القادم: ${user.level + 1}*

*❐↞💰┇النقــــــاط: ${user.bank || 0}*
*❐↞🪙┇العمـــــلات: ${user.coin || 0}*
*❐↞💡┇الخـــبـــرة: ${user.exp}*
*❐↞🎯┇المتبقي للفل القادم: ${remainingPoints}*

*❐═━━━═╊⊰🐲⊱╉═━━━═❐*

> *🌟 استمر في التألق يا نجم 🌟*`.trim()

    const img = "https://qu.ax/EkkRk.jpg"
    
    try {
        await conn.sendButton(m.chat, str, '> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*', img, [
            ['🏦 الـبـنـك', `.قسم11`]
        ], m)
    } catch {
        await conn.sendButton(m.chat, str, '> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*', null, [
            ['🏦 الـبـنـك', `.قسم11`]
        ], m)
    }
  }
}

handler.help = ['levelup']
handler.tags = ['xp']
handler.command = ['رانك', 'lvl', 'لفل', 'مستوى']

export default handler
