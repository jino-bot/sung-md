export async function before(m) {
    try {
        let id = m.chat;
        this.bomb = this.bomb ? this.bomb : {};
        if (!this.bomb[id]) return !0;

        let user = global.db.data.users[m.sender];
        let body = m.text;
        let [player, board, timer, msg, currentReward] = this.bomb[id];

        // التأكد أن اللاعب هو صاحب الدور والرد على آخر رسالة للبوت
        if (m.sender !== player || !m.quoted || m.quoted.id !== msg.id) return !0;

        if (/^(انسحب|surrender)$/i.test(body)) {
            await this.reply(m.chat, `*🚩 قرر @${m.sender.split('@')[0]} الانسحاب والحفاظ على أرباحه.*`, m, { mentions: [m.sender] });
            clearTimeout(timer);
            delete this.bomb[id];
            return !0;
        }

        if (isNaN(body) || body < 1 || body > 9) return !0;

        let json = board.find(v => v.position == body);
        if (!json || json.state) return !0;

        if (json.emot === '💥') {
            json.state = true;
            let penalty = 1500; // عقوبة الخسارة من الـ bank
            user.bank = Math.max(0, (user.bank || 0) - penalty);

            let loseBoard = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*✧ \`بـوووووووم! انفجرت القنبلة\` ✧*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
   ${board.slice(0, 3).map(v => v.emot === '💥' ? '💥' : (v.state ? '💎' : v.number)).join('')}
   ${board.slice(3, 6).map(v => v.emot === '💥' ? '💥' : (v.state ? '💎' : v.number)).join('')}
   ${board.slice(6).map(v => v.emot === '💥' ? '💥' : (v.state ? '💎' : v.number)).join('')}
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

*💀 انفجر بك التنين!*
*تم خصم: ⟦ ${penalty} ⟧ من رصيد البنك 🏦*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`;

            await this.reply(m.chat, loseBoard, m);
            clearTimeout(timer);
            delete this.bomb[id];

        } else {
            json.state = true;
            // إضافة الربح الحالي لرصيد البنك
            user.bank = (user.bank || 0) + currentReward;
            
            // مضاعفة الجائزة للصندوق القادم
            let nextReward = Math.floor(currentReward * 1.8); 
            this.bomb[id][4] = nextReward;

            let openCount = board.filter(v => v.state).length;

                if (openCount >= 8) {
                let winBoard = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*✧ \`فوز أسطوري! صناديق التنين فارغة\` ✧*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
   ${board.slice(0, 3).map(v => v.state ? '💎' : v.number).join('')}
   ${board.slice(3, 6).map(v => v.state ? '💎' : v.number).join('')}
   ${board.slice(6).map(v => v.state ? '💎' : v.number).join('')}
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

*🏆 مبروك! نجوت من فخ التنين وجمعت كل النقاط!*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`;
                await this.reply(m.chat, winBoard, m);
                clearTimeout(timer);
                delete this.bomb[id];
            } else {
                let updateBoard = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*✧ \`تحدي صناديق التنين الملعونة\` ✧*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
   ${board.slice(0, 3).map(v => v.state ? '💎' : v.number).join('')}
   ${board.slice(3, 6).map(v => v.state ? '💎' : v.number).join('')}
   ${board.slice(6).map(v => v.state ? '💎' : v.number).join('')}
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

*✅ صندوق آمن! ربحت: ⟦ ${currentReward} ⟧ نقطة بنك 🏦*
*💰 الصندوق القادم قيمته: ⟦ ${nextReward} ⟧*
*استمر أو اكتب (انسحب) للحفاظ على أرباحك.*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅╔*`;

                // إرسال رسالة جديدة وتحديث المرجع (مثل نظام XO)
                let newMsg = await this.reply(m.chat, updateBoard, m);
                this.bomb[id][3] = newMsg; 
            }
        }
    } catch (e) {
        console.error(e);
    }
    return !0;
}
