import { exec } from 'child_process'
import { promisify } from 'util'
import fs from 'fs'
import path from 'path'

const execAsync = promisify(exec)

let handler = async (m, { conn, args }) => {
  const chatId = m.chat

  // ===============================
  // ✅ الحالة 1: رابط فقط → أزرار
  // ===============================
  if (args.length === 1 && args[0].startsWith('http')) {
    const url = args[0]

    let info
    try {
      const { stdout } = await execAsync(
        `yt-dlp --print "%(title)s|%(uploader)s" "${url}"`
      )
      const [title, uploader] = stdout.trim().split('|')
      info = { title, uploader }
    } catch {
      info = { title: 'غير معروف', uploader: 'غير معروف' }
    }

    return conn.sendMessage(chatId, {
      text:
        `┏━━━✦ 『 📊 معلومات المنشور 』✦━━━┓\n\n` +
        `📝 العنوان: ${info.title}\n` +
        `📤 الناشر: ${info.uploader}\n\n` +
        `اختر نوع التحميل:\n` +
        `┗━━━━━━━━━━━━━━━━━━━━┛`,
      buttons: [
        {
          buttonId: `.فيس فيديو ${url}`,
          buttonText: { displayText: '🎬 تحميل فيديو' },
          type: 1
        },
        {
          buttonId: `.فيس صورة ${url}`,
          buttonText: { displayText: '🖼️ تحميل صورة' },
          type: 1
        }
      ],
      headerType: 1
    }, { quoted: m })
  }

  // ===============================
  // ❌ صيغة ناقصة
  // ===============================
  if (args.length < 2) {
    return conn.sendMessage(chatId, {
      text:
        `❌ *| الصيغة الصحيحة:*\n\n` +
        `.فيس (الرابط)\n` +
        `.فيس فيديو (الرابط)\n` +
        `.فيس صورة (الرابط)`
    }, { quoted: m })
  }

  // ===============================
  // ✅ تحميل فعلي
  // ===============================
  const format = args[0].toLowerCase()
  const url = args[1]

  if (!url.includes('facebook.com')) {
    return conn.sendMessage(chatId, {
      text: '❌ الرابط غير صالح (فيسبوك فقط)'
    }, { quoted: m })
  }

  const tempDir = './temp'
  if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true })

  const filePath = path.join(
    tempDir,
    `${Date.now()}.${format === 'صورة' ? 'jpg' : 'mp4'}`
  )

  await conn.sendMessage(chatId, {
    text: `⏳ جاري التحميل...\n📱 المصدر: Facebook\n🎬 النوع: ${format}`
  }, { quoted: m })

  // 🎬 فيديو
  if (format === 'فيديو') {
    exec(`yt-dlp -f mp4 -o "${filePath}" "${url}"`, async err => {
      if (err || !fs.existsSync(filePath)) {
        return conn.sendMessage(chatId, {
          text: '❌ فشل تحميل الفيديو (قد يكون خاص)'
        }, { quoted: m })
      }

      await conn.sendMessage(chatId, {
        video: fs.readFileSync(filePath),
        caption:
          `┏━━━✦ 『 📥 تم التحميل 』✦━━━┓\n\n` +
          `🎬 النوع: فيديو\n` +
          `📱 المصدر: Facebook\n` +
          `🤖 بواسطة: سونغ\n` +
          `┗━━━━━━━━━━━━━━━━━━━━┛`
      }, { quoted: m })

      fs.unlinkSync(filePath)
    })
  }

  // 🖼️ صورة
  else if (format === 'صورة') {
    exec(`yt-dlp -f best -o "${filePath}" "${url}"`, async err => {
      if (err || !fs.existsSync(filePath)) {
        return conn.sendMessage(chatId, {
          text: '❌ فشل تحميل الصورة (قد يكون خاص)'
        }, { quoted: m })
      }

      await conn.sendMessage(chatId, {
        image: fs.readFileSync(filePath),
        caption:
          `┏━━━✦ 『 📥 تم التحميل 』✦━━━┓\n\n` +
          `🖼️ النوع: صورة\n` +
          `📱 المصدر: Facebook\n` +
          `🤖 بواسطة: سونغ\n` +
          `┗━━━━━━━━━━━━━━━━━━━━┛`
      }, { quoted: m })

      fs.unlinkSync(filePath)
    })
  }

  else {
    return conn.sendMessage(chatId, {
      text: '❗ اختر: فيديو أو صورة'
    }, { quoted: m })
  }
}

handler.help = ['فيس <رابط>', 'فيس <فيديو|صورة> <رابط>']
handler.tags = ['downloader']
handler.command = ['فيس']

export default handler