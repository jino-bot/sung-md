import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

let handler = async (m, { conn, usedPrefix }) => {
    try {
        // إرسال تفاعل 🏦
        await conn.sendMessage(m.chat, { react: { text: "🏦", key: m.key } });

        let name = await conn.getName(m.sender)
        
        const messageText = `*مـــرحبــــاً بـــكـ/ﻲ يـا ❪${name}❫ في قسم البنك*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *شرح القسم: إدارة أموالك، تحويل النقاط، واستلام الهدايا والمكافآت*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *｢🏦┊قسم النظام المصرفي┊🏦｣*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
┊📅┊: \`${usedPrefix}اسبوعي\`
> هدية أسبوعية عشوائية (للمستوى +10).
┊🏆┊: \`${usedPrefix}ترتيب\`
> عرض ترتيب المستخدمين حسب إجمالي النقاط.
┊👤┊: \`${usedPrefix}حسابي\`
> عرض تفاصيل حسابك البنكي الحالي.
┊💰┊: \`${usedPrefix}رانك\`
> تطوير مستواك اذا وصلت الحد.
┊💎┊: \`${usedPrefix}شهري\`
> هدية شهرية ضخمة (للمستوى +25).
┊📈┊: \`${usedPrefix}مستوى\`
> عرض رتبتك، مستواك، ونقاط الخبرة (XP).
┊🎁┊: \`${usedPrefix}يومي\`
> مكافأة نقاط مجانية كل 24 ساعة.
┊🎫┊: \`${usedPrefix}راتب\`
> مكافأة نقاط راتب كل 24 ساعة.
┊💼┊: \`${usedPrefix}عمل\`
> مكافأة نقاط عمل كل 24 ساعة.
┊🔄┊: \`${usedPrefix}تحويل\`
> تحويل نقاط لحساب تاني.
┊👤┊: \`${usedPrefix}حسابه\`
> عرض تفاصيل زميلك البنكي الحالي.
┊🪙┊: \`${usedPrefix}عملاتي\`
> عرض قائمة عملاتك في البنك.
┊🪙┊: \`${usedPrefix}شراء_العملات\`
> شراء عملات مقابل النقاط.
┊🏦┊: \`${usedPrefix}شراء_النقاط\`
> شراء نقاط مقابل العملات الذهبية.
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

        // مسار الصورة الموحد
        const imagePath = path.join(__dirname, '../src/media/Menu4.jpg')

        if (fs.existsSync(imagePath)) {
            await conn.sendMessage(m.chat, {
                image: { url: imagePath },
                caption: messageText
            }, { quoted: m })
        } else {
            await conn.sendMessage(m.chat, { text: messageText }, { quoted: m })
        }

    } catch (err) {
        console.error('❌ Error in Bank Menu:', err)
    }
}

handler.help = ['البنك']
handler.tags = ['main']
handler.command = /^(قسم11)$/i 

export default handler
