import fs from 'fs';

let toM = a => '@' + a.split('@')[0];

async function handler(m, { conn, groupMetadata, usedPrefix, command, text }) {
    let ps = groupMetadata.participants.map(v => v.id);
    let a = m.sender; // العريس هو من أرسل الأمر
    let b;

    // تحديد العروسة (منشن، رد، أو عشوائي)
    let target = m.mentionedJid?.[0] || (m.quoted ? m.quoted.sender : null);

    if (target) {
        if (target === a) return m.reply('*⚠️ لا يمكنك الزواج من نفسك، ابحث عن شريك آخر!*');
        b = target;
    } else {
        do {
            b = ps[Math.floor(Math.random() * ps.length)];
        } while (b === a);
    }

    // مسار الصورة المحلي
    const localImg = './src/media/زواج.png';
    
    let caption = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*✧ \`إعـلان زواج مـلـكـي\` ✧*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

*❯ 🤵🏻‍♂️ الــعــريـس :* ${toM(a)}
*❯ 👰🏻‍♀️ الــعــروسـة :* ${toM(b)}

*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*✨ بـاركو لهـما في حيـاتهما الجـديـدة ✨*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

> *توزيع الحلويات على حساب العريس والبوفيه مفتوح 😂 🍬*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`;

    // التحقق من وجود الصورة قبل الإرسال
    if (fs.existsSync(localImg)) {
        await conn.sendFile(m.chat, localImg, 'marry.png', caption, m, false, { mentions: [a, b] });
    } else {
        // رسالة بديلة في حال عدم وجود الصورة في المسار المحدد
        await conn.reply(m.chat, caption, m, { mentions: [a, b] });
    }
}

handler.help = ['زوجني', 'زواج'];
handler.tags = ['fun'];
handler.command = ['زوجني', 'زواج'];
handler.group = true;

export default handler;
