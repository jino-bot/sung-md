import pkg from '@whiskeysockets/baileys'
const { prepareWAMessageMedia } = pkg
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

function clockString(ms) {
let h = Math.floor(ms / 3600000)
let m = Math.floor((ms % 3600000) / 60000)
let s = Math.floor((ms % 60000) / 1000)
return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':')
}

const handler = async (m, { conn }) => {
// حساب السرعة الحقيقية (Ping)
let start = Date.now()
let ping = Date.now() - start

// حساب إجمالي الأوامر الحقيقي من مجلد plugins
const pluginsDir = path.join(__dirname, '../plugins')
let totalPlugins = 0
try {
totalPlugins = fs.readdirSync(pluginsDir).filter(file => file.endsWith('.js')).length
} catch {
totalPlugins = 0
}

let user = global.db.data.users[m.sender] || {}
let name = await conn.getName(m.sender)
let uptime = clockString(process.uptime() * 1000)
let platform = process.platform === 'win32' ? 'Windows' : process.platform === 'linux' ? 'Linux / Server' : 'سيرفر'

await conn.sendMessage(m.chat, { react: { text: '🐲', key: m.key } })

// قراءة الصورة المحلية
await conn.sendMessage(m.chat, { react: { text: '🐲', key: m.key } })

// استخدام صورة من رابط فقط
const media = await prepareWAMessageMedia(
  {
    image: { url: 'https://files.catbox.moe/lpg8cr.jpg' }
  },
  { upload: conn.waUploadToServer }
)


const menuText = `
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
*『 👤┇بوت سونغ جينوو┇👤』*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
*【⚫️┇اهـلا بـك : ${name}┇⚫️ 】*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*『🤖┇مـعـلـومـات الـبـوت┇🤖』*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*【🐉┇الـبــوت  : سـونـغ┇🐉】*
*【🀄┇الـوضـع  : عـــــام┇🀄】*
*【♨️┇المنـصة : ${platform}┇♨️】*
*【🌐┇الـبـادئـة : نقطة┇🌐】*

*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
*『👤┇معلـومـات المستخدم┇👤』*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*【🎫┇الاسم  : ${user.name || name}*
*【💰┇النقاط : ${user.coin || 0}*
*【🎖️┇الخبرة : ${user.exp || 0}*
*【🎰┇المستوى : ${user.level || 0}*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*『⏱️┇الـــمــدة : ${uptime}*
*『🚀┇السـرعة : ${ping}ms*
*『👑┇إجمالي الأوامر : ${totalPlugins}*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
\`⧉↫ يمكنك عرض الاقسام من زر القائمة\`
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*`;


const buttons = [  
{  
  name: "single_select",  
  buttonParamsJson: JSON.stringify({  
    title: '📜┇قائمة البوت┇📜',  
    sections: [  
      {  
        title: '📂 ┇ الأقسام المتاحة ┇ 📂',  
        rows: [  
          { title: '🎭┆قـسـم الـشـخـصـيـات AI', description: 'اوامر الشخصيات الخيالية للدردشة', id: '.قسم1' },  
          { title: '🧰┆قـسـم الأدوات الـتـقـنـيـة', description: 'اوامر ادوات مميزة للبوت', id: '.قسم2' },  
          { title: '👑┆قـسـم الـمـطـور الـخـاص', description: 'أوامر التحكم الكاملة للمالك فقط', id: '.قسم3' },  
          { title: '🛡️┆قـسـم إدارة الـمـشـرفـيـن', description: 'اوامر صلاحيات المشرفين', id: '.قسم4' },  
          { title: '🕌┆قـسـم الإسـلامـيـات', description: 'اوامر الدين الاسلامي للتحصين', id: '.قسم5' },  
          { title: '👥┆قـسـم إدارة الـمـجـمـوعـات', description: 'اوامر تنظيم المجموعات وضبط الإعدادات', id: '.قسم6' },  
          { title: '🎮┆قـسـم الألـعـاب والـتـحـدي', description: 'ألعاب تفاعلية، كويزات ومسابقات', id: '.قسم7' },  
          { title: '😂┆قـسـم الـريـكنشنات والـمـرح', description: 'نكت، ريكنشنات، وأشياء ممتعة', id: '.قسم8' },  
          { title: '📚┆قـسـم الـثـقـافـة والـعـلـوم', description: 'هل تعلم؟ ومعلومات عامة مفيدة', id: '.قسم9' },  
          { title: '🖼️┆قـسم: الـصـور والـتـصـامـيـم', description: 'تحميل صور، خلفيات، ولوحات فنية', id: '.قسم10' },  
          { title: '🏦┆قـسـم الـنـظـام الـمـصـرفـي', description: 'إدارة العملات والبنك الخاص بك', id: '.قسم11' },  
          { title: '📥┆قـسـم الـتـنـزيـلات والميديا', description: 'تحميل من يوتيوب، تيك توك، فيسبوك', id: '.قسم12' },  
          { title: '🛡️┆قـسـم الـحـمـايـة والأمـان', description: 'أنظمة الحماية التلقائية للجروبات', id: '.قسم13' },  
          { title: '🎉┆قـسـم الـفـعـالـيـات', description: 'اوامر الفعاليات والتحدي واللعب', id: '.قسم14' },  
          { title: '🤖┆قـسـم الذكاء الإصطناعي', description: 'تحدث مع AI واطلب منه أي شيء', id: '.قسم15' },  
          { title: '👥┆قـسـم الأعـضـاء', description: 'أوامر عامة مخصصة لجميع المستخدمين', id: '.قسم16' },  
          { title: '🔂┆قـسـم الـمـلـصـقـات والتحويل', description: 'اوامر الملصقات واوامر التحويل', id: '.قسم17' },  
          { title: '🍥┆قـسـم الأنمـي والـمـانـجـا', description: 'عالم الأنمي، أخبار، ومعلومات والمانهوا', id: '.قسم18' },  
          { title: '🏷️┆قـسـم الألـقـاب والـتـسـجـيـل', description: 'نظام تسجيل الهوية والألقاب', id: '.قسم19' },  
          { title: '🐉┆قـسـم الـسولـو لـيـفـلـيـنـغ', description: 'النظام الخاص بليفلينغ والارتقاء', id: '.قسم20' },
          { title: '🤖┆قـسـم الـبـوت والنـظام', description: 'معلومات العامة والتنصيب', id: '.قسم21' } 
        ]  
      }  
    ]  
  })  
},
{  
  name: "quick_reply",  
  buttonParamsJson: JSON.stringify({  
    display_text: "🌟┇تقييم البوت┇🌟",  
    id: ".تقييم"  
  })  
},  
{  
  name: "cta_url",  
  buttonParamsJson: JSON.stringify({  
    display_text: "📢┇قناة البوت┇📢",  
    url: "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o",  
    merchant_url: "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o"  
  })  
},  
{  
  name: "quick_reply",  
  buttonParamsJson: JSON.stringify({  
    display_text: "👑┇مطور البوت┇👑",  
    id: ".المطور"  
  })  
}

]

await conn.relayMessage(m.chat, {
viewOnceMessage: {
message: {
interactiveMessage: {
body: { text: menuText },
footer: { text: '> 𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
header: {
hasMediaAttachment: true,
imageMessage: media.imageMessage
},
nativeFlowMessage: { buttons }
}
}
}
}, {})
}

handler.help = ['menu']
handler.tags = ['main']
handler.command = ['اوامر', 'الاوامر', 'مهام']

export default handler