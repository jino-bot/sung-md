export async function before(m) {
    this.autosholat = this.autosholat ? this.autosholat : {};
    let id = m.chat;

    // مواقيت الصلاة
    let jadwalSholat = {
        "الفجر": "04:55",
        "الظهر": "12:05",
        "العصر": "15:20",
        "المغرب": "17:55",
        "العشاء": "19:10"
    };

    // توقيت إنجمينا
    const date = new Date(new Date().toLocaleString("en-US", { timeZone: "Africa/Ndjamena" }));
    const timeNow = `${date.getHours().toString().padStart(2, "0")}:${date.getMinutes().toString().padStart(2, "0")}`;

    // التحقق إذا كان الوقت الحالي هو وقت صلاة ولم يتم الإرسال لهذه الصلاة بعد
    for (const [sholat, waktu] of Object.entries(jadwalSholat)) {
        if (timeNow === waktu && this.autosholat[id] !== waktu) {
            
            let caption = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*✧ \`تذكير بموعد الصلاة\` ✧*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

*🕋 حان الآن موعد صلاة : ⟦ ${sholat} ⟧*

*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*⏰ التوقيت الحالي : ⟦ ${waktu} ⟧*
*🌍 المدينة : ⟦ إنجمينا ⟧*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

> *﴿إِنَّ الصَّلاةَ كانَت عَلَى المُؤمِنينَ كِتابًا مَوقوتًا﴾*
> اذهب وتوضأ الآن وقم لصلاتك.. ولا تنسانا من صالح دعائك.

*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`;

            await this.reply(m.chat, caption, null);
            
            // تخزين الوقت لمنع التكرار في نفس الدقيقة
            this.autosholat[id] = waktu; 

            // مسح الذاكرة بعد دقيقة للسماح بالصلوات القادمة
            setTimeout(() => {
                delete this.autosholat[id];
            }, 61000);
        }
    }
}
