import { cpus as _cpus, totalmem, freemem } from 'os'
import util from 'util'
import { performance } from 'perf_hooks'
import { sizeFormatter } from 'human-readable'

let format = sizeFormatter({
  std: 'JEDEC',
  decimalPlaces: 2,
  keepTrailingZeroes: false,
  render: (literal, symbol) => `${literal} ${symbol}B`,
})

let handler = async (m, { conn, usedPrefix }) => {

  /* ────── الدردشات ────── */
  const chats = Object.entries(conn.chats).filter(([_, d]) => d?.isChats)
  const groups = chats.filter(([id]) => id.endsWith('@g.us'))
  const privates = chats.filter(([id]) => !id.endsWith('@g.us'))

  /* ────── CPU ────── */
  const cpus = _cpus().map(cpu => {
    cpu.total = Object.values(cpu.times).reduce((a, b) => a + b, 0)
    return cpu
  })

  const cpu = cpus.reduce((a, b, _, { length }) => {
    a.speed += b.speed / length
    a.total += b.total
    for (let k in b.times) a.times[k] += b.times[k]
    return a
  }, {
    speed: 0,
    total: 0,
    times: { user: 0, nice: 0, sys: 0, idle: 0, irq: 0 }
  })

  /* ────── اختبار السرعة ────── */
  let start = performance.now()
  await util.promisify(setTimeout)(1500)
  let ping = performance.now() - start

  /* ────── المستخدم ────── */
  let target = m.quoted?.sender || m.mentionedJid?.[0] || m.sender
  if (!(target in global.db.data.users)) throw 'المستخدم غير مسجل في قاعدة البيانات'

  let avatar = await conn.profilePictureUrl(target, 'image').catch(() => './logo.jpg')

  /* ────── الرسالة ────── */
  const botname = '𝐒𝐎𝐍𝐆 𝐁𝐎𝐓'

  const caption = `
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
*『 مـعـلـومـات الـبـوت 』*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*

*📊 إحصائيات الاستخدام*
*❐⇇ إجمالي الدردشات:* ${chats.length}
*❐⇇ المجموعات:* ${groups.length}
*❐⇇ الخاص:* ${privates.length}
*❐⇇ سرعة الاستجابة:* ${ping.toFixed(2)} ms

*🖥️ أداء الخادم*
*❐⇇ CPU (النظام):* ${cpu.times.sys.toFixed(0)}
*❐⇇ CPU (المستخدم):* ${cpu.times.user.toFixed(0)}
*❐⇇ RAM:* ${format(totalmem())}
*❐⇇ المتاح:* ${format(freemem())}

*🤖 معلومات البوت*
*❐⇇ الاسم:* ${botname}
*❐⇇ المالك:* Ayoub
*❐⇇ البادئة:* ${usedPrefix}
*❐⇇ الوضع:* عام
*❐⇇ المنصة:* سيرفر

*🧠 ذاكرة Node.js*
\`\`\`
${Object.entries(process.memoryUsage())
  .map(([k, v]) => `${k.padEnd(12)}: ${format(v)}`)
  .join('\n')}
\`\`\`

*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> 𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃
`

  await conn.sendFile(
    m.chat,
    avatar,
    'song-info.jpg',
    caption,
    m,
    false,
    { mentions: [target] }
  )

  await conn.sendMessage(m.chat, {
    react: { text: '🐉', key: m.key }
  })
}

handler.help = ['معلومات']
handler.tags = ['رئيسي']
handler.command = ['احصائيات', 'معلومات_بوت', 'info']

export default handler