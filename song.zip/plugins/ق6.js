import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

let handler = async (m, { conn, usedPrefix }) => {
    await conn.sendMessage(m.chat, { react: { text: "👥", key: m.key } });
    let name = await conn.getName(m.sender)
    
    const messageText = `*مـــرحبــــاً بـــكـ/ﻲ يـا ❪${name}❫ في قسم النقابة*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *شرح القسم: إدارة شؤون المجموعة، الألقاب، ومراقبة تفاعل الأعضاء*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *｢👥┊قسم النقابة والجروبات┊👥｣*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
┊📊┊: \`${usedPrefix}معلومات\` | عرض بيانات الجروب.
┊📩┊: \`${usedPrefix}دعوة\` | إرسال رابط دعوة خاص.
┊📋┊: \`${usedPrefix}استمارة\` | عرض استمارة الاستقبال.
┊📈┊: \`${usedPrefix}التفاعل\` | ترتيب تفاعل أعضاء المجموعة.
┊🔥┊: \`${usedPrefix}تفاعله\` | فحص تفاعل عضو محدد.
┊🔇┊: \`${usedPrefix}كتم\` | كتم صوت عضو في الشات.
┊📂┊: \`${usedPrefix}كتم_فك\` | فك كتم صوت عضو في الشات.
┊📂┊: \`${usedPrefix}نسخة\` | نسخ بيانات المجموعة احتياطياً.
┊📟┊: \`${usedPrefix}حسبة\` | تفعيل او تعطيل حسبة الرسائل.
┊📜┊: \`${usedPrefix}القواعد\` | عرض قوانين المجموعة بالترتيبً.
┊🔐┊: \`${usedPrefix}شات\` | فتح او قفل شات المحادثة في الجروب.
┊↪️┊: \`${usedPrefix}لينك\` | نسخ رابط المجموعة وجلبها.
┊🔂┊: \`${usedPrefix}لينك_ريستر\` | إعادة تعيين رابط المجموعة.
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

    const imagePath = path.join(__dirname, '../src/media/Menu4.jpg')
    await conn.sendMessage(m.chat, { image: fs.existsSync(imagePath) ? fs.readFileSync(imagePath) : { url: 'https://qu.ax/yXYsp' }, caption: messageText }, { quoted: m })
}
handler.command = /^(قسم6)$/i
export default handler
