import { toDataURL } from 'qrcode'

let handler = async (m, { text, conn, usedPrefix, command }) => {
    // التحقق من وجود نص
    let content = text ? text : (m.quoted && m.quoted.text ? m.quoted.text : '');
    
    if (!content) return m.reply(`*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*\`˼⚠️˹ تـنـبـيـه هـام\`↶*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*｢🍷｣⇇ يرجى كتابة النص المراد تحويله إلى باركود*
*💡 مثال:* ${usedPrefix}${command} https://github.com
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`);

    try {
        // إنشاء الباركود بجودة عالية (Scale: 10)
        let qrBuffer = await toDataURL(content.slice(0, 2048), { 
            scale: 10,
            margin: 2,
            color: {
                dark: '#000000', // لون المربعات
                light: '#ffffff' // لون الخلفية
            }
        });

        let caption = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*\`˼📱˹ صـانـع الـبـاركـود\`↶*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

*｢✅｣⇇ تـم تـصـمـيـم الـكـود بـنـجـاح*

*｢📄｣ الـنـص الـمـشـفـر:*
『 ${content.length > 50 ? content.substring(0, 50) + '...' : content} 』

*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`;

        // إرسال الصورة
        await conn.sendFile(m.chat, qrBuffer, 'qrcode.png', caption, m);

    } catch (e) {
        console.error(e);
        m.reply('*❌ حدث خطأ أثناء إنشاء الباركود، حاول مرة أخرى.*');
    }
}

handler.help = ['qr', 'كود', 'باركود'];
handler.tags = ['tools'];
handler.command = /^(qrcode|باركود)$/i;

export default handler;
