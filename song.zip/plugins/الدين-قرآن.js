import axios from 'axios'

let handler = async (m, { conn, args, command }) => {
  try {
    let surahName = args.join(' ').replace('سورة', '').trim()

    if (!surahName)
      throw `*❍━━━══『📖』══━━━❍*\n➜ اكتب اسم السورة مثل:\n.${command} سورة الملك\n*❍━━━══『📖』══━━━❍*`

    // 🔹 جلب قائمة السور
    let surahRes = await axios.get('https://www.mp3quran.net/api/v3/suwar?language=ar')
    let surahs = surahRes.data.suwar

    let surah = surahs.find(s => s.name === surahName)
    if (!surah)
      throw `❗ السورة "${surahName}" غير موجودة`

    let surahNumber = String(surah.id).padStart(3, '0')
    let ayatCount =
      surah.ayat ||
      surah.total_verses ||
      surah.verses_count ||
      surah.number_of_ayah ||
      'غير متوفر'

    // 🔹 جلب بيانات الشيخ ماهر
    let recitersRes = await axios.get('https://www.mp3quran.net/api/v3/reciters?language=ar')
    let reciters = recitersRes.data.reciters

    let maher = reciters.find(r => r.name.includes('ماهر'))
    if (!maher || !maher.moshaf?.[0]?.server)
      throw '❗ لم يتم العثور على القارئ ماهر المعيقلي'

    let audioUrl = `${maher.moshaf[0].server}/${surahNumber}.mp3`

    // 🔹 جلب حجم الملف الحقيقي
    let head = await axios.head(audioUrl)
    let sizeInMB = ((head.headers['content-length'] || 0) / (1024 * 1024)).toFixed(2)

    // 🔹 رسالة معلومات
    await conn.sendMessage(m.chat, {
      text: `*❍━━━══『📖』══━━━❍*
⌛️ *جاري تشغيل سورة ${surahName}*
📖 السورة: *${surahName}*
🔢 عدد الآيات: *${ayatCount}*
🎙️ القارئ: *ماهر المعيقلي*
⏺️ الحجم: *${sizeInMB} MB*
*❍━━━══『📖』══━━━❍*`
    }, { quoted: m })

    // 🔹 بث الصوت مباشرة (بدون حفظ)
    let audioStream = await axios.get(audioUrl, { responseType: 'arraybuffer' })

    await conn.sendMessage(m.chat, {
      audio: audioStream.data,
      mimetype: 'audio/mp4',
      ptt: false
    }, { quoted: m })

  } catch (e) {
    console.error(e)
    await conn.sendMessage(m.chat, {
      text: '❗ حدث خطأ أثناء تشغيل السورة، تأكد من الاسم وحاول مرة أخرى.'
    }, { quoted: m })
  }
}

handler.help = ['استماع <اسم السورة>']
handler.tags = ['islam']
handler.command = /^استماع$/i

export default handler