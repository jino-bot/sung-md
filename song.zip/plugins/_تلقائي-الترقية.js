import { canLevelUp, xpRange } from '../lib/levelling.js'

const img = 'https://files.catbox.moe/3y6nci.jpg'

export async function before(m, { conn }) {
  if (!global.db.data?.users?.[m.sender]) return true

  let user = global.db.data.users[m.sender]
  let beforeLevel = user.level

  // رفع المستوى
  while (canLevelUp(user.level, user.exp, global.multiplier)) {
    user.level++
  }

  user.role = global.rpg.role(user.level).name

  if (beforeLevel === user.level) return true

  const usuario = `@${m.sender.split('@')[0]}`
  const mentionedSender = [m.sender]

  let { min, xp } = xpRange(user.level, global.multiplier)

  let text = `
*『🎊┇تـمـت ترقـيـتـك┇🎊』*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
*❐↞👤┇الـمـستخدم:* ${usuario}
*❐↞🎖┇الـرتـــــبـــــة:* ${user.role}
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*

*❐↞🎰┇المستوى:* ${beforeLevel} ⇦ ${user.level}
*❐↞💡┇الخـــبـــرة:* ${user.exp - min} / ${xp - min}
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
> *⌫┇مبروك على المستوى الجديد، واصل التقدم┇*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*
`.trim()

  // ===== معلومات القناة (نفس طريقتك) =====
  const channelInfo = {
  isForwarded: true,
  forwardedNewsletterMessageInfo: {
    newsletterJid: "120363416870755391@newsletter",
    newsletterName: "𝐒𝐔𝐍𝐆 ꒰🐉⃝⃕꒱𝐔𝐏𝐃𝐀𝐓𝐄",
    serverMessageId: -1
  },
  mentionedJid: [m.sender]
}

  await conn.sendMessage(
    m.chat,
    {
      image: { url: img },
      caption: text,
      contextInfo: channelInfo
    },
    { quoted: m }
  )

  return true
}

// ===== نظام الرتب =====
global.rpg = {
  role(level) {
    level = parseInt(level)
    const roles = [
      { name: 'فقير 😞', level: 0 },
      { name: 'مواطن 👨🏻‍💼', level: 2 },
      { name: 'موظف 👨🏻‍🔧', level: 4 },
      { name: 'رجل اعمال 🧑🏻‍✈️', level: 5 },
      { name: 'طباخ 👨🏻‍🍳', level: 10 },
      { name: 'عميل سري 🥷🏻', level: 15 },
      { name: 'عسكري 💂🏻', level: 20 },
      { name: 'كاتب 📚', level: 30 },
      { name: 'جاسوس 🕵🏻', level: 35 },
      { name: 'مصارع 🤼‍♂️', level: 40 },
      { name: 'قاضي 👩‍⚖️', level: 45 },
      { name: 'لاعب كرة قدم ⚽', level: 50 },
      { name: 'رسام 🧑🏻‍🎨', level: 55 },
      { name: 'مدير بنك ❄️', level: 60 },
      { name: 'مدير مدرسة 🧶', level: 65 },
      { name: 'ظابط شرطة 👮‍♂️', level: 70 },
      { name: 'كاتب ✒️', level: 75 },
      { name: 'ظابط جيش 🎖️', level: 80 },
      { name: 'ممثل 👨‍🎤', level: 85 },
      { name: 'نائب الرئيس 🤵🏻‍♂️', level: 90 },
      { name: 'الرئيس 🤵🏻‍♂️', level: 100 }
    ]
    return roles.slice().reverse().find(r => level >= r.level) || roles[0]
  }
}