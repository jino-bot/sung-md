let handler = async (m, { conn, args, participants }) => {
    let users = Object.entries(global.db.data.users).map(([key, value]) => {
        return { ...value, jid: key }
    })
    
    // ترتيب المستخدمين تنازلياً حسب الخبرة
    let sortedExp = users.sort((a, b) => b.exp - a.exp)
    
    // تحديد العشرة الأوائل
    let top = sortedExp.slice(0, 10)
    
    let text = `
*『🏆┇قائمة المتصدرين (الخبرة)┇🏆』*

*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
${top.map((user, i) => {
    let name = conn.getName(user.jid)
    // رموز للمراكز الثلاثة الأولى
    let emoji = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : '🐲'
    return `*${emoji}┇المركز ${i + 1}*
*❐↞👤┇الأسم: @${user.jid.split`@`[0]}*
*❐↞💡┇الخبرة: ${user.exp}*
*❐↞🎰┇المستوى: ${user.level}*
*❐──────────────⟢ـ*`
}).join('\n')}

> *👑 استمر في التفاعل لتتصدر القائمة!*`.trim()

    conn.reply(m.chat, text, m, {
        mentions: top.map(u => u.jid)
    })
}

handler.help = ['leaderboard']
handler.tags = ['main']
handler.command = ['ترتيب', 'المتصدرين']

export default handler
