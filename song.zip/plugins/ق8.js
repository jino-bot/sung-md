import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

let handler = async (m, { conn, usedPrefix }) => {
    await conn.sendMessage(m.chat, { react: { text: "🎡", key: m.key } });
    let name = await conn.getName(m.sender)
    
    const messageText = `*مـــرحبــــاً بـــكـ/ﻲ يـا ❪${name}❫ في قسم الريكنشنات*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *شرح القسم: تفاعلات ومشاعر حركية (GIF) للتعبير عن حالتك*

*⛔ هذا القسم موقوف حاليا وفي حالة صيانه ⛔*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *｢🎡┊قسم الترفيه والمرح┊🎡｣*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
┊😭┊: \`${usedPrefix}ابكي\`     ┊💃┊: \`${usedPrefix}ارقص\`
┊⚔️┊: \`${usedPrefix}اقتل\`     ┊🏠┊: \`${usedPrefix}بيت\`
┊👋┊: \`${usedPrefix}تلويح\`    ┊😜┊: \`${usedPrefix}تنمر\`
┊😊┊: \`${usedPrefix}سعيد\`     ┊🤝┊: \`${usedPrefix}سلم\`
┊🥊┊: \`${usedPrefix}صفع\`      ┊😬┊: \`${usedPrefix}عض\`
┊🫂┊: \`${usedPrefix}عناق\`     ┊🤨┊: \`${usedPrefix}مشكوك\`
┊🙈┊: \`${usedPrefix}كسوف\`     ┊👈┊: \`${usedPrefix}وغز\`
┊🍕┊: \`${usedPrefix}ياكل\`     ┊😇┊: \`${usedPrefix}يبتسم\`
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

    const imagePath = path.join(__dirname, '../src/media/Menu4.jpg')
    await conn.sendMessage(m.chat, { image: fs.existsSync(imagePath) ? fs.readFileSync(imagePath) : { url: 'https://qu.ax/yXYsp' }, caption: messageText }, { quoted: m })
}
handler.command = /^(قسم8)$/i
export default handler
