const linkRegex = /https?:\/\/\S+/i

export async function before(m, { conn, isAdmin, isBotAdmin, isOwner, isROwner }) {
    if (!m.isGroup) return
    if (!m.text) return
    if (m.fromMe || isOwner || isROwner) return

    // جلب إعدادات المجموعة
    let chat = global.db.data.chats[m.chat]
    if (!chat || !chat.antiLink) return

    // التحقق من وجود رابط
    if (!linkRegex.test(m.text)) return

    // استثناء الأدمن
    if (isAdmin) {
        return m.reply('🛡️ مانع الروابط مفعّل، وأنت مستثنى لأنك أدمن.')
    }

    // استثناء رابط نفس المجموعة
    if (isBotAdmin && conn.groupInviteCode) {
        try {
            const code = await conn.groupInviteCode(m.chat)
            const groupLink = `https://chat.whatsapp.com/${code}`
            if (m.text.includes(groupLink)) return
        } catch {}
    }

    const userTag = `@${m.sender.split('@')[0]}`
    const bang = m.key.id
    const delet = m.key.participant || m.sender

    // إذا البوت ليس أدمن
    if (!isBotAdmin) {
        return await conn.sendMessage(
            m.chat,
            {
                text: `*「 🚫 مانع الروابط 」*\n\n${userTag} أرسلت رابطًا، لكن لا أستطيع حذفك لأنني لست أدمن.`,
                mentions: [m.sender]
            },
            { quoted: m }
        )
    }

    // رسالة تحذير
    await conn.sendMessage(
        m.chat,
        {
            text: `*「 🚫 مانع الروابط 」*\n\n${userTag} لقد خالفت قوانين المجموعة بإرسال رابط، سيتم حذف الرسالة وطردك.`,
            mentions: [m.sender]
        },
        { quoted: m }
    )

    // حذف الرسالة
    await conn.sendMessage(m.chat, {
        delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: bang,
            participant: delet
        }
    })

    // طرد العضو
    await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')

    return true
}