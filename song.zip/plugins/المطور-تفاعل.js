// تفاعل.js
let handler = async (m, { args }) => {
  let chat = global.db.data.chats[m.chat]

  if (!args[0]) {
    return m.reply('⚙️ استخدم:\n.تفاعل on\n.تفاعل off')
  }

  if (args[0] === 'on') {
    chat.react = true
    m.reply('✅ تم تفعيل التفاعل بالإيموجي')
  } else if (args[0] === 'off') {
    chat.react = false
    m.reply('❌ تم إيقاف التفاعل بالإيموجي')
  } else {
    m.reply('⚠️ خيار غير صحيح\nاستخدم on أو off')
  }
}

handler.help = ['تفاعل on', 'تفاعل off']
handler.tags = ['group']
handler.command = ['تفاعل','react']

handler.admin = true
handler.group = true

export default handler