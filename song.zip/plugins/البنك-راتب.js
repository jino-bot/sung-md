let handler = async (m, { conn }) => {

    // جلب المستخدم
    let user = global.db.data.users[m.sender]
    if (!user) return m.reply('❌ لم يتم العثور على بياناتك.')

    /* === تهيئة القيم (حل مشكلة null) === */
    user.lastcofre ??= 0
    user.bank ??= 0        // النقاط
    user.coin ??= 0        // العملات
    user.exp ??= 0

    const cooldown = 86400000 // 24 ساعة
    const now = Date.now()

    // تحقق من الوقت
    if (now - user.lastcofre < cooldown) {
        let remaining = cooldown - (now - user.lastcofre)
        return m.reply(
            `🏦 لقد استلمت هديتك اليومية بالفعل\n\n` +
            `⏳ الوقت المتبقي: *${msToTime(remaining)}*`
        )
    }

    /* === الجوائز العشوائية 🎁 === */
    let coins = Math.floor(Math.random() * 10) + 5      // عملات
    let points = Math.floor(Math.random() * 5000) + 500 // نقاط
    let exp = Math.floor(Math.random() * 4000) + 500    // خبرة

    /* === إضافة الجوائز === */
    user.coin += coins
    user.bank += points
    user.exp += exp
    user.lastcofre = now

    /* === الرسالة === */
    let text = `
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
🪙 العملات: *${coins}*
💰 النقاط: *${points}*
⭐ الخبرة: *${exp}*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*

🎉 مبروك! عد بعد 24 ساعة لهدية جديدة.
    `.trim()

    let img = 'https://img.freepik.com/vector-gratis/cofre-monedas-oro-piedrasas-preciosas-cristales-trofeo_107791-7769.jpg?w=2000'

    await conn.sendMessage(
        m.chat,
        { image: { url: img }, caption: text },
        { quoted: m }
    )
}

handler.help = ['راتبي', 'راتب']
handler.tags = ['xp']
handler.command = /^(راتبي|راتب)$/i
handler.level = 0

export default handler

function msToTime(ms) {
    let h = Math.floor(ms / 3600000)
    let m = Math.floor((ms % 3600000) / 60000)
    return `${h} ساعة و ${m} دقيقة`
}