let WAMessageStubType = (await import('@whiskeysockets/baileys')).default

export async function before(m, { conn }) {
if (!m.messageStubType || !m.isGroup) return

const chat = global.db.data.chats[m.chat]
if (!chat?.detect) return

const usuario = `@${m.sender.split('@')[0]}`
const mentionedSender = [m.sender]

// ===== معلومات القناة =====
const channelInfo = {
forwardedNewsletterMessageInfo: {
newsletterJid: "120363416870755391@newsletter", // عدلها لقناتك
newsletterName: "𝐒𝐔𝐍𝐆 ꒰🐉⃝⃕꒱𝐔𝐏𝐃𝐀𝐓𝐄",
serverMessageId: -1
},
isForwarded: true,
forwardingScore: 999,
mentionedJid: mentionedSender
}

const fkontak = {
key: {
participants: "0@s.whatsapp.net",
remoteJid: "status@broadcast",
fromMe: false,
id: "Halo"
},
message: {
contactMessage: {
vcard: `BEGIN:VCARD
VERSION:3.0
N:Sy;Bot;;;
FN:y
item1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}
item1.X-ABLabel:Ponsel
END:VCARD`
}
},
participant: "0@s.whatsapp.net"
}

let nombre = `
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
*❐⇇ تم تغيير اسم المجموعة*
*❐⇇ بواسطة ↜ ❪${usuario}❫*
*❐⇇ الاسم الجديد ↶*
*❐⇇ ┊ \`${m.messageStubParameters?.[0] || ''}\` ┊*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*`.trim()

let foto = `
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
*❐⇇ تم تغيير صورة المجموعة*
*❐⇇ بواسطة ↜ ❪${usuario}❫*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*`.trim()

let newlink = `
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
*❐⇇ تم تغيير رابط المجموعة*
*❐⇇ بواسطة ↜ ❪${usuario}❫*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*`.trim()

let edit = `
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
*❐⇇ تم تغيير إعدادات المجموعة*
*❐⇇ بواسطة ↜ ❪${usuario}❫*
❐⇇ ${m.messageStubParameters?.[0] === 'on' ? '*للمشرفين فقط*' : '*الجميع*'} من يمكنه التحدث
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*`.trim()

let admingp = `
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
*❐⇇ تم ترقية ↜ ❪@${m.messageStubParameters?.[0]?.split('@')[0]}❫*
*❐⇇ بواسطة ↜ ❪${usuario}❫*
*❐↜ مبروك الترقية ⤴️👑*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*`.trim()

let noadmingp = `
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
*❐⇇ تم إعفاء ↜ ❪@${m.messageStubParameters?.[0]?.split('@')[0]}❫*
*❐⇇ بواسطة ↜ ❪${usuario}❫*
*❐↜ للأسف تم إعفاؤك ⤵️🧳*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*`.trim()

// ===== الأحداث =====
if (m.messageStubType == 21) {
await conn.sendMessage(m.chat, { text: nombre, contextInfo: channelInfo }, { quoted: fkontak })
}

else if (m.messageStubType == 22) {
await conn.sendMessage(m.chat, { text: foto, contextInfo: channelInfo }, { quoted: fkontak })
}

else if (m.messageStubType == 23) {
await conn.sendMessage(m.chat, { text: newlink, contextInfo: channelInfo }, { quoted: fkontak })
}

else if (m.messageStubType == 25) {
await conn.sendMessage(m.chat, { text: edit, contextInfo: channelInfo }, { quoted: fkontak })
}

else if (m.messageStubType == 29) {
await conn.sendMessage(m.chat, {
text: admingp,
contextInfo: {
...channelInfo,
mentionedJid: [m.sender, m.messageStubParameters?.[0]].filter(Boolean)
}
}, { quoted: fkontak })
}

else if (m.messageStubType == 30) {
await conn.sendMessage(m.chat, {
text: noadmingp,
contextInfo: {
...channelInfo,
mentionedJid: [m.sender, m.messageStubParameters?.[0]].filter(Boolean)
}
}, { quoted: fkontak })
}

else {
console.log({
messageStubType: m.messageStubType,
messageStubParameters: m.messageStubParameters,
type: WAMessageStubType[m.messageStubType]
})
}
}