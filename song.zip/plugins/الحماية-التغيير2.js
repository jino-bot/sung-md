let handler = async (m, { conn, args, usedPrefix, command }) => {
  let chat = global.db.data.chats[m.chat]
  if (!chat) return

  // ===== عرض الحالة =====
  if (!args[0]) {
    let status = chat.protectAll ? 'مفعل ✅' : 'معطل ❌'
    return conn.reply(
      m.chat,
      `*🛡️ حالة الحماية المطلقة:* ${status}\n\n` +
      `*الاستخدام:*\n` +
      `• ${usedPrefix + command} on\n` +
      `• ${usedPrefix + command} off`,
      m
    )
  }

  // ===== تفعيل =====
  if (args[0] === 'on') {
    if (chat.protectAll) {
      return m.reply('⚠️ الحماية المطلقة مفعلة بالفعل.')
    }

    let metadata = await conn.groupMetadata(m.chat)

    chat.protectAll = true
    chat.groupState = {
      name: metadata.subject || '',
      desc: metadata.desc || '',
      settings: metadata.announce ? 'announcement' : 'not_announcement',
      photo: await conn.profilePictureUrl(m.chat, 'image').catch(() => null)
    }

    return m.reply('✅ تم تفعيل الحماية المطلقة للمجموعة.')
  }

  // ===== تعطيل =====
  if (args[0] === 'off') {
    if (!chat.protectAll) {
      return m.reply('⚠️ الحماية المطلقة معطلة بالفعل.')
    }

    chat.protectAll = false
    chat.groupState = null

    return m.reply('❌ تم تعطيل الحماية المطلقة.')
  }

  // ===== خطأ =====
  return m.reply(
    `❌ خيار غير صحيح\n\n` +
    `*استخدم فقط:*\n` +
    `• ${usedPrefix + command} on\n` +
    `• ${usedPrefix + command} off`
  )
}

// ===== تعريف الأمر =====
handler.help = ['مطلقة']
handler.tags = ['group']
handler.command = ['مطلقة', 'absolute']

// ===== قيود =====
handler.group = true
handler.admin = true

export default handler