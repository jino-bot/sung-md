let handler = async (m, { conn, text, usedPrefix, command, isAdmin, isOwner }) => {
    // التحقق من الصلاحيات
    if (!isAdmin && !isOwner) return m.reply('*[❗] هذا الأمر للمشرفين فقط*')

    let who
    if (m.isGroup) {
        who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? (text.replace(/[^0-9]/g, '') + '@s.whatsapp.net') : false
    }

    if (!who) return m.reply(`*[❗] منشن الشخص أو رد على رسالته*\n\n*مثال: ${usedPrefix + command} @منشن*`)

    let user = global.db.data.users[who] ||= {}
    
    if (command === 'كتم') {
        if (user.muto) return m.reply('*[⚠️] هذا العضو مكتوم بالفعل.*')
        user.muto = true
        await conn.reply(m.chat, `*✅ تم كتم العضو بنجاح*\n\n👤 العضو: @${who.split('@')[0]}\n🚫 سيتم حذف أي رسالة يرسلها تلقائياً.`, m, { mentions: [who] })
    }

    if (command === 'كتم_فك' || command === 'فك_كتم') {
        if (!user.muto) return m.reply('*[⚠️] هذا العضو غير مكتوم.*')
        user.muto = false
        await conn.reply(m.chat, `*✅ تم فك الكتم عن العضو*\n\n👤 العضو: @${who.split('@')[0]}\n✨ يمكنه الآن التحدث بحرية.`, m, { mentions: [who] })
    }
}

handler.help = ['كتم', 'كتم_فك']
handler.tags = ['group']
handler.command = /^(كتم|كتم_فك|فك_كتم)$/i
handler.group = true
handler.admin = true

export default handler
