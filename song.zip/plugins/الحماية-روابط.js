let handler = async (m, { conn, args, usedPrefix, command }) => {
    // التأكد من وجود سجل للمجموعة في قاعدة البيانات
    let chat = global.db.data.chats[m.chat]
    
    // الحالة 1: كتابة الأمر بدون on أو off (عرض الحالة)
    if (!args[0]) {
        let status = chat.antiLink ? 'مفعل ✅' : 'معطل ❌'
        return conn.reply(m.chat, `*🛡️ حالة مانع الروابط:* ${status}\n\n*استخدم:* \n• ${usedPrefix + command} on (للتفعيل)\n• ${usedPrefix + command} off (للتعطيل)`, m)
    }

    // الحالة 2: تفعيل الميزة
    if (args[0] === 'on') {
        if (chat.antiLink) return m.reply('⚠️ الميزة مفعلة بالفعل في هذه المجموعة.')
        chat.antiLink = true
        m.reply('✅ تم تفعيل مانع الروابط بنجاح.')
    } 
    
    // الحالة 3: تعطيل الميزة
    else if (args[0] === 'off') {
        if (!chat.antiLink) return m.reply('⚠️ الميزة معطلة بالفعل في هذه المجموعة.')
        chat.antiLink = false
        m.reply('❌ تم تعطيل مانع الروابط بنجاح.')
    } 
    
    // في حال كتابة شيء غير on أو off
    else {
        m.reply(`خطأ! استخدم:\n*${usedPrefix + command} on*\n*${usedPrefix + command} off*`)
    }
}

// تعريفات الأمر
handler.help = ['روابط']
handler.tags = ['group']
handler.command = ['روابط', 'antilink'] 

// القيود (فقط المشرفين وفي المجموعات)
handler.group = true
handler.admin = true

export default handler
