let handler = async (m, { conn, args }) => {
  const prompt = args.join(' ').trim()

  if (!prompt) {
    return conn.reply(
      m.chat,
      '❌ أرسل الوصف بعد الأمر.\n\nمثال:\n.ارسم لوفي يقفز في السماء بأسلوب أنميشن',
      m
    )
  }

  try {
    // ستايل أنميشن ملون
    const artPrompt = `
${prompt},
anime animation style,
colorful,
high quality,
studio ghibli style,
soft lighting,
smooth shading,
vibrant colors
    `.trim()

    const imageUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(artPrompt)}`

    const caption = `
*❐═━━━═╊⊰🎬🎨⊱╉═━━━═❐*

✏️ *الوصف:* ${prompt}
🎬 *النمط:* أنميشن / أنمي ملون

*❐═━━━═╊⊰🎬🎨⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*
    `.trim()

    // تفاعل عند البدء
    try {
      await conn.sendMessage(m.chat, {
        react: { text: '🎬', key: m.key }
      })
    } catch {}

    await conn.sendMessage(
      m.chat,
      {
        image: { url: imageUrl },
        caption
      },
      { quoted: m }
    )

    // تفاعل نجاح
    try {
      await conn.sendMessage(m.chat, {
        react: { text: '✨', key: m.key }
      })
    } catch {}

  } catch (e) {
    console.error('❌ خطأ في أمر ارسم أنميشن:', e)
    await conn.reply(m.chat, '❌ حدث خطأ أثناء إنشاء صورة الأنميشن.', m)
  }
}

handler.help = ['انميشن <وصف>']
handler.tags = ['ai', 'tools']
handler.command = /^انميشن$/i

export default handler
