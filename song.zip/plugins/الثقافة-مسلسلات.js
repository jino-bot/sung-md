import fs from 'fs';
import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

const timeout = 60000;
const poin = 200;

let handler = async (m, { conn, command }) => {
    conn.tekateki = conn.tekateki || {};
    let id = m.chat;

    // ===== معالجة الإجابة =====
    if (command.startsWith('اجابة_مسلسل_')) {
        let game = conn.tekateki[id];
        if (!game) return;

        let index = parseInt(command.split('_')[2]);
        let selected = game[4][index - 1];

        let correct = game[1].response.trim().toLowerCase();
        let answer = selected.trim().toLowerCase();

        if (correct === answer) {
            let db = global.db.data;

            if (!db.users[m.sender]) {
                db.users[m.sender] = { bank: 0, exp: 0, coin: 0, level: 0 };
            }

            db.users[m.sender].bank += poin;
            global.db.data = db;

            clearTimeout(game[3]);
            delete conn.tekateki[id];

            const msg = {
                body: { text: `*⎔⋅• ━╼╃ ⌬〔🐲〕⌬ ╄╾ ━ •⋅⎔*\n*🎬 إجابة صحيحة!*\n*🏦 الجائزة ⇇ ${poin} نقطة*\n*⎔⋅• ━╼╃ ⌬〔🐲〕⌬ ╄╾ ━ •⋅⎔*` },
                footer: { text: '𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
                nativeFlowMessage: {
                    buttons: [
                        {
                            name: 'quick_reply',
                            buttonParamsJson: JSON.stringify({
                                display_text: '🔄 مسلسل آخر',
                                id: '.مسلسل'
                            })
                        }
                    ]
                }
            };
            return conn.relayMessage(m.chat, { viewOnceMessage: { message: { interactiveMessage: msg } } }, {});
        } else {
            game[5]--;
            if (game[5] > 0) {
                return conn.reply(m.chat, '*❌ إجابة خاطئة*\n*تبقى محاولة واحدة ⏳*', m);
            } else {
                clearTimeout(game[3]);
                delete conn.tekateki[id];

                const msg = {
                    body: { text: `*❌ انتهت المحاولات*\n*✅ الإجابة الصحيحة: ${game[1].response}*` },
                    footer: { text: '𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: 'quick_reply',
                                buttonParamsJson: JSON.stringify({
                                    display_text: '🔄 حاول مجددًا',
                                    id: '.مسلسل'
                                })
                            }
                        ]
                    }
                };
                return conn.relayMessage(m.chat, { viewOnceMessage: { message: { interactiveMessage: msg } } }, {});
            }
        }
    }

    // ===== بدء لعبة جديدة =====
    if (id in conn.tekateki) {
        return conn.reply(m.chat, '⚠️ هناك سؤال مسلسلات لم يُحل بعد!', conn.tekateki[id][0]);
    }

    let filePath = './src/game/مسلسلات.json';
    if (!fs.existsSync(filePath)) return conn.reply(m.chat, '❌ ملف المسلسلات غير موجود!', m);

    let data = JSON.parse(fs.readFileSync(filePath));
    let json = data[Math.floor(Math.random() * data.length)];

    let options = [json.response];
    while (options.length < 4) {
        let r = data[Math.floor(Math.random() * data.length)].response;
        if (!options.includes(r)) options.push(r);
    }
    options.sort(() => Math.random() - 0.5);

    const media = await prepareWAMessageMedia(
        { image: { url: 'https://files.catbox.moe/bh92ec.jpg' } },
        { upload: conn.waUploadToServer }
    );

    const interactiveMessage = {
        body: {
            text: `*⎔⋅• ━╼╃ ⌬〔🐲〕⌬ ╄╾ ━ •⋅⎔*\n*🎬 سؤال من عالم المسلسلات*\n\n*❓ ${json.question}*\n\n*⏱️ 60 ثانية*\n*🏦 الجائزة: ${poin} نقطة*\n*لديك محاولتين فقط*`
        },
        footer: { text: '𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
        header: {
            hasMediaAttachment: true,
            imageMessage: media.imageMessage
        },
        nativeFlowMessage: {
            buttons: options.map((o, i) => ({
                name: 'quick_reply',
                buttonParamsJson: JSON.stringify({
                    display_text: o,
                    id: `.اجابة_مسلسل_${i + 1}`
                })
            }))
        }
    };

    let msg = generateWAMessageFromContent(
        m.chat,
        { viewOnceMessage: { message: { interactiveMessage } } },
        { userJid: conn.user.jid, quoted: m }
    );

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    conn.tekateki[id] = [
        msg,
        json,
        poin,
        setTimeout(async () => {
            if (conn.tekateki[id]) {
                await conn.reply(m.chat, `⌛ انتهى الوقت\n✅ الإجابة: ${json.response}`, m);
                delete conn.tekateki[id];
            }
        }, timeout),
        options,
        2
    ];
};

handler.help = ['مسلسل'];
handler.tags = ['game'];
handler.command = /^(مسلسل|اجابة_مسلسل_\d+)$/i;

export default handler;