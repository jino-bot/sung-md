
import { exec } from 'child_process'
import { promisify } from 'util'
import fs from 'fs'
import path from 'path'

const execAsync = promisify(exec)

let handler = async (m, { conn, args }) => {
  const chatId = m.chat

  // ✅ الحالة 1: المستخدم كتب .تيك + رابط فقط
  if (args.length === 1 && args[0].startsWith('http')) {
    const url = args[0]

    // جلب معلومات الفيديو فقط
    let info
    try {
      const { stdout } = await execAsync(
        `yt-dlp --print "%(title)s|%(duration_string)s|%(uploader)s" "${url}"`
      )
      const [title, duration, uploader] = stdout.trim().split('|')
      info = { title, duration, uploader }
    } catch {
      info = { title: 'غير معروف', duration: 'غير معروف', uploader: 'غير معروف' }
    }

    return conn.sendMessage(chatId, {
      text:
        `┏━━━✦ 『 📊 معلومات المقطع 』✦━━━┓\n\n` +
        `🎬 العنوان: ${info.title}\n` +
        `⏱️ المدة: ${info.duration}\n` +
        `📤 الناشر: ${info.uploader}\n\n` +
        `اختر طريقة التحميل:\n` +
        `┗━━━━━━━━━━━━━━━━━━━━┛`,
      buttons: [
        { buttonId: `.تيك فيديو ${url}`, buttonText: { displayText: '🎬 تحميل فيديو' }, type: 1 },
        { buttonId: `.تيك صوت ${url}`, buttonText: { displayText: '🎧 تحميل صوت' }, type: 1 }
      ],
      headerType: 1
    }, { quoted: m })
  }

  // ❌ لو الصيغة ناقصة
  if (args.length < 2) {
    return conn.sendMessage(chatId, {
      text: `❌ *| الصيغة صحيحة كالتالي:*\n\n.تيك (الرابط)\n.تيك فيديو (الرابط)\n.تيك صوت (الرابط)`
    }, { quoted: m })
  }

  // ✅ الحالة 2: تحميل فعلي (فيديو / صوت)
  const format = args[0].toLowerCase()
  const url = args[1]

  const tempDir = './temp'
  if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true })

  const filePath = path.join(
    tempDir,
    `${Date.now()}.${format === 'صوت' ? 'mp3' : 'mp4'}`
  )

  await conn.sendMessage(chatId, {
    text: `⏳ جاري التحميل...\n🎬 النوع: ${format}`
  }, { quoted: m })

  // 🎬 فيديو
  if (format === 'فيديو') {
    exec(`yt-dlp -f mp4 -o "${filePath}" "${url}"`, async err => {
      if (err || !fs.existsSync(filePath))
        return conn.sendMessage(chatId, { text: '❌ فشل تحميل الفيديو' }, { quoted: m })

      await conn.sendMessage(chatId, {
        video: fs.readFileSync(filePath),
        caption: '🎬 تم التحميل بنجاح\n🤖 بواسطة: سونغ'
      }, { quoted: m })

      fs.unlinkSync(filePath)
    })
  }

  // 🎧 صوت
  else if (format === 'صوت') {
    exec(`yt-dlp -x --audio-format mp3 -o "${filePath}" "${url}"`, async err => {
      if (err || !fs.existsSync(filePath))
        return conn.sendMessage(chatId, { text: '❌ فشل تحميل الصوت' }, { quoted: m })

      await conn.sendMessage(chatId, {
        audio: fs.readFileSync(filePath),
        mimetype: 'audio/mpeg',
        caption: '🎧 تم تحميل الصوت\n🤖 بواسطة: سونغ'
      }, { quoted: m })

      fs.unlinkSync(filePath)
    })
  }

  else {
    return conn.sendMessage(chatId, {
      text: '❗ اختر: فيديو أو صوت'
    }, { quoted: m })
  }
}

handler.help = ['تيك <رابط>', 'تيك <فيديو|صوت> <رابط>']
handler.tags = ['downloader']
handler.command = ['تيك']

export default handler