import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

let handler = async (m, { conn, usedPrefix }) => {
    try {
        // إرسال تفاعل 🧠
        await conn.sendMessage(m.chat, { react: { text: "🧠", key: m.key } });

        let name = await conn.getName(m.sender)
        
        const messageText = `*مـــرحبــــاً بـــكـ/ﻲ يـا ❪${name}❫ في قسم الذكاء الاصطناعي*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *شرح القسم: تفاعل مع أحدث نماذج الذكاء الاصطناعي للدردشة، البحث، وتوليد المحتوى*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *｢🤖┊قسم الـذكـاء الاصـطـنـاعـي┊🤖｣*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
┊🎙️┊: \`${usedPrefix}اليس\`
> شخصية Alice الذكية تجيب عليك برسائل صوتية.
┊🔍┊: \`${usedPrefix}بحث\`
> الحصول على ملخصات ذكية وشاملة لأي موضوع.
┊💬┊: \`${usedPrefix}جبيتي\`
> محادثة متطورة مع ChatGPT v5 الجديد.
┊🕌┊: \`${usedPrefix}صالح\`
> استفسارات دينية مع بوت الشيخ صالح الذكي.
┊🐾┊: \`${usedPrefix}صوت\`
> توليد أصوات حيوانات واقعية بالذكاء الاصطناعي.
┊😈┊: \`${usedPrefix}كيرا\`
> ردود ساخرة وجريئة من شخصية كيرا.
┊🤣┊: \`${usedPrefix}نكتة\`
> توليد نكت طريفة وجديدة كلياً.
┊🖼️┊: \`${usedPrefix}توليد\`
> تحويل خيالك إلى صور واقعية عبر الوصف.
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

    const imagePath = path.join(__dirname, '../src/media/Menu4.jpg')

    if (fs.existsSync(imagePath)) {
        await conn.sendMessage(m.chat, { 
            image: { url: imagePath }, 
            caption: messageText 
        }, { quoted: m })
    } else {
        await conn.sendMessage(m.chat, { text: messageText }, { quoted: m })
    }

    } catch (err) {
        console.error('❌ Error in AI Menu:', err)
    }
}

handler.help = ['الذكاء']
handler.tags = ['main']
handler.command = /^(قسم15)$/i 

export default handler
