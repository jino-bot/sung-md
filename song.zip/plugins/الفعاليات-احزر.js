import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

const timeout = 60000;
const reward = 150; // نقاط البنك

let handler = async (m, { conn, command }) => {
    conn.MONTE = conn.MONTE || {};
    let id = m.chat;

    if (command.startsWith('جوابي_')) {
        let MONTE = conn.MONTE[id];

        if (!MONTE) {
            return conn.reply(m.chat, '*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*لا توجد لعبة نشطة حالياً ⚠️*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*', m);
        }

        let selectedAnswerIndex = parseInt(command.split('_')[1]);
        let selectedAnswer = MONTE.options[selectedAnswerIndex - 1];
        let isCorrect = MONTE.correctAnswer === selectedAnswer;

        if (isCorrect) {
    let db = global.db.data

    // تأكيد وجود المستخدم
    if (!db.users[m.sender]) {
        db.users[m.sender] = {
            bank: 0,
            exp: 0,
            coin: 0,
            level: 0
        }
    }

    // إضافة النقاط إلى bank
    db.users[m.sender].bank = (db.users[m.sender].bank || 0) + reward

    // 🔥 حفظ فعلي في database.json
    global.db.data = db

    clearTimeout(MONTE.timer)
    delete conn.MONTE[id]

            const interactiveMessage = {
                body: { text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*🎉 إجابتك صحيحة مبروك 🎉*\n*🏦┊الجائزة┊⇇ 150 نقطة*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*` },
                footer: { text: '𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
                nativeFlowMessage: {
                    buttons: [{ name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🔄 شخصية أخرى', id: '.احزر' }) }]
                }
            };
            return conn.relayMessage(m.chat, { viewOnceMessage: { message: { interactiveMessage } } }, {});

        } else {
            MONTE.attempts -= 1;
            if (MONTE.attempts > 0) {
                return conn.reply(m.chat, `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*إجابتك خاطئة ❌*\n*لديك محاولة واحدة أخرى ⏳*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`, m);
            } else {
                const correctAnswer = MONTE.correctAnswer;
                clearTimeout(MONTE.timer);
                delete conn.MONTE[id];

                const interactiveMessage = {
                    body: { text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*إجابتك خاطئة ❌*\n*إنتهت المحاولات المتاحة*\n*✅┊الشخصية هي┊⇇ ${correctAnswer}*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*` },
                    footer: { text: '𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
                    nativeFlowMessage: {
                        buttons: [{ name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🔄 حاول مرة أخرى', id: '.احزر' }) }]
                    }
                };
                return conn.relayMessage(m.chat, { viewOnceMessage: { message: { interactiveMessage } } }, {});
            }
        }
    } else {
        if (conn.MONTE[id]) {
            return conn.reply(m.chat, '*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*هناك لعبة جارية بالفعل! أجب أولاً ⚠️*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*', m);
        }

        try {
            const response = await fetch('https://gist.githubusercontent.com/Kyutaka101/98d564d49cbf9b539fee19f744de7b26/raw/f2a3e68bbcdd2b06f9dbd5f30d70b9fda42fec14/guessflag');
            const MONTEData = await response.json();
            const MONTEItem = MONTEData[Math.floor(Math.random() * MONTEData.length)];
            const { img, name } = MONTEItem;

            let options = [name];
            while (options.length < 4) {
                let randomItem = MONTEData[Math.floor(Math.random() * MONTEData.length)].name;
                if (!options.includes(randomItem)) options.push(randomItem);
            }
            options.sort(() => Math.random() - 0.5);

            const media = await prepareWAMessageMedia({ image: { url: img } }, { upload: conn.waUploadToServer });

            const interactiveMessage = {
                body: {
                    text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*✧ \`خمن شخصية الأنمي\` ✧*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n\n*❏- 👤 الـشخصية : ⟦ اختر الاسم الصحيح لصاحب الصورة الظاهرة ⟧*\n\n*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*\n*❏- ⏱️ الـوقـت: ⟦60 ثانـية⟧*\n**❏- 🏦 الجائزة: ⟦150 نقطة⟧*\n*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*\n> اختر اسم الشخصية قبل انتهاء الوقت\n> لديك محاولتين فقط\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅╔*\n> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`,
                },
                footer: { text: '𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
                header: {
                    hasMediaAttachment: true,
                    imageMessage: media.imageMessage,
                },
                nativeFlowMessage: {
                    buttons: options.map((option, index) => ({
                        name: 'quick_reply',
                        buttonParamsJson: JSON.stringify({
                            display_text: `┊${index + 1}┊⇇${option}`,
                            id: `.جوابي_${index + 1}`
                        })
                    })),
                },
            };

            let msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: { message: { interactiveMessage } },
            }, { userJid: conn.user.jid, quoted: m });

            await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

            conn.MONTE[id] = {
                correctAnswer: name,
                options: options,
                attempts: 2,
                timer: setTimeout(async () => {
                    if (conn.MONTE[id]) {
                        await conn.reply(m.chat, `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*⌛ انتهى الوقت المسموح*\n*✅ الشخصية هي: ${name}*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`, m);
                        delete conn.MONTE[id];
                    }
                }, timeout)
            };

        } catch (e) {
            console.error(e);
            conn.reply(m.chat, '❌ حدث خطأ في تحميل الشخصية.', m);
        }
    }
};

handler.help = ['احزر'];
handler.tags = ['game'];
handler.command = /^(احزر|احزري|جوابي_\d+)$/i;

export default handler;
