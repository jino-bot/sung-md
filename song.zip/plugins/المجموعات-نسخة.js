import { jidDecode } from '@whiskeysockets/baileys'
import fs from 'fs'
import fetch from 'node-fetch'
import { join } from 'path'

const decodeJid = jid =>
  (jidDecode(jid)?.user || jid.split('@')[0]) + '@s.whatsapp.net'

let handler = async (m, { conn, args }) => {
  try {
    if (!m.isGroup)
      return m.reply('*⚠️ هذا الأمر يعمل داخل المجموعات فقط.*')

    const isOwner = global.owner
      .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
      .includes(m.sender)

    if (!isOwner)
      return m.reply('*❌ هذا الأمر مخصص لمالك البوت فقط.*')

    const action = args[0]?.toLowerCase()
    const name = args.slice(1).join(' ').trim()
    const baseDir = join('tmp', 'copy-group')

    const deco = {
      guide: `*❍━━━══━━❪📦❫━━══━━━❍*
*➤ أوامر النسخة:*

• .نسخة نسخ [اسم]  
• .نسخة لصق [اسم]  
• .نسخة حذف [اسم]  
• .نسخة حافظة  

*❍━━━══━━❪📦❫━━══━━━❍*`,
      copied: n => `*✅ تم حفظ نسخة المجموعة باسم:* 「${n}」`,
      pasted: n => `*📎 تم تطبيق النسخة:* 「${n}」`,
      deleted: n => `*🗑️ تم حذف النسخة:* 「${n}」`,
      notFound: n => `*❌ لا توجد نسخة باسم:* 「${n}」`,
      needName: ex => `*⚠️ اكتب اسم النسخة*\nمثال:\n${ex}`
    }

    if (!action) return m.reply(deco.guide)

    /* ===== نسخ ===== */
    if (action === 'نسخ') {
      if (!name) return m.reply(deco.needName('.نسخة نسخ مجموعة1'))

      const meta = await conn.groupMetadata(m.chat)
      const data = {
        subject: meta.subject,
        description: meta.desc || '',
        settings: {
          announce: meta.announce,
          restrict: meta.restrict
        },
        created: meta.creation,
        id: meta.id
      }

      const dir = join(baseDir, name)
      fs.mkdirSync(dir, { recursive: true })
      fs.writeFileSync(join(dir, 'groupData.json'), JSON.stringify(data, null, 2))

      try {
        const pfp = await conn.profilePictureUrl(m.chat, 'image')
        const res = await fetch(pfp)
        const buf = Buffer.from(await res.arrayBuffer())
        fs.writeFileSync(join(dir, `${name}.jpg`), buf)
      } catch {}

      return m.reply(deco.copied(name))
    }

    /* ===== لصق ===== */
    if (action === 'لصق') {
      if (!name) return m.reply(deco.needName('.نسخة لصق مجموعة1'))

      const file = join(baseDir, name, 'groupData.json')
      if (!fs.existsSync(file)) return m.reply(deco.notFound(name))

      const data = JSON.parse(fs.readFileSync(file))
      await conn.groupUpdateSubject(m.chat, data.subject)
      await conn.groupUpdateDescription(m.chat, data.description)
      await conn.groupSettingUpdate(m.chat, data.settings.announce ? 'announcement' : 'not_announcement')
      await conn.groupSettingUpdate(m.chat, data.settings.restrict ? 'locked' : 'unlocked')

      const img = join(baseDir, name, `${name}.jpg`)
      if (fs.existsSync(img))
        await conn.updateProfilePicture(m.chat, { url: img })

      return m.reply(deco.pasted(name))
    }

    /* ===== حذف ===== */
    if (action === 'حذف') {
      if (!name) return m.reply(deco.needName('.نسخة حذف مجموعة1'))

      const dir = join(baseDir, name)
      if (!fs.existsSync(dir)) return m.reply(deco.notFound(name))

      fs.rmSync(dir, { recursive: true, force: true })
      return m.reply(deco.deleted(name))
    }

    /* ===== الحافظة ===== */
    if (action === 'حافظة') {
      if (!fs.existsSync(baseDir))
        return m.reply('*📂 لا توجد أي نسخ محفوظة.*')

      const list = fs.readdirSync(baseDir)
      if (!list.length)
        return m.reply('*📂 لا توجد أي نسخ محفوظة.*')

      let text = `*❍━━━══━━❪📁❫━━══━━━❍*\n`
      list.forEach((n, i) => text += `*${i + 1}.* ${n}\n`)
      text += `*❍━━━══━━❪📁❫━━══━━━❍*`
      return m.reply(text)
    }

    return m.reply(deco.guide)

  } catch (e) {
    console.error(e)
    m.reply('*❌ حدث خطأ أثناء تنفيذ الأمر.*')
  }
}

handler.help = ['نسخة']
handler.tags = ['group']
handler.command = /^نسخة$/i
handler.group = true

export default handler