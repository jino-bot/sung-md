import { exec } from 'child_process'
import fs from 'fs'
import path from 'path'

let handler = async (m, { conn, args }) => {
  const chatId = m.chat

  if (!args || args.length === 0) {
    return conn.sendMessage(chatId, {
      text: `❌ *| الصيغة ناقصة!*\n\nاستخدم:\n\`.تنزيل [عنوان البحث]\``
    }, { quoted: m })
  }

  const query = args.join(' ').trim()
  const tempDir = './temp'
  if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true })

  const videoPath = path.join(tempDir, `tiktok_${Date.now()}.mp4`)

  await conn.sendMessage(chatId, {
    text: `⏳ *| جاري البحث وتحميل الفيديو الأول من TikTok...*\n📌 البحث عن: "${query}"`
  }, { quoted: m })

  const errorMsg =
    `❌ *| فشل تحميل الفيديو!*\n📌 تأكد من أن TikTok متاح أو جرب إعادة المحاولة.`

  // 🔍 البحث عن أول نتيجة وتحميلها
  const searchCommand = `yt-dlp "ytsearch1:${query}" -f mp4 -o "${videoPath}"`

  exec(searchCommand, async err => {
    if (err || !fs.existsSync(videoPath)) {
      console.error('[ERROR] تحميل الفيديو:', err?.message || err)
      return conn.sendMessage(chatId, { text: errorMsg }, { quoted: m })
    }

    try {
      await conn.sendMessage(chatId, {
        video: fs.readFileSync(videoPath),
        caption:
          `┏━━━✦ 『 📥 تم التحميل بنجاح 』✦━━━┓\n\n` +
          `🎬 النوع: فيديو\n` +
          `📱 المصدر: TikTok\n` +
          `📝 البحث عن: ${query}\n` +
          `🤖 بواسطة: سونغ\n` +
          `┗━━━━━━━━━━━━━━━━━━━━┛`
      }, { quoted: m })
    } finally {
      try {
        if (fs.existsSync(videoPath)) fs.unlinkSync(videoPath)
      } catch {}
    }
  })
}

handler.help = ['تنزيل <عنوان البحث>']
handler.tags = ['downloader']
handler.command = ['تنزيل']

export default handler