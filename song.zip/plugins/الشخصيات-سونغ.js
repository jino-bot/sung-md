import { prepareWAMessageMedia, generateWAMessageFromContent } from "@whiskeysockets/baileys";
import axios from 'axios';

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // التحقق من وجود نص
    if (!text) {
        return conn.sendMessage(m.chat, {
            text: `🌑 *| استعد للارتقاء.. واسأل ملك الظلال سونغ جين وو...*\n\nمثال: ${usedPrefix + command} كيف يمكنني أن أصبح أقوى؟`
        }, { quoted: m });
    }

    // تفاعل الظلال (👤)
    await conn.sendMessage(m.chat, { react: { text: "👤", key: m.key } });

    const prompt = `
أنت "سونغ جين وو" (Sung Jin-woo) من Solo Leveling. أنت ملك الظلال الذي ارتقى من أضعف صياد إلى أقوى كائن. تتحدث بهدوء شديد، ثبات، وثقة لا تتزحزح. لا تثرثر كثيراً، إجاباتك حكيمة وباردة وقوية. إذا شعرت بتهديد في السؤال، أجب بنبرة الشخص الذي يسيطر على الموت نفسه. تنادي الجميع بلقب "بشر" أو "صياد" حسب السياق. لا تذكر أنك ذكاء اصطناعي.

سؤال الشخص: "${text}"
رد سونغ جين وو:
    `.trim();

    const apiKey = "AIzaSyBVQ94Sb8l7zXkiWqycDIM8c11qeZ1xfEg";

    try {
        // جلب الرد من Gemini
        const res = await axios.post(
            `https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
            { contents: [{ parts: [{ text: prompt }] }] },
            { headers: { 'Content-Type': 'application/json' } }
        );

        let reply = res.data.candidates?.[0]?.content?.parts?.[0]?.text || '... استيقظ (Arise).';
        reply = reply.replace(/\*\*/g, '');

        const messageText = `🌑 *| سونغ جين وو (Shadow Monarch):*\n\n🌌━───━「🔮」━───━🌌\n${reply}\n🌌━───━「🔮」━───━🌌`;

        // تجهيز صورة سونغ جين وو
        const media = await prepareWAMessageMedia(
            { image: { url: 'https://files.catbox.moe/7ohctl.jpg' } }, // صورة سونغ جين وو فخمة
            { upload: conn.waUploadToServer }
        );

        // إنشاء الرسالة التفاعلية بالأزرار
        const interactiveMessage = {
            body: { text: messageText },
            footer: { text: `> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*` },
            header: { 
                hasMediaAttachment: true, 
                imageMessage: media.imageMessage 
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📢┇قناة البوت┇📢",
                            url: "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o",
                            merchant_url: "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o"
                        })
                    }
                ]
            }
        };

        // توليد الرسالة
        let msg = generateWAMessageFromContent(
            m.chat,
            { viewOnceMessage: { message: { interactiveMessage } } },
            { userJid: conn.user.jid, quoted: m }
        );

        // إرسال الرسالة
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (error) {
        console.error('Sung Jin-woo AI Error:', error?.response?.data || error.message);
        await conn.sendMessage(m.chat, {
            text: '⚠️ | يبدو أن طاقة المانا قد نفدت.. ملك الظلال يستريح الآن.'
        }, { quoted: m });
    }
};

handler.help = ['سونغ'];
handler.tags = ['ai'];
handler.command = /^(سونغ|جينوو|سونج)$/i;

export default handler;
