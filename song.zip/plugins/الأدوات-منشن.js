import { prepareWAMessageMedia, generateWAMessageFromContent } from "@whiskeysockets/baileys";

let handler = async (m, { conn }) => {
    // رابط الصورة (يمكنك تغييره)
    const coverImageUrl = 'https://files.catbox.moe/cplot6.png';
    
    // تحضير الميديا
    const messa = await prepareWAMessageMedia(
        { image: { url: coverImageUrl } },
        { upload: conn.waUploadToServer }
    );

    const interactiveMessage = {
        body: { 
            text: `*──────❲ 𝚂𝙾𝙽𝙶 𝙱𝙾𝚃 ❳*\n*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*\n🌐 *اختر نوع المنشن الذي تريده:*\n*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*\n> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*` 
        },
        footer: { text: "𝙎𝙊𝙉𝙂 𝘽𝙊𝙏 𝙀𝘿𝙄𝙏𝙄𝙊𝙉" },
        header: {
            title: "╭───⟢❲ 𝙼𝙴𝙽𝚃𝙸𝙾𝙽 𝙻𝙸𝚂𝚃 ❳╰───⟢",
            hasMediaAttachment: true,
            imageMessage: messa.imageMessage,
        },
        nativeFlowMessage: {
            buttons: [
                {
                    name: 'single_select',
                    buttonParamsJson: JSON.stringify({
                        title: "✨ اضغط هنا للاختيار",
                        sections: [
                            {
                                title: "📋 خيارات المنشن المتاحة",
                                rows: [
                                    {
                                        header: "｢👥｣ منشن أعضاء",
                                        title: "منشن الأعضاء العاديين فقط",
                                        description: "يتم استثناء المشرفين",
                                        id: ".منشن_اعضاء"
                                    },
                                    {
                                        header: "｢👑｣ منشن مشرفين",
                                        title: "منشن طاقم الإدارة فقط",
                                        description: "للتنبيهات الإدارية العاجلة",
                                        id: ".منشن_مشرفين"
                                    },
                                    {
                                        header: "｢📣｣ منشن الكل",
                                        title: "منشن لجميع أعضاء الجروب",
                                        description: "إرسال منشن جماعي ظاهر",
                                        id: ".منشن_الكل"
                                    },
                                    {
                                        header: "｢👻｣ منشن مخفي",
                                        title: "منشن لجميع الأعضاء (مخفي)",
                                        description: "تنبيه الجميع بدون رسالة منشن مزعجة",
                                        id: ".مخفي"
                                    }
                                ]
                            }
                        ]
                    })
                }
            ],
            messageParamsJson: ''
        }
    };

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage,
            },
        },
    }, { userJid: conn.user.jid, quoted: m });

    conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
};

// الإعدادات لجعل الأمر متاحاً للجميع
handler.help = ['منشن'];
handler.tags = ['group'];
handler.command = /^منشن$/i; // يستجيب فقط لأمر "منشن"
handler.group = true; // يعمل في المجموعات فقط
handler.admin = false; // لا يتطلب أن يكون المستخدم مشرفاً

export default handler;
