let handler = async (m, { conn, command }) => {

const payments = {
  pay_sa: `
🇸🇦 *السعودية*
• STC Pay
• تحويل بنكي (IBAN)
• USDT
`,

  pay_uae: `
🇦🇪 *الإمارات*
• PayPal
• تحويل بنكي
• USDT
`,

  pay_eg: `
🇪🇬 *مصر*
• Vodafone Cash
• InstaPay
• تحويل بنكي
`,

  pay_iq: `
🇮🇶 *العراق*
• Zain Cash
• Asia Hawala
• تحويل بنكي
`,

  pay_jo: `
🇯🇴 *الأردن*
• Orange Money
• CliQ
• تحويل بنكي
`,

  pay_dz: `
🇩🇿 *الجزائر*
• CCP
• BaridiMob
• تحويل بنكي
`,

  pay_ma: `
🇲🇦 *المغرب*
• CIH Pay
• Cash Plus
• تحويل بنكي
`,

  pay_tn: `
🇹🇳 *تونس*
• D17
• Poste Tunisienne
• تحويل بنكي
`,

  pay_ly: `
🇱🇾 *ليبيا*
• خدمة موبي كاش
• تحويل يدوي
• حساب بنكي
`,

  pay_td: `
🇹🇩 *تشاد*
• Airtel Money
• MTN MoMo
• تحويل بنكي
`,

  pay_tr: `
🇹🇷 *تركيا*
• Papara
• Ziraat Bank
• تحويل بنكي
`,

  pay_us: `
🇺🇸 *الولايات المتحدة*
• PayPal
• Zelle
• حساب بنكي
`,

  pay_fr: `
🇫🇷 *فرنسا*
• PayPal
• Lydia
• تحويل بنكي
`,

  pay_de: `
🇩🇪 *ألمانيا*
• PayPal
• SEPA
• حساب بنكي
`,

  pay_uk: `
🇬🇧 *بريطانيا*
• PayPal
• Wise
• حساب بنكي
`
}

const msg = payments[command]
if (!msg) return

conn.reply(m.chat, msg + `
📌 *ملاحظة*
يتم إرسال تفاصيل الدفع بعد الاتفاق.
`, m)

}

handler.command = /^(pay_sa|pay_uae|pay_eg|pay_iq|pay_jo|pay_dz|pay_ma|pay_tn|pay_ly|pay_td|pay_tr|pay_us|pay_fr|pay_de|pay_uk)$/i
handler.tags = ['payment']
handler.help = ['طرق الدفع حسب الدولة']

export default handler
