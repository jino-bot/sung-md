let handler = async (m, { conn, args, usedPrefix, command }) => {
    // الوصول لبيانات المجموعة
    let chat = global.db.data.chats[m.chat]
    if (!chat) return

    // عرض الحالة الحالية
    if (!args[0]) {
        let status = chat.antifake ? 'مفعل ✅' : 'معطل ❌'
        return conn.reply(
            m.chat,
            `*🛡️ حالة مانع الأرقام الوهمية:* ${status}\n\n` +
            `*للتحكم استخدم:*\n` +
            `• ${usedPrefix + command} on\n` +
            `• ${usedPrefix + command} off`,
            m
        )
    }

    // تفعيل الميزة
    if (args[0] === 'on') {
        if (chat.antifake) {
            return m.reply('⚠️ مانع الأرقام الوهمية مفعّل بالفعل في هذه المجموعة.')
        }
        chat.antifake = true
        return m.reply(
            '✅ تم تفعيل مانع الأرقام الوهمية.\n' +
            '📵 سيتم طرد أرقام الدول المحظورة تلقائياً.'
        )
    }

    // تعطيل الميزة
    if (args[0] === 'off') {
        if (!chat.antifake) {
            return m.reply('⚠️ مانع الأرقام الوهمية معطّل بالفعل.')
        }
        chat.antifake = false
        return m.reply('❌ تم تعطيل مانع الأرقام الوهمية بنجاح.')
    }

    // إدخال غير صحيح
    return m.reply(
        `❌ استخدام غير صحيح\n\n` +
        `*الصحيح:*\n` +
        `• ${usedPrefix + command} on\n` +
        `• ${usedPrefix + command} off`
    )
}

// إعدادات الأمر
handler.help = ['وهمي']
handler.tags = ['group']
handler.command = ['وهمي', 'antifake']

// القيود
handler.group = true
handler.admin = true

export default handler