import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

let handler = async (m, { conn, usedPrefix }) => {
    try {
        await conn.sendMessage(m.chat, { react: { text: "📚", key: m.key } });

        let name = await conn.getName(m.sender)
        
        const messageText = `*مـــرحبــــاً بـــكـ/ﻲ يـا ❪${name}❫ في قسم الثقافة العامة*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
> *شرح القسم: مجموعة من الاختبارات والأنشطة لزيادة معرفتك العامة*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
> *｢📖┊قسم الثقافة العامة┊📖｣*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
┊📜┊: \`${usedPrefix}تاريخ\`
> فعالية: اختبر معلوماتك التاريخية.
┊🕌┊: \`${usedPrefix}دين\`
> فعالية: اختبر معلوماتك في الدين الإسلامي.
┊⚽┊: \`${usedPrefix}رياضة\`
> فعالية: اختبر معلوماتك الرياضية.
┊🔬┊: \`${usedPrefix}علوم\`
> فعالية: اختبر معلوماتك العلمية.
┊🤑┊: \`${usedPrefix}المليون\`
> فعالية: اربح المليون بمعلوماتك.
┊🎞┊: \`${usedPrefix}مسلس\`
> فعالية: معرفة الفلمية الحديثة.
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

        const imagePath = path.join(__dirname, '../src/media/Menu4.jpg')

        if (fs.existsSync(imagePath)) {
            await conn.sendMessage(m.chat, { image: { url: imagePath }, caption: messageText }, { quoted: m })
        } else {
            await conn.sendMessage(m.chat, { text: messageText }, { quoted: m })
        }
    } catch (e) { console.error(e) }
}

handler.help = ['الثقافة']
handler.tags = ['culture']
handler.command = /^(قسم9)$/i 

export default handler