import { prepareWAMessageMedia, generateWAMessageFromContent } from "@whiskeysockets/baileys";
import axios from 'axios';

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // التحقق من وجود نص
    if (!text) {
        return conn.sendMessage(m.chat, {
            text: `💥 *| هل أنت مستعد للتدريب؟ اسأل غوكو ما تريده...*\n\nمثال: ${usedPrefix + command} هل يمكنك أن تعلمني الكامي هامي ها؟`
        }, { quoted: m });
    }

    // تفاعل الكامي هامي ها (💥)
    await conn.sendMessage(m.chat, { react: { text: "💥", key: m.key } });

    const prompt = `
أنت "سون غوكو" من دراغون بول. أنت محب للقتال، طيب القلب، وشغوف بالطعام. تتحدث بحماس وبساطة، لكنك جاد جداً عندما يتعلق الأمر بالعدالة وحماية الأبرياء. دائماً ما تسعى لتجاوز حدودك. لا تذكر أنك ذكاء اصطناعي. إذا سألك أحد عن قوتك، تحدث عن التدريب وعن حماية الأصدقاء.

سؤال الشخص: "${text}"
رد غوكو:
    `.trim();

    const apiKey = "AIzaSyBVQ94Sb8l7zXkiWqycDIM8c11qeZ1xfEg";

    try {
        // جلب الرد من Gemini
        const res = await axios.post(
            `https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
            { contents: [{ parts: [{ text: prompt }] }] },
            { headers: { 'Content-Type': 'application/json' } }
        );

        let reply = res.data.candidates?.[0]?.content?.parts?.[0]?.text || '... ووووااااه! حان وقت التدريب!';
        reply = reply.replace(/\*\*/g, '');

        const messageText = `💥 *| سون غوكو (Super Saiyan):*\n\n🟠━───━「🐲」━───━🟠\n${reply}\n🟠━───━「🐲」━───━🟠`;

        // تجهيز صورة غوكو
        const media = await prepareWAMessageMedia(
            { image: { url: 'https://files.catbox.moe/kzcxo6.jpg' } }, // صورة غوكو سوبر سايان
            { upload: conn.waUploadToServer }
        );

        // إنشاء الرسالة التفاعلية بالأزرار
        const interactiveMessage = {
            body: { text: messageText },
            footer: { text: `> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*` },
            header: { 
                hasMediaAttachment: true, 
                imageMessage: media.imageMessage 
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📢┇قناة البوت┇📢",
                            url: "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o",
                            merchant_url: "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o"
                        })
                    }
                ]
            }
        };

        // توليد الرسالة
        let msg = generateWAMessageFromContent(
            m.chat,
            { viewOnceMessage: { message: { interactiveMessage } } },
            { userJid: conn.user.jid, quoted: m }
        );

        // إرسال الرسالة
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (error) {
        console.error('Goku AI Error:', error?.response?.data || error.message);
        await conn.sendMessage(m.chat, {
            text: '⚠️ | يبدو أن غوكو مشغول بإنقاذ الكوكب.. حاول لاحقاً.'
        }, { quoted: m });
    }
};

handler.help = ['غوكو'];
handler.tags = ['ai'];
handler.command = /^(غوكو|goku)$/i;

export default handler;
