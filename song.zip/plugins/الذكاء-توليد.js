import axios from 'axios'

let handler = async (m, { conn, args }) => {
  const prompt = args.join(' ').trim()

  if (!prompt) {
    return conn.reply(
      m.chat,
      '❌ أرسل وصف الصورة بعد الأمر.\n\nمثال:\n.توليد قط يطير في الفضاء',
      m
    )
  }

  // 🚀 تفاعل عند الطلب
  try {
    await conn.sendMessage(m.chat, {
      react: { text: '🚀', key: m.key }
    })
  } catch {}

  try {
    const imageUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}`

    const caption = `
*❐═━━━═╊⊰🎨⊱╉═━━━═❐*

✏️ *الوصف:*
${prompt}

*❐═━━━═╊⊰🎨⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*
    `.trim()

    // ✅ تفاعل عند النجاح
    try {
      await conn.sendMessage(m.chat, {
        react: { text: '✅', key: m.key }
      })
    } catch {}

    await conn.sendMessage(
      m.chat,
      {
        image: { url: imageUrl },
        caption
      },
      { quoted: m }
    )

  } catch (err) {
    console.error('❌ خطأ توليد الصورة:', err)

    try {
      await conn.sendMessage(m.chat, {
        react: { text: '❌', key: m.key }
      })
    } catch {}

    return conn.reply(
      m.chat,
      '❌ حدث خطأ أثناء إنشاء الصورة.',
      m
    )
  }
}

handler.help = ['توليد <وصف>']
handler.tags = ['ai']
handler.command = /^توليد$/i

export default handler
