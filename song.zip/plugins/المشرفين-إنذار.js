let handler = async (m, { conn, text, usedPrefix, command, isAdmin, isOwner, isBotAdmin }) => {
    // 1. التحقق من الصلاحيات
    if (!isAdmin && !isOwner) return m.reply('*[❗] هذا الأمر للمشرفين فقط*')

    // 2. تحديد الشخص المستهدف (منشن أو رد أو رقم)
    let who
    if (m.isGroup) {
        who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? (text.replace(/[^0-9]/g, '') + '@s.whatsapp.net') : false
    } else {
        who = m.chat
    }

    if (!who) return m.reply(`*[❗] منشن الشخص أو رد على رسالته*\n\n*مثال: ${usedPrefix + command} @منشن*`)

    // 3. الوصول لقاعدة البيانات (تأكد من وجود المسار الصحيح)
    if (!global.db.data.users[who]) global.db.data.users[who] = { warn: 0 }
    
    let user = global.db.data.users[who]
    user.warn = (user.warn || 0) + 1
    
    const userMention = `@${who.split('@')[0]}`

    // 4. إعدادات المنشن والقناة
    const contextInfo = {
        mentionedJid: [who, m.sender],
        forwardingScore: 999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363416870755391@newsletter",
            newsletterName: "𝐒𝐔𝐍𝐆 ꒰🐉⃝⃕꒱𝐔𝐏𝐃𝐀𝐓𝐄",
            serverMessageId: -1
        }
    }

    if (user.warn < 3) {
        let warnMsg = `
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
✧ \`إنــذار مـن الإدارة\`
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
👤 *العضو:* ${userMention}
👮 *بواسطة:* @${m.sender.split('@')[0]}
📌 *الإنذارات:* 『${user.warn}/3』
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> يرجى الالتزام بالقوانين تجنباً للطرد.
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*`.trim()

        await conn.sendMessage(m.chat, { text: warnMsg, contextInfo }, { quoted: m })
    } else {
        let kickMsg = `
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
✧ \`طرد نهائي (3/3)\`
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
👤 *العضو:* ${userMention}
📌 *الإنذارات:* مكتملة
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> تم طردك لتجاوز حد التحذيرات.
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*`.trim()

        await conn.sendMessage(m.chat, { text: kickMsg, contextInfo }, { quoted: m })

        // تنفيذ الطرد
        if (isBotAdmin) {
            await conn.groupParticipantsUpdate(m.chat, [who], 'remove')
            user.warn = 0 // تصفير بعد الطرد
        } else {
            m.reply('*[❗] لا أستطيع الطرد لأني لست مشرفاً*')
        }
    }
}

handler.help = ['انذار']
handler.tags = ['group']
handler.command = /^(انذار|تحذير)$/i
handler.group = true
handler.admin = true // لضمان ظهور الخطأ للمستخدم العادي

export default handler
