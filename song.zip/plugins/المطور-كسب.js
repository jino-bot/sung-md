let handler = async (m, { conn, text, command }) => {

  if (!m.quoted)
    return m.reply(`*⚠️┇يجب الرد على رسالة الشخص!*\n\n*مثال:* .${command} 200`)

  let amount = parseInt(text)
  if (isNaN(amount) || amount <= 0)
    return m.reply(`*⚠️┇يرجى إدخال رقم صحيح!*`)

  let target = m.quoted.sender
  let name = await conn.getName(target)

  // حفظ العملية مؤقتاً
  global.kasabSession ??= {}
  global.kasabSession[m.sender] = {
    target,
    amount
  }

  const buttons = [
    {
      name: "quick_reply",
      buttonParamsJson: JSON.stringify({
        display_text: "⭐ نقاط",
        id: "kasab|points"
      })
    },
    {
      name: "quick_reply",
      buttonParamsJson: JSON.stringify({
        display_text: "💰 عملات",
        id: "kasab|coins"
      })
    },
    {
      name: "quick_reply",
      buttonParamsJson: JSON.stringify({
        display_text: "💡 خبرة",
        id: "kasab|exp"
      })
    },
    {
      name: "quick_reply",
      buttonParamsJson: JSON.stringify({
        display_text: "🎁 الكل",
        id: "kasab|all"
      })
    }
  ]

  await conn.relayMessage(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: `*『💼┇تحديد نوع العمولة┇💼』*

*👤┇المستلم:* ${name}
*🔢┇القيمة:* ${amount}

*⬇️ اختر نوع الإضافة:*`
          },
          footer: { text: '> 𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
          nativeFlowMessage: { buttons }
        }
      }
    }
  }, {})
}

handler.command = ['كسب']
handler.rowner = true
export default handler