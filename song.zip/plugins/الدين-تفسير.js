import axios from 'axios'

const surahNames = {
  "الفاتحة": 1,
  "البقرة": 2,
  "آل عمران": 3,
  "النساء": 4,
  "الأنعام": 6,
  "النبأ": 78,
  "النازعات": 79,
  "عبس": 80,
  "التكوير": 81,
  "الانفطار": 82,
  "المطففين": 83,
  "الانشقاق": 84,
  "البروج": 85,
  "الطارق": 86,
  "الأعلى": 87,
  "الغاشية": 88,
  "الفجر": 89,
  "البلد": 90,
  "الشمس": 91,
  "الليل": 92,
  "الضحى": 93,
  "الشرح": 94,
  "التين": 95,
  "العلق": 96,
  "القدر": 97,
  "البينة": 98,
  "الزلزلة": 99,
  "العاديات": 100,
  "القارعة": 101,
  "التكاثر": 102,
  "العصر": 103,
  "الهمزة": 104,
  "الفيل": 105,
  "قريش": 106,
  "الماعون": 107,
  "الكوثر": 108,
  "الكافرون": 109,
  "النصر": 110,
  "المسد": 111,
  "الإخلاص": 112,
  "الفلق": 113,
  "الناس": 114,
}

async function getSurahTafsir(surahNumber) {
  try {
    const url = `https://quranenc.com/api/v1/translation/sura/arabic_moyassar/${surahNumber}`
    const res = await axios.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0',
        'Accept': 'application/json'
      }
    })
    return res.data.result
  } catch (e) {
    console.error('❌ خطأ في جلب التفسير:', e.message)
    return null
  }
}

function splitMessage(text, max = 3500) {
  let result = []
  let i = 0
  while (i < text.length) {
    let end = i + max
    if (end < text.length) {
      let last = text.lastIndexOf('\n', end)
      if (last > i) end = last
    }
    result.push(text.slice(i, end).trim())
    i = end
  }
  return result
}

let handler = async (m, { conn, args, command }) => {

  if (!args[0])
    throw `❌ *اكتب اسم السورة أو رقمها*\n\n📌 مثال:\n.${command} النبأ`

  let input = args.join(' ').trim()
  let surahNumber = null

  if (/^\d+$/.test(input)) {
    surahNumber = Number(input)
  } else if (surahNames[input]) {
    surahNumber = surahNames[input]
  }

  if (!surahNumber || surahNumber < 1 || surahNumber > 114)
    throw '❌ *لم أتعرف على السورة المطلوبة*'

  let tafsir = await getSurahTafsir(surahNumber)
  if (!tafsir)
    throw '❌ *تعذر جلب التفسير*'

  let surahName =
    Object.keys(surahNames).find(k => surahNames[k] === surahNumber) || `رقم ${surahNumber}`

  let text = `📖 *تفسير سورة ${surahName}*\n\n`

  tafsir.forEach(v => {
    text += `﴿${v.aya}﴾ ${v.translation}\n\n`
  })

  let parts = splitMessage(text)

  for (let part of parts) {
    await conn.sendMessage(m.chat, {
      text: `*❍━━━══『📖』══━━━❍*\n${part}\n*❍━━━══『📖』══━━━❍*`
    }, { quoted: m })
  }
}

handler.help = ['تفسير <اسم|رقم>']
handler.tags = ['islam']
handler.command = /^تفسير$/i

export default handler