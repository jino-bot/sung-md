let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text)
    throw `ضع اسم الخلفية بعد الأمر\nمثال:\n${usedPrefix + command} naruto`

  // نرسل صورتين مختلفتين
  const urls = [
    `https://source.unsplash.com/1080x1920/?${encodeURIComponent(text)},anime`,
    `https://source.unsplash.com/1080x1920/?${encodeURIComponent(text)},wallpaper`
  ]

  for (let url of urls) {
    await conn.sendFile(
      m.chat,
      url,
      'wallpaper.jpg',
      `🖼️ *${text}*`,
      m
    )
  }
}

handler.help = ['wallpaper <query>']
handler.tags = ['downloader']
handler.command = /^(wall|wallpaper|خلفيات)$/i

export default handler