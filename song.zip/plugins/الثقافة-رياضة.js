import fs from 'fs';
import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

const timeout = 60000;
const poin = 200;

let handler = async (m, { conn, command, text }) => {
    conn.tekateki = conn.tekateki || {};
    let id = m.chat;

    // 1. معالجة الضغط على الأزرار أولاً
    if (command.startsWith('اجابة_رياضة_')) {
        let game = conn.tekateki[id];
        if (!game) return !0; // إذا لم توجد لعبة، لا ترد بشيء

        let selectedAnswerIndex = parseInt(command.split('_')[2]);
        let selectedAnswer = game[4][selectedAnswerIndex - 1];
        let isCorrect = game[1].response.trim().toLowerCase() === selectedAnswer.trim().toLowerCase();

        if (isCorrect) {
            let db = global.db.data

// تأكد من وجود المستخدم
if (!db.users[m.sender]) {
    db.users[m.sender] = {
        bank: 0,
        exp: 0,
        coin: 0,
        level: 0
    }
}

// إضافة 150 نقطة إلى البنك
db.users[m.sender].bank = (db.users[m.sender].bank || 0) + poin

// حفظ فعلي
global.db.data = db
            clearTimeout(game[3]);
            delete conn.tekateki[id];

            const interactiveMessage = {
                body: { text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*🎉 إجابتك صحيحة مبروك 🎉*\n*🏦┊الجائزة┊⇇ ${poin} نقطة*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*` },
                footer: { text: '𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
                nativeFlowMessage: {
                    buttons: [{ name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🔄 سؤال رياضي آخر', id: '.رياضه' }) }]
                }
            };
            return conn.relayMessage(m.chat, { viewOnceMessage: { message: { interactiveMessage } } }, {});
        } else {
            game[5] -= 1; 
            if (game[5] > 0) {
                return conn.reply(m.chat, `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*إجابتك خاطئة ❌*\n*لديك محاولة واحدة أخرى ⏳*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`, m);
            } else {
                let correct = game[1].response;
                clearTimeout(game[3]);
                delete conn.tekateki[id];
                const interactiveMessage = {
                    body: { text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*إجابتك خاطئة ❌*\n*إنتهت المحاولات المتاحة*\n*✅┊الإجابة هي┊⇇ ${correct}*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*` },
                    footer: { text: '𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
                    nativeFlowMessage: {
                        buttons: [{ name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🔄 حاول مجدداً', id: '.رياضه' }) }]
                    }
                };
                return conn.relayMessage(m.chat, { viewOnceMessage: { message: { interactiveMessage } } }, {});
            }
        }
    }

    // 2. التحقق من وجود لعبة قائمة عند طلب أمر "رياضه" فقط
    if (command === 'رياضه' || command === 'رياضة') {
        if (id in conn.tekateki) {
            return conn.reply(m.chat, '*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*هناك تحدي رياضي لم ينتهِ بعد! ⚠️*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*', conn.tekateki[id][0]);
        }

        let tekateki = JSON.parse(fs.readFileSync(`./src/game/رياضه.json`));
        let json = tekateki[Math.floor(Math.random() * tekateki.length)];
        let options = [json.response];
        while (options.length < 4) {
            let randomRes = tekateki[Math.floor(Math.random() * tekateki.length)].response;
            if (!options.includes(randomRes)) options.push(randomRes);
        }
        options.sort(() => Math.random() - 0.5);

        const imageUrl = 'https://telegra.ph/file/39fb047cdf23c790e0146.jpg';
        const media = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: conn.waUploadToServer });

        const interactiveMessage = {
            body: { text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*✧ \`تحدي المعلومات الرياضية\` ✧*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n\n*❏- ⚽ الـسـؤال : ⟦ ${json.question} ⟧*\n\n*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*\n*❏- ⏱️ الـوقـت: ⟦60 ثانـية ⟧*\n*❏-🏦 الجائزة: ⟦ ${poin} نقطة ⟧*\n*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*` },
            footer: { text: '𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
            header: { hasMediaAttachment: true, imageMessage: media.imageMessage },
            nativeFlowMessage: {
                buttons: options.map((opt, i) => ({
                    name: 'quick_reply',
                    buttonParamsJson: JSON.stringify({ display_text: `⚽ ${opt}`, id: `.اجابة_رياضة_${i + 1}` })
                })),
            },
        };

        let msg = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { interactiveMessage } } }, { userJid: conn.user.jid, quoted: m });
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

        conn.tekateki[id] = [
            msg, json, poin,
            setTimeout(async () => {
                if (conn.tekateki[id]) {
                    await conn.reply(m.chat, `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*⌛ انتهى الوقت المسموح*\n*✅ الإجابة هي: ${json.response}*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`, m);
                    delete conn.tekateki[id];
                }
            }, timeout),
            options, 2
        ];
    }
};

handler.help = ['رياضه'];
handler.tags = ['game'];
handler.command = /^(رياضه|رياضة|اجابة_رياضة_\d+)$/i;

export default handler;
