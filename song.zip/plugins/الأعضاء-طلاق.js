import fs from 'fs';

let toM = a => '@' + a.split('@')[0];

async function handler(m, { conn, groupMetadata, text }) {
    let ps = groupMetadata.participants.map(v => v.id);
    let a = m.sender; // الشخص الذي أرسل الأمر
    let b;

    // تحديد الشخص الثاني: منشن، رد، أو عشوائي
    const target = m.mentionedJid?.[0] || (m.quoted ? m.quoted.sender : null);

    if (target) {
        if (target === a) return m.reply('*⚠️ لا يمكنك الطلاق من نفسك!*');
        b = target;
    } else {
        do {
            b = ps[Math.floor(Math.random() * ps.length)];
        } while (b === a);
    }

    // مسار الصورة المحلي (يمكن تغييره أو استخدام رابط مباشر)
    const localImg = './src/media/طلاق.png';

    let caption = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*✧ \`إعـلان طـلاق هزلي\` ✧*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

*❯ 💔 الزوج :* ${toM(a)}
*❯ 💔 الزوجة :* ${toM(b)}

*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*✨ انتهى الزواج… حان وقت الشاي والحلويات 😂🍵* 
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`;

    // إرسال الصورة إذا موجودة، أو إرسال الرسالة بدونها
    if (fs.existsSync(localImg)) {
        await conn.sendFile(m.chat, localImg, 'divorce.png', caption, m, false, { mentions: [a, b] });
    } else {
        await conn.reply(m.chat, caption, m, { mentions: [a, b] });
    }
}

handler.help = ['طلاق'];
handler.tags = ['fun'];
handler.command = ['طلاق'];
handler.group = true;

export default handler;