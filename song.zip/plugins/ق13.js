import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

let handler = async (m, { conn, usedPrefix }) => {
    try {
        // إرسال تفاعل 🛡️
        await conn.sendMessage(m.chat, { react: { text: "🛡️", key: m.key } });

        let name = await conn.getName(m.sender)
        
        const messageText = `*مـــرحبــــاً بـــكـ/ﻲ يـا ❪${name}❫ في قسم الحماية*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *شرح القسم: يوفر أنظمة حماية متطورة للمجموعات ضد الروابط والسبام*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *｢🛡️┊قسم الـحـمـايـة والأمـان┊🛡️｣*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
┊🛡️┊: \`${usedPrefix}حماية\`
> إدارة مستويات حماية المجموعة (عادية).
┊🛡️┊: \`${usedPrefix}مطلقة\`
> إدارة مستويات حماية المجموعة (مطلقة).
┊🛡️┊: \`${usedPrefix}وهمي\`
> تشغيل او ايقاف مانع الارقام الوهمية.
┊🛡️┊: \`${usedPrefix}كشف\`
> كشف تغيرات التي تطرح على المجموعة.
┊🛡️┊: \`${usedPrefix}قبول\`
> القبول التلقائي لكل طلبات الانضمام.
┊🛡️┊: \`${usedPrefix}شتائم\`
> مانع الشتائم المخلة بالآداب.
┊🛡️┊: \`${usedPrefix}روابط2\`
> مانع روابط المواقع وحذفها.
┊🛡️┊: \`${usedPrefix}روابط\`
> مانع روابط المجموعات وحذفها.
┊🛡️┊: \`${usedPrefix}الخاص\`
> مانع التكلم في الخاص مع البوت.
┊🛡️┊: \`${usedPrefix}الترحيب\`
> الترحيب التلقائي للأعضاء في الجروبات.
┊🛡️┊: \`${usedPrefix}البوتات\`
> مانع البوتات غير البوت الرئيسي.
┊🛡️┊: \`${usedPrefix}اسبام\`
> حماية المجموعات من الاسبام.
┊🛡️┊: \`${usedPrefix}اخفاء\`
> حماية الجروبات من عرض المرة الواحدة.
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

    const imagePath = path.join(__dirname, '../src/media/Menu4.jpg')

    if (fs.existsSync(imagePath)) {
        await conn.sendMessage(m.chat, { 
            image: { url: imagePath }, 
            caption: messageText 
        }, { quoted: m })
    } else {
        await conn.sendMessage(m.chat, { text: messageText }, { quoted: m })
    }

    } catch (err) {
        console.error('❌ Error in Protection Menu:', err)
    }
}

handler.help = ['الحماية']
handler.tags = ['main']
handler.command = /^(قسم13)$/i 

export default handler
