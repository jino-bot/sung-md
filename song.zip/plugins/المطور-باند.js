let handler = async (m, { conn }) => {
  if (!m.quoted) throw '□ رد على رسالة الشخص الذي تريد حظره'

  let who = m.quoted.sender
  let user = global.db.data.users[who]
  if (!user) throw '□ المستخدم غير موجود في قاعدة البيانات'

  user.banned = true

  conn.reply(
    m.chat,
    `@${who.split('@')[0]} لن تستطيع استخدام أوامر البوت بعد الآن ❌`,
    m,
    { mentions: [who] }
  )
}

handler.help = ['ban (reply)']
handler.tags = ['owner']
handler.command = /^بان$/i
handler.rowner = true

export default handler