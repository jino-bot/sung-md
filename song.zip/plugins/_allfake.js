import pkg from '@whiskeysockets/baileys'
import fs from 'fs'
import fetch from 'node-fetch'
import axios from 'axios'
import moment from 'moment-timezone'

const { generateWAMessageFromContent, prepareWAMessageMedia, proto } = pkg

var handler = m => m
handler.all = async function (m) {

/* ====== القنوات ====== */
global.canalIdM = [
  "120363416870755391@newsletter",
  "120363416870755391@newsletter"
]
global.canalNombreM = [
  '𝐒𝐔𝐍𝐆 ꒰🐉⃝⃕꒱𝐔𝐏𝐃𝐀𝐓𝐄',
  '𝐒𝐔𝐍𝐆 ꒰🐲⃝⃕꒱𝐉𝐈𝐍𝐎',
  '𝐁𝐎𝐓 ꒰🐲⃝⃕꒱𝐉𝐈𝐍𝐎'
]

// اختيار القناة العشوائية وتخزينها
const channelRD = await getRandomChannel()

/* ====== التاريخ والوقت ====== */
global.d = new Date(new Date().getTime() + 3600000)
global.locale = 'es'
global.dia = global.d.toLocaleDateString(global.locale, { weekday: 'long' })
global.fecha = global.d.toLocaleDateString('es', {
  day: 'numeric',
  month: 'numeric',
  year: 'numeric'
})
global.tiempo = global.d.toLocaleString('en-US', {
  hour: 'numeric',
  minute: 'numeric',
  second: 'numeric',
  hour12: true
})

/* ====== اسم المستخدم ====== */
global.nombre = m.pushName || 'Anónimo'

/* ====== إعداد القناة ====== */
global.rcanal = {
  contextInfo: {
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: channelRD.id,
      serverMessageId: '',
      newsletterName: channelRD.name
    }
  }
}

/* ====== حقن القناة تلقائياً في كل الأوامر ====== */
let conn = this
const originalSendMessage = conn.sendMessage.bind(conn)

conn.sendMessage = async (jid, content, options = {}) => {
  // نحقن القناة فقط في الرسائل النصية والوسائط، ونتجنب الرسائل التي تحتوي على react
  if (content && typeof content === 'object' && !content.contextInfo && !content.react) {
    content.contextInfo = global.rcanal.contextInfo
  }
  return originalSendMessage(jid, content, options)
}
}

export default handler

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}

async function getRandomChannel() {
  let randomIndex = Math.floor(Math.random() * global.canalIdM.length)
  return {
    id: global.canalIdM[randomIndex],
    name: global.canalNombreM[randomIndex]
  }
}