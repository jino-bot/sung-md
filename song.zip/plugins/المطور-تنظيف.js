import pkg from '@whiskeysockets/baileys'
const { prepareWAMessageMedia } = pkg
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const handler = async (m, { conn }) => {

  // تفاعل
  await conn.sendMessage(m.chat, { react: { text: '🧹', key: m.key } })

  // تحميل الصورة من الرابط مباشرة
  let media
  try {
    media = await prepareWAMessageMedia(
      { image: { url: 'https://files.catbox.moe/zd89n4.jpg' } },
      { upload: conn.waUploadToServer }
    )
  } catch (e) {
    console.error(e)
  }

  const text = `
*❐═━━━═╊⊰🧹⊱╉═━━━═❐*
✧ *قائمة تنظيف وصيانة البوت*
*❐═━━━═╊⊰🛡️⊱╉═━━━═❐*

*اختر العملية التي تريد تنفيذها:*

① 🗂️ تنظيف ملف الجلسة  
② 🧠 تنظيف قاعدة البيانات  
③ ♻️ إعادة ضبط قاعدة البيانات  
④ 🔄 إعادة تشغيل البوت

*❐═━━━═╊⊰🤖⊱╉═━━━═❐*
> *تنفيذ هذه الأوامر للمطور فقط*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
`.trim()

  const buttons = [
    {
      name: "single_select",
      buttonParamsJson: JSON.stringify({
        title: "🧹 اختر من القائمة",
        sections: [
          {
            title: "🛠️ أوامر التنظيف والصيانة",
            rows: [
              {
                title: "🗂️ تنظيف ملف الجلسة",
                description: "حذف ملفات Session",
                id: ".تنظيف_session"
              },
              {
                title: "🧠 تنظيف قاعدة البيانات",
                description: "تنظيف البيانات غير المستخدمة",
                id: ".تنظيف_db"
              },
              {
                title: "♻️ إعادة ضبط قاعدة البيانات",
                description: "تفريغ القاعدة بالكامل",
                id: ".تنظيف_resetdb"
              },
              {
                title: "🔄 إعادة تشغيل البوت",
                description: "إعادة تشغيل النظام",
                id: ".تنظيف_restart"
              }
            ]
          }
        ]
      })
    }
  ]

  await conn.relayMessage(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: { text },
          footer: { text: '> 𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃' },
          header: {
            hasMediaAttachment: true,
            imageMessage: media.imageMessage
          },
          nativeFlowMessage: { buttons }
        }
      }
    }
  }, {})
}

handler.help = ['تنظيف']
handler.tags = ['owner']
handler.command = ['تنظيف']
handler.owner = true

export default handler
