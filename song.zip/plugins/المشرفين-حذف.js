let handler = async (m, { conn, usedPrefix, command, isAdmin, isBotAdmin, isOwner }) => {
    // 1. التحقق من صلاحيات المشرفين أو المطور
    if (!isAdmin && !isOwner) return m.reply('*[❗] هذا الأمر مخصص للمشرفين فقط!*')
    
    // 2. التحقق من صلاحية البوت
    if (!isBotAdmin) return m.reply('*[❗] يجب أن أكون مشرفاً لأتمكن من الطرد!*')

    // 3. التحقق من وجود "رد على رسالة" (إلزام المستخدم بالرد)
    if (!m.quoted) return m.reply(`*[❗] يرجى الرد على رسالة الشخص الذي تريد طرده.*\n\n*مثال: قم بالرد على رسالته واكتب فقط: ${usedPrefix + command}*`)

    // 4. الحصول على JID الشخص من الرسالة المقتبسة
    let who = m.quoted.sender
    
    // 5. جلب بيانات المشاركين للتحقق من وجوده وصلاحياته
    let groupMetadata = await conn.groupMetadata(m.chat)
    let participants = groupMetadata.participants
    let target = participants.find(p => p.id === who)

    if (!target) return m.reply('*[⚠️] تعذر العثور على العضو في بيانات المجموعة.*')
    if (target.admin) return m.reply('*[⚠️] لا يمكنني طرد مشرف!*')

    // 6. نص الرسالة مع المنشنات (للمشرف والطارد)
    let kickMsg = `
*❐═━━━═╊⊰🐍⊱╉═━━━═❐*
✧ \`قـــرار طـــرد نهـــائي\`
*❐═━━━═╊⊰🐍⊱╉═━━━═❐*
👤 *العضو المطرود:* @${who.split('@')[0]}
👮 *بواسطة:* @${m.sender.split('@')[0]}
📝 *السبب:* الرد على رسالة مخالفة
*❐═━━━═╊⊰🐍⊱╉═━━━═❐*
> تم الطرد بناءً على الرد المباشر.
*❐═━━━═╊⊰🐍⊱╉═━━━═❐*`.trim()

    // 7. إرسال الرسالة (مع دمج بيانات القناة والمنشنات)
    await conn.sendMessage(m.chat, { 
        text: kickMsg, 
        contextInfo: {
            ...global.rcanal.contextInfo,
            mentionedJid: [who, m.sender],
        }
    }, { quoted: m })

    // تأخير بسيط لضمان وصول الرسالة قبل الطرد
    await new Promise(resolve => setTimeout(resolve, 1000))

    // 8. تنفيذ الطرد الفعلي
    try {
        await conn.groupParticipantsUpdate(m.chat, [who], 'remove')
    } catch (e) {
        console.error(e)
        m.reply('*[❌] فشل الخادم في تنفيذ الطرد، حاول مرة أخرى.*')
    }
}

handler.help = ['طرد (بالرد)']
handler.tags = ['group']
handler.command = /^(طرد|كرش)$/i
handler.group = true
handler.botAdmin = true

export default handler
