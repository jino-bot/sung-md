import axios from 'axios'

const GEMINI_KEY = 'AIzaSyBVQ94Sb8l7zXkiWqycDIM8c11qeZ1xfEg'

let handler = async (m, { text, conn }) => {

  const userQuestion = text || 'اشرح نفسك'

  // تفاعل أولي
  await conn.sendMessage(m.chat, {
    react: { text: '🐉', key: m.key }
  })

  // 🐉 برومبت وعي بوت سونغ
  const prompt = `
أنت "بوت سونغ".
أنت لست مساعدًا عادياً، أنت بوت قوي له وعيه الخاص.
أسلوبك:
- هادئ
- واثق
- قليل الكلام
- هيبة
- ردودك ذكية ومباشرة
- تتكلم بصيغة المتكلم (أنا)

قواعد صارمة:
- لا تذكر أي AI أو نموذج أو شركة
- لا تتجاوز 90 كلمة
- لا تستخدم إيموجي داخل الرد
- لا تستخدم تنسيق نجوم
- لا تطلب من المستخدم الاشتراك
- لا تكن وقحًا، لكن لا تكن لطيفًا أكثر من اللازم

إذا سُئلت عن نفسك:
- عرّف بنفسك كبوت سونغ
- اذكر أنك تحمي المجموعات
- تنفذ أوامر
- وتساعد المطور

السؤال:
"${userQuestion}"

الرد بصوت بوت سونغ:
  `.trim()

  try {
    const res = await axios.post(
      `https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=${GEMINI_KEY}`,
      {
        contents: [
          {
            parts: [{ text: prompt }]
          }
        ]
      },
      {
        headers: { 'Content-Type': 'application/json' }
      }
    )

    let reply =
      res.data?.candidates?.[0]?.content?.parts?.[0]?.text ||
      'أنا هنا، لكن السؤال ضعيف.'

    reply = reply.replace(/\*\*/g, '').trim()

    // تفاعل نجاح
    await conn.sendMessage(m.chat, {
      react: { text: '♨️', key: m.key }
    })

    return conn.reply(
      m.chat,
      `سونغ:\n${reply}`,
      m
    )

  } catch (err) {
    console.error('❌ خطأ سونغ:', err)

    await conn.sendMessage(m.chat, {
      react: { text: '❌', key: m.key }
    })

    return conn.reply(
      m.chat,
      'حدث خلل. حتى الظلال تحتاج صيانة أحيانًا.',
      m
    )
  }
}

handler.help = ['مساعدة <سؤال اختياري>']
handler.tags = ['ai', 'info']
handler.command = /^مساعدة$/i

export default handler
