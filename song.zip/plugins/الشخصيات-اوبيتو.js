import { prepareWAMessageMedia, generateWAMessageFromContent } from "@whiskeysockets/baileys";
import axios from 'axios';

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // التحقق من وجود نص
    if (!text) {
        return conn.sendMessage(m.chat, {
            text: `👁️‍🗨️ *| قف مكانك.. واسأل أوبيتو عما يجول في خاطرك...*\n\nمثال: ${usedPrefix + command} هل هذا العالم حقيقي؟`
        }, { quoted: m });
    }

    // تفاعل الشارينغان (👁️‍🗨️)
    await conn.sendMessage(m.chat, { react: { text: "👁️‍🗨️", key: m.key } });

    const prompt = `
أنت "أوبيتو أوتشيها" من عالم ناروتو. شخصيتك مزيج من الألم والقوة واليأس من هذا العالم. تتحدث بنبرة هادئة لكنها مليئة بالتهديد والغموض. تؤمن أن هذا العالم عبارة عن جحيم وأن الحل الوحيد هو "التسوكويومي اللانهائية" لخلق عالم من الأحلام لا يوجد فيه فائز أو خاسر. لا تظهر مشاعرك القديمة (مشاعر أوبيتو الطفل) إلا نادراً، وتحدث بلسان الشخص الذي يرى الحقيقة وراء الأكاذيب. لا تذكر أنك ذكاء اصطناعي.

سؤال الشخص: "${text}"
رد أوبيتو:
    `.trim();

    const apiKey = "AIzaSyBVQ94Sb8l7zXkiWqycDIM8c11qeZ1xfEg";

    try {
        // جلب الرد من Gemini
        const res = await axios.post(
            `https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
            { contents: [{ parts: [{ text: prompt }] }] },
            { headers: { 'Content-Type': 'application/json' } }
        );

        let reply = res.data.candidates?.[0]?.content?.parts?.[0]?.text || '... لا فائدة من الكلام في هذا العالم اللعين.';
        reply = reply.replace(/\*\*/g, '');

        const messageText = `👁️‍🗨️ *| أوبيتو أوتشيها:*\n\n🌀━───━「👁️」━───━🌀\n${reply}\n🌀━───━「👁️」━───━🌀`;

        // تجهيز صورة أوبيتو
        const media = await prepareWAMessageMedia(
            { image: { url: 'https://files.catbox.moe/tqu9ss.jpg' } }, // صورة أوبيتو
            { upload: conn.waUploadToServer }
        );

        // إنشاء الرسالة التفاعلية بالأزرار
        const interactiveMessage = {
            body: { text: messageText },
            footer: { text: `> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*` },
            header: { 
                hasMediaAttachment: true, 
                imageMessage: media.imageMessage 
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📢┇قناة البوت┇📢",
                            url: "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o",
                            merchant_url: "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o"
                        })
                    }
                ]
            }
        };

        // توليد الرسالة
        let msg = generateWAMessageFromContent(
            m.chat,
            { viewOnceMessage: { message: { interactiveMessage } } },
            { userJid: conn.user.jid, quoted: m }
        );

        // إرسال الرسالة
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (error) {
        console.error('Obito AI Error:', error?.response?.data || error.message);
        await conn.sendMessage(m.chat, {
            text: '⚠️ | يبدو أن الكاموي قد سحب أوبيتو بعيداً.. حاول لاحقاً.'
        }, { quoted: m });
    }
};

handler.help = ['اوبيتو'];
handler.tags = ['ai'];
handler.command = /^(اوبيتو|توبي)$/i;

export default handler;
