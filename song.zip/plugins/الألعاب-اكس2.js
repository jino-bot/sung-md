const symbols = ['❌', '⭕'];
const numerosEmoji = ['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣'];

function renderTablero(tablero) {
  return `
*╔════ 💠 ════╗*
   ${tablero.slice(0,3).join('')}
   ${tablero.slice(3,6).join('')}
   ${tablero.slice(6).join('')}
*╚════ 💠 ════╝*`;
}

function verificarGanador(tablero) {
  const combinaciones = [
    [0,1,2], [3,4,5], [6,7,8],
    [0,3,6], [1,4,7], [2,5,8],
    [0,4,8], [2,4,6]
  ];
  for (const [a, b, c] of combinaciones) {
    if (tablero[a] === tablero[b] && tablero[b] === tablero[c]) {
      return tablero[a];
    }
  }
  return tablero.every(x => x === '❌' || x === '⭕') ? 'empate' : null;
}

// ذكاء اصطناعي بسيط للبوت
function moveBot(tablero) {
  let emptyIndices = tablero.map((v, i) => numerosEmoji.includes(v) ? i : null).filter(v => v !== null);
  return emptyIndices[Math.floor(Math.random() * emptyIndices.length)];
}

let handler = async (m, { conn, usedPrefix, command }) => {
  conn.tttbot = conn.tttbot || {};
  let id = m.chat;

  if (conn.tttbot[id]) {
    return conn.reply(m.chat, '*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*⚠️ هناك تحدٍ قائم بالفعل مع البوت!*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*', conn.tttbot[id].msg);
  }

  conn.tttbot[id] = {
    tablero: [...numerosEmoji],
    usuario: m.sender,
    msg: m,
    status: 'playing'
  };

  let caption = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*✧ \`تحدي الذكاء ضد البوت\` ✧*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

*👤 أنـت : ⟦ ❌ ⟧*
*🤖 الـبوت : ⟦ ⭕ ⟧*

*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
${renderTablero(conn.tttbot[id].tablero)}
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

> *ابدأ بإرسال رقم المربع الذي تود اللعب فيه.*
> *الفوز: 200 XP | الخسارة: -100 XP*

*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`;

  conn.tttbot[id].msg = await conn.reply(m.chat, caption, m);
};

handler.before = async (m, { conn }) => {
  conn.tttbot = conn.tttbot || {};
  let id = m.chat;
  if (!conn.tttbot[id] || m.sender !== conn.tttbot[id].usuario) return;

  const textInput = m.text || '';
  const numero = parseInt(textInput.trim());
  if (!numero || numero < 1 || numero > 9) return;

  let game = conn.tttbot[id];
  let idx = numero - 1;

  if (game.tablero[idx] !== symbols[0] && game.tablero[idx] !== symbols[1]) {
    // دور المستخدم
    game.tablero[idx] = symbols[0];
    let result = verificarGanador(game.tablero);

    if (!result) {
      // دور البوت تلقائياً
      let botIdx = moveBot(game.tablero);
      if (botIdx !== undefined) game.tablero[botIdx] = symbols[1];
      result = verificarGanador(game.tablero);
    }

    let finishMsg = '';
    let user = global.db.data.users[m.sender]

if (result === 'empate') {
  user.coin += 3
  finishMsg = '🤝 *تعادل!* تم إرجاع 3 عملات'
}
else if (result === symbols[0]) {
  user.coin += 6
  finishMsg = '🏆 *فزت على البوت!* 💰 +6 عملات'
}
else {
  finishMsg = '💀 *خسرت أمام البوت!* 💰 -3 عملات'
}

    let updatedCaption = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*✧ \`نتائج التحدي الملكي\` ✧*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
${renderTablero(game.tablero)}
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

${result ? `> *الخاتمة:* ${finishMsg}` : `> *الدور القادم:* أرسل رقماً آخر`}

*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`;

    await conn.reply(m.chat, updatedCaption, m);
    if (result) delete conn.tttbot[id];
  } else {
    m.reply('*❌ هذا المربع محجوز، اختر رقماً آخر!*');
  }
};

handler.help = ['اكس_بوت'];
handler.tags = ['game'];
handler.command = /^(اكس_بوت|xbot|tttbot)$/i;

export default handler;
