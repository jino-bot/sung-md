let handler = async (m, { conn, args }) => {
  if (!args[0] || args[0] !== 'فك') return
  if (!m.quoted) throw '□ رد على رسالة الشخص الذي تريد فك الحظر عنه'

  let who = m.quoted.sender
  let user = global.db.data.users[who]
  if (!user) throw '□ المستخدم غير موجود في قاعدة البيانات'

  if (!user.banned) throw '□ هذا المستخدم غير محظور أصلاً'

  user.banned = false

  conn.reply(
    m.chat,
    `@${who.split('@')[0]} تم فك الحظر ويمكنك استخدام أوامر البوت الآن ✅`,
    m,
    { mentions: [who] }
  )
}

handler.help = ['ban فك (reply)']
handler.tags = ['owner']
handler.command = /^باند$/i
handler.rowner = true

export default handler