import { exec } from 'child_process'
import fs from 'fs'
import path from 'path'

let handler = async (m, { conn, args }) => {
  const query = args.join(' ').trim()

  if (!query) {
    return conn.reply(
      m.chat,
      '🐾 اكتب اسم الحيوان لإرسال صوته.\n\nمثال:\n.صوت اسد\n.صوت كلب',
      m
    )
  }

  const tempDir = './temp'
  if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true })

  const audioPath = path.join(tempDir, `animal_${Date.now()}.mp3`)

  // 🔊 تفاعل عند استقبال الأمر
  try {
    await conn.sendMessage(m.chat, {
      react: { text: '🔊', key: m.key }
    })
  } catch {}

  // بحث يوتيوب تلقائي
  const searchQuery = `${query} sound effect`
  const command = `yt-dlp -x --audio-format mp3 "ytsearch1:${searchQuery}" -o "${audioPath}"`

  exec(command, async (err) => {
    if (err || !fs.existsSync(audioPath)) {
      console.error('❌ خطأ تحميل الصوت:', err)

      try {
        await conn.sendMessage(m.chat, {
          react: { text: '❌', key: m.key }
        })
      } catch {}

      return conn.reply(
        m.chat,
        `❌ فشل جلب صوت "${query}"\n\n📌 جرب اسم آخر أو تأكد أن yt-dlp يعمل.`,
        m
      )
    }

    // ✅ جاهز
    try {
      await conn.sendMessage(m.chat, {
        react: { text: '✅', key: m.key }
      })
    } catch {}

    const caption = `
*❐═━━━═╊⊰🐾⊱╉═━━━═❐*

🔊 *صوت حيوان*
📝 *الاسم:* ${query}

*❐═━━━═╊⊰🐾⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*
    `.trim()

    try {
      await conn.sendMessage(
        m.chat,
        {
          audio: fs.readFileSync(audioPath),
          mimetype: 'audio/mpeg',
          caption
          // لو تريده ڤويس:
          // ptt: true
        },
        { quoted: m }
      )
    } catch (e) {
      console.error('❌ خطأ الإرسال:', e)
      await conn.reply(m.chat, '⚠️ حدث خطأ أثناء إرسال الصوت.', m)
    } finally {
      try { fs.unlinkSync(audioPath) } catch {}
    }
  })
}

handler.help = ['صوت <اسم الحيوان>']
handler.tags = ['ai', 'fun']
handler.command = /^صوت$/i

export default handler
