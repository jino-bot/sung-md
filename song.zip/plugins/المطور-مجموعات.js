let handler = async (m, { conn }) => {

  // رقم مرسل الأمر
  const senderJID = m.key.participant || m.key.remoteJid
  const senderNumber = senderJID.split('@')[0]

  // رقم البوت من settings.js
  const botNumber = (global.botNumber || '').replace(/[^0-9]/g, '')

  // قائمة المالكين
  const owners = global.owner.map(o => o[0])

  // حماية إضافية (اختيارية)
  if (!owners.includes(senderNumber)) {
    return conn.reply(m.chat, '❌ هذا الأمر مخصص للمالك فقط.', m)
  }

  // جلب جميع المجموعات
  const groupsData = await conn.groupFetchAllParticipating()
  const groups = Object.entries(groupsData)

  if (!groups.length) {
    return conn.reply(m.chat, '❌ لا يوجد مجموعات حالياً.', m)
  }

  // تنسيق القائمة
  const list = groups.map(([id, group], i) =>
    `*${i + 1}. ${group.subject}*\n🆔 ${id}\n━━━━━━━━━━━━━━`
  ).join('\n\n')

  const response =
    `📊 البوت (${botNumber || 'غير محدد'}) مشترك في *${groups.length}* مجموعة:\n\n${list}`

  await conn.sendMessage(m.chat, { text: response }, { quoted: m })
}

handler.command = ['مجموعات']
handler.tags = ['owner']
handler.help = ['مجموعات']
handler.owner = true

export default handler