import axios from "axios";
const { generateWAMessageContent, generateWAMessageFromContent, proto } =
  (await import("@whiskeysockets/baileys")).default;

const base = "https://www.pinterest.com";
const search = "/resource/BaseSearchResource/get/";

const headers = {
  accept: "application/json, text/javascript, */*; q=0.01",
  referer: "https://www.pinterest.com/",
  "user-agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
  "x-app-version": "a9522f",
  "x-pinterest-appstate": "active",
  "x-pinterest-pws-handler": "www/[username]/[slug].js",
  "x-requested-with": "XMLHttpRequest",
};

async function getCookies() {
  const res = await axios.get(base);
  return res.headers["set-cookie"]
    .map(v => v.split(";")[0])
    .join("; ");
}

async function searchPinterest(query) {
  const cookies = await getCookies();

  const params = {
    source_url: `/search/pins/?q=${query}`,
    data: JSON.stringify({
      options: {
        query,
        scope: "pins",
        bookmarks: [""],
        page_size: 10,
      },
      context: {},
    }),
    _: Date.now(),
  };

  const { data } = await axios.get(base + search, {
    headers: { ...headers, cookie: cookies },
    params,
  });

  const results = data.resource_response.data.results.filter(
    v => v.images?.orig?.url
  );

  return results.slice(0, 10).map(v => v.images.orig.url);
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text)
    return m.reply(`مثال:\n${usedPrefix + command} anime`);

  await m.reply("🔎 جاري البحث ...");

  const images = await searchPinterest(text);
  if (!images.length) return m.reply("❌ لا توجد نتائج");

  async function createImage(url) {
    const { imageMessage } = await generateWAMessageContent(
      { image: { url } },
      { upload: conn.waUploadToServer }
    );
    return imageMessage;
  }

  let cards = [];
  let i = 1;

  for (let img of images) {
    cards.push({
      body: proto.Message.InteractiveMessage.Body.fromObject({
        text: `𝐏𝐇𝐎𝐓𝐎 𝐍𝐔𝐌 ${i++}`,
      }),
      footer: proto.Message.InteractiveMessage.Footer.fromObject({
        text: "> 𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃",
      }),
      header: proto.Message.InteractiveMessage.Header.fromObject({
        hasMediaAttachment: true,
        imageMessage: await createImage(img),
      }),
      nativeFlowMessage:
        proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
          buttons: [
            {
              name: "cta_url",
              buttonParamsJson: JSON.stringify({
                display_text: "📢┇قناة البوت┇📢",
                url: "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o",
                merchant_url:
                  "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o",
              }),
            },
          ],
        }),
    });
  }

  const msg = generateWAMessageFromContent(
    m.chat,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: proto.Message.InteractiveMessage.fromObject({
            body: { text: "*تم تحميل الصور*" },
            footer: { text: "> 𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃" },
            carouselMessage: { cards },
          }),
        },
      },
    },
    {}
  );

  await conn.relayMessage(m.chat, msg.message, {
    messageId: msg.key.id,
  });
};

handler.help = ["pinterest"];
handler.tags = ["downloader"];
handler.command =
  /^(pinterest|pin|صور|بين|صوره-بين)$/i;
handler.limit = true;

export default handler;