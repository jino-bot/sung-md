import axios from 'axios'

const GEMINI_KEY = 'AIzaSyBVQ94Sb8l7zXkiWqycDIM8c11qeZ1xfEg'

let handler = async (m, { text, conn }) => {
  if (!text) {
    return conn.reply(
      m.chat,
      '🤖 *جبيتي هنا*\n\nاكتب سؤالك مباشرة:\n.جبيتي اشرح لي async await',
      m
    )
  }

  // تفاعل مبدئي
  await conn.sendMessage(m.chat, {
    react: { text: '🤖', key: m.key }
  })

  // 🧠 برومبت شخصية ChatGPT 5
  const prompt = `
أنت شخصية اسمها "جبيتي".
تمثل ChatGPT الإصدار الخامس (ChatGPT-5).
أسلوبك:
- ذكي
- واضح
- مختصر
- احترافي
- مباشر بدون حشو

تشرح المفاهيم المعقدة ببساطة.
تعطي أمثلة عند الحاجة.
لا تذكر Gemini ولا Google ولا AI.
لا تستخدم إيموجيات.
لا تتجاوز 80 كلمة.

السؤال:
"${text}"
  `.trim()

  try {
    const res = await axios.post(
      `https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=${GEMINI_KEY}`,
      {
        contents: [
          {
            parts: [{ text: prompt }]
          }
        ]
      },
      {
        headers: { 'Content-Type': 'application/json' }
      }
    )

    let reply =
      res.data?.candidates?.[0]?.content?.parts?.[0]?.text ||
      'لم أتمكن من توليد رد حالياً.'

    reply = reply.replace(/\*\*/g, '').trim()

    // تفاعل نجاح
    await conn.sendMessage(m.chat, {
      react: { text: '✅', key: m.key }
    })

    return conn.reply(
      m.chat,
      `*جبيتي:*\n${reply}`,
      m
    )
  } catch (err) {
    console.error('❌ خطأ جبيتي:', err)

    await conn.sendMessage(m.chat, {
      react: { text: '❌', key: m.key }
    })

    return conn.reply(
      m.chat,
      '⚠️ حدث خطأ أثناء التفكير، حاول مرة أخرى.',
      m
    )
  }
}

handler.help = ['جبيتي <سؤال>']
handler.tags = ['ai']
handler.command = /^جبيتي$/i

export default handler
