const timeout = 180000;

let handler = async (m, { conn, usedPrefix, command }) => {
    conn.bomb = conn.bomb ? conn.bomb : {};
    let id = m.chat;

    if (conn.bomb[id]) return conn.reply(m.chat, '*⚠️ هناك تحدي قائم بالفعل في هذه المجموعة!*', conn.bomb[id][3]);

    const bombs = ['💥', '✅', '✅', '✅', '✅', '✅', '✅', '✅', '✅'].sort(() => Math.random() - 0.5);
    const board = bombs.map((v, i) => ({
        position: i + 1,
        emot: v,
        state: false,
        number: ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣'][i]
    }));

    let caption = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*✧ \`تحدي صناديق التنين الملعونة\` ✧*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅╔*

*أرسل رقماً من ( 1 ) إلى ( 9 ) لفتح الصناديق.*
*كل صندوق آمن تفتحه يضاعف جائزتك!*

*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
   ${board.slice(0, 3).map(v => v.number).join('')}
   ${board.slice(3, 6).map(v => v.number).join('')}
   ${board.slice(6).map(v => v.number).join('')}
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

> *الوقت المتاح: 3 دقائق*
> *قم بالرد على الرسالة بالرقم.*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`;

    let msg = await conn.reply(m.chat, caption, m);

    conn.bomb[id] = [
        m.sender,
        board,
        setTimeout(() => {
            if (conn.bomb[id]) {
                conn.reply(m.chat, `*⌛ انتهى الوقت! انفجرت الصناديق.*`, conn.bomb[id][3]);
                delete conn.bomb[id];
            }
        }, timeout),
        msg,
        200 // الجائزة الابتدائية للنقاط (bank)
    ];
};

handler.help = ['قنبلة'];
handler.tags = ['game'];
handler.command = /^(قنبلة|متفجرات)$/i;

export default handler;
