import fs from 'fs'
import path from 'path'

const FILE_PATH = path.resolve('src/datatms.json')

const channelInfo = {
  isForwarded: true,
  forwardedNewsletterMessageInfo: {
    newsletterJid: '120363416870755391@newsletter',
    newsletterName: '𝐒𝐔𝐍𝐆 ꒰🐉⃝⃕꒱𝐔𝐏𝐃𝐀𝐓𝐄',
    serverMessageId: -1
  }
}

let handler = async (m, { conn, participants }) => {
  try {
    if (!m.isGroup) return m.reply('❌ هذا الأمر يعمل داخل المجموعات فقط.')

    if (!fs.existsSync(FILE_PATH))
      return m.reply('⚠️ لا توجد بيانات تفاعل بعد.')

    const data = JSON.parse(fs.readFileSync(FILE_PATH))
    const chatId = m.chat

    if (!data[chatId] || !data[chatId].enabled)
      return m.reply('⚠️ نظام الحسبة غير مفعل.\nاستخدم `.حسبة on`')

    const groupData = data[chatId]
    const usersData = groupData.users || {}
    const totalMessages = groupData.total || 0

    // كل أعضاء المجموعة
    const members = participants.map(p => p.id)

    // دمج الجميع حتى اللي 0
    let stats = members.map(uid => [uid, usersData[uid] || 0])
    stats.sort((a, b) => b[1] - a[1])

    let text = `*❐═━━━═╊⊰🐉⊱╉═━━━═❐*\n`
    text += `*『📊┇ تفاعل المجموعة ┇📊』*\n`
    text += `*❐═━━━═╊⊰🐉⊱╉═━━━═❐*\n\n`
    text += `📌 *إجمالي الرسائل:* \`${totalMessages}\`\n`
    text += `👥 *عدد الأعضاء:* \`${members.length}\`\n`
    text += `*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*\n`

    stats.forEach(([uid, count], i) => {
      text += `*${i + 1} ┇* @${uid.split('@')[0]} » \`${count}\` رسالة\n`
    })

    text += `*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*\n`
    text += `*❐═━━━═╊⊰🐉⊱╉═━━━═❐*`

    await conn.sendMessage(
      chatId,
      {
        text,
        contextInfo: {
          ...channelInfo,
          mentionedJid: members
        }
      },
      { quoted: m }
    )

  } catch (e) {
    console.error('❌ خطأ في التفاعل:', e)
    m.reply('❌ حدث خطأ أثناء جلب التفاعل.')
  }
}

handler.help = ['التفاعل']
handler.tags = ['group']
handler.command = ['التفاعل']
handler.group = true

export default handler