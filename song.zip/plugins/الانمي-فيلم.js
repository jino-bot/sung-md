import fetch from 'node-fetch';

let handler = async (message, { text, conn, usedPrefix, command }) => {
  try {
    if (!text) {
      return await conn.sendMessage(
        message.chat,
        { text: `🎬 *طريقة الاستخدام:*\n\`${usedPrefix + command} اسم الفيلم\`\n\nمثال:\n\`${usedPrefix + command} Inception\`` },
        { quoted: message }
      );
    }

    const apiKey = "8796d665b3896a3fc541fb2605b91f58"; // ✅ مفتاح TMDB API
    const encodedTitle = encodeURIComponent(text);
    const searchUrl = `https://api.themoviedb.org/3/search/movie?api_key=${apiKey}&query=${encodedTitle}&language=ar`;

    await conn.sendPresenceUpdate("composing", message.chat);

    const searchResponse = await fetch(searchUrl);
    const searchData = await searchResponse.json();

    if (!searchData.results || searchData.results.length === 0) {
      throw new Error(`❌ لم يتم العثور على فيلم بعنوان: *${text}*`);
    }

    // اختيار أول نتيجة
    const movie = searchData.results[0];
    const movieId = movie.id;

    // جلب تفاصيل الفيلم
    const detailsUrl = `https://api.themoviedb.org/3/movie/${movieId}?api_key=${apiKey}&language=ar`;
    const detailsResponse = await fetch(detailsUrl);
    const detailsData = await detailsResponse.json();

    let result = `🎬 *${detailsData.title}* (${detailsData.release_date?.split("-")[0] || "غير معروف"})\n\n`;
    result += `📌 *التقييم:* ${detailsData.vote_average}/10 ⭐️\n`;
    result += `🎭 *النوع:* ${detailsData.genres.map(g => g.name).join(", ")}\n`;
    result += `🕒 *المدة:* ${detailsData.runtime} دقيقة\n`;
    result += `🎥 *الشعبية:* ${detailsData.popularity}\n`;
    result += `📝 *القصة:* ${detailsData.overview || "لا توجد قصة متاحة"}\n\n`;
    result += `🎞️ *المصدر:* [رابط TMDB](https://www.themoviedb.org/movie/${movieId})`;

    let options = { text: result, mentions: [message.sender], quoted: message };

    if (detailsData.poster_path) {
      options.image = { url: `https://image.tmdb.org/t/p/w500${detailsData.poster_path}` };
    }

    await conn.sendMessage(message.chat, options);
  } catch (error) {
    console.error("Error:", error);
    await conn.sendMessage(
      message.chat,
      { text: `⚠️ | خطأ: ${error.message}` },
      { quoted: message }
    );
  }
};

handler.help = ["فلم"];
handler.tags = ["movies"];
handler.command = ["فلم"];

export default handler;