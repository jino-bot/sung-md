import pkg from "@whiskeysockets/baileys";
const { generateWAMessageFromContent, prepareWAMessageMedia } = pkg;
import fs from 'fs';

const cooldown = 45000;

let handler = async (m, { conn, args, usedPrefix, command }) => {
    const now = Date.now();
    const user = global.db.data.users[m.sender];

    if (!user) return;

    const lastWait = user.wait || 0;
    const remaining = lastWait + cooldown - now;
    if (remaining > 0)
        return conn.reply(
            m.chat,
            `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*🕓 السوق مغلق حالياً، انتظر ⟦ ${msToTime(remaining)} ⟧ لفتح صفقة جديدة.*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`,
            m
        );

    let betAmount = parseInt(args[0]);

    // عند الضغط على أزرار صعود / هبوط
    if (args[1] && !isNaN(betAmount)) {
        const choice = args[1].toLowerCase();
        return await executeTrade(m, conn, choice, betAmount, user, now, usedPrefix, command);
    }

    if (isNaN(betAmount) || betAmount < 10) {
        return conn.reply(
            m.chat,
            `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*⚠️ يجب تحديد مبلغ لدخول السوق!*\n*استخدم:* ${usedPrefix + command} <المبلغ>\n\n*مثال:* ${usedPrefix + command} 1000\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`,
            m
        );
    }

    if (user.coin < betAmount)
        return conn.reply(
            m.chat,
            `*❌ رصيدك لا يكفي للمخاطرة! لديك: ⟦ ${user.coin.toLocaleString()} عملة ⟧*`,
            m
        );

    const pathImg = './src/media/تداول.png';
    let media;
    if (fs.existsSync(pathImg)) {
        media = await prepareWAMessageMedia(
            { image: fs.readFileSync(pathImg) },
            { upload: conn.waUploadToServer }
        );
    }

    const buttons = [
        {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: "📈 صعود",
                id: `${usedPrefix + command} ${betAmount} up`
            })
        },
        {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: "📉 هبوط",
                id: `${usedPrefix + command} ${betAmount} down`
            })
        }
    ];

    const interactiveMessage = {
        body: {
            text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*✧ \`منصة تداول التنين الملكي\` ✧*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

👤 *اللاعب :* @${m.sender.split('@')[0]}
💰 *رصيدك :* ⟦ ${user.coin.toLocaleString()} عملة ⟧
📊 *مبلغ التداول :* ⟦ ${betAmount.toLocaleString()} عملة ⟧

*– يرجى التخمين.. هل سهم البوت سيرتفع أم سيهبط؟*`
        },
        footer: { text: "𝚂𝙾𝙽𝙶 𝙱𝙾𝚃 • 𝚃𝚁𝙰𝙳𝙸𝙽𝙶 𝚂𝚈𝚂𝚃𝙴𝙼" },
        header: {
            title: "Stock Market",
            hasMediaAttachment: !!media,
            imageMessage: media?.imageMessage
        },
        nativeFlowMessage: { buttons }
    };

    const msg = generateWAMessageFromContent(
        m.chat,
        { viewOnceMessage: { message: { interactiveMessage } } },
        { userJid: conn.user.jid, quoted: m, mentions: [m.sender] }
    );

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
};

async function executeTrade(m, conn, choice, betAmount, user, now, usedPrefix, command) {
    if (user.coin < betAmount) return m.reply('*❌ رصيدك غير كافٍ!*');

    const loadingMsg = await conn.sendMessage(m.chat, { text: `*⏳ جاري مراقبة المؤشرات وفتح الصفقة...*` });
    await new Promise(res => setTimeout(res, 2000));

    const marketMove = Math.random() > 0.55 ? choice : (choice === 'up' ? 'down' : 'up');
    const isProfit = marketMove === choice;
    const multiplier = 1.8;
    const resultAmount = isProfit ? Math.floor(betAmount * multiplier) : -betAmount;

    user.coin += resultAmount;
    user.wait = now;

    let status = isProfit ? "✅ صفقة ناجحة (PROFIT)" : "❌ صفقة خاسرة (LOSS)";

    let resultRender = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*✧ \`ملخص كشف الحساب\` ✧*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

💹 *حالة السوق :* ⟦ ${marketMove === 'up' ? 'صعود 📈' : 'هبوط 📉'} ⟧
🏆 *النتيجة :* ${status}

*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
${isProfit
        ? `*💰 الأرباح : +⟦ ${resultAmount.toLocaleString()} عملة ⟧*`
        : `*💸 الخسارة : -⟦ ${Math.abs(resultAmount).toLocaleString()} عملة ⟧*`}
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

> *رصيدك الإجمالي: ${user.coin.toLocaleString()} عملة*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`;

    const buttons = [
        {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: "🔄 تداول مرة أخرى",
                id: `${usedPrefix + command} ${betAmount}`
            })
        }
    ];

    const interactiveMessage = {
        body: { text: resultRender },
        footer: { text: "𝚂𝙾𝙽𝙶 𝙱𝙾𝚃 • 𝚃𝚁𝙰𝙳𝙸𝙽𝙶" },
        nativeFlowMessage: { buttons }
    };

    const finalMsg = generateWAMessageFromContent(
        m.chat,
        { viewOnceMessage: { message: { interactiveMessage } } },
        { userJid: conn.user.jid, quoted: m }
    );

    await conn.sendMessage(m.chat, { delete: loadingMsg.key });
    await conn.relayMessage(m.chat, finalMsg.message, { messageId: finalMsg.key.id });
}

handler.command = ['تداول', 'trade'];
export default handler;

function msToTime(duration) {
    const s = Math.floor(duration / 1000) % 60;
    const m = Math.floor(duration / 60000) % 60;
    return `${m ? m + ' دقيقة و ' : ''}${s} ثانية`;
}