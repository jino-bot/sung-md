import moment from 'moment-timezone'

let handler = async (m, { conn, text, participants }) => {
  // تصفية المشاركين
  let admins = participants.filter(p => p.admin)
  let members = participants.filter(p => !p.admin)

  // بيانات المجموعة
  let groupMetadata = await conn.groupMetadata(m.chat)
  let groupName = groupMetadata.subject
  let time = moment.tz('Asia/Riyadh').format('hh:mm A')
  let date = moment.tz('Asia/Riyadh').format('YYYY/MM/DD')
  let messageContent = text ? text : 'لا توجد رسالة محددة'

  // نص الرسالة (بدون أي تغيير)
  let teks = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
\`˼🌐˹ منشن جميع أعضاء المجموعة\`↶
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
💠 *اسم المجموعة:* 『 ${groupName} 』
📩 *الرسالة:* 『 ${messageContent} 』
📅 *التاريخ:* 『 ${date} 』
🕰️ *الوقت:* 『 ${time} 』
👥 *إجمالي المستهدفين:* 『 ${participants.length} 』
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> ˼👑˹  *قائمة المشرفين* ↶
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
${admins.map(v => `*┊⟣*｢@${v.id.split('@')[0]}｣`).join('\n')}
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
> ˼👥˹  *قائمة الأعضاء* ↶
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
${members.map(v => `*┊⟣*｢@${v.id.split('@')[0]}｣`).join('\n')}
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> ˼👤˹  *مسؤول المنشن* ↶
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*┊⟣*｢@${m.sender.split('@')[0]}｣
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

  // ===== معلومات القناة + المنشن (الطريقة الصحيحة) =====
  const channelInfo = {
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: '120363416870755391@newsletter',
      newsletterName: '𝐒𝐔𝐍𝐆 ꒰🐉⃝⃕꒱𝐔𝐏𝐃𝐀𝐓𝐄',
      serverMessageId: -1
    },
    mentionedJid: participants.map(u => u.id)
  }

  // إرسال الرسالة
  await conn.sendMessage(
    m.chat,
    {
      text: teks,
      contextInfo: channelInfo
    },
    { quoted: m }
  )
}

handler.help = ['منشن_الكل']
handler.tags = ['group']
handler.command = /^(منشن_الكل|الكل)$/i
handler.group = true
handler.admin = true

export default handler