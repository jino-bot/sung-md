let handler = async (m, { conn, args, usedPrefix, command, isAdmin, isOwner, isBotAdmin }) => {
    // 1. التحقق من الصلاحيات (المشرفين أو المطور)
    if (!isAdmin && !isOwner) return m.reply('*[❗] هذا الأمر مخصص للمشرفين والمطور فقط!*')
    
    // 2. التحقق من أن البوت مشرف ليتمكن من جلب الرابط
    if (!isBotAdmin) return m.reply('*[❗] يجب أن أكون مشرفاً لأتمكن من استخراج رابط المجموعة!*')

    try {
        // 3. جلب كود الرابط من الواتساب
        let groupCode = await conn.groupInviteCode(m.chat)
        let link = `https://chat.whatsapp.com/${groupCode}`
        let groupName = (await conn.groupMetadata(m.chat)).subject

        // 4. تنسيق الرسالة
        let teks = `
*❐═━━━═╊⊰🔗⊱╉═━━━═❐*
✧ \`رابط دعوة المجموعة\`
*❐═━━━═╊⊰🔗⊱╉═━━━═❐*
💠 *المجموعة:* 『 ${groupName} 』
🌐 *الرابط:* ${link}
*❐═━━━═╊⊰🔗⊱╉═━━━═❐*
> *ملاحظة: الرابط مخصص للدعوة فقط.*
*❐═━━━═╊⊰🔗⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`.trim()

        // 5. الإرسال مع دمج بيانات القناة (allfake)
        await conn.sendMessage(m.chat, { 
            text: teks,
            contextInfo: {
                ...global.rcanal.contextInfo,
                externalAdReply: {
                    title: '𝐒𝐎𝐍Γ 𝐔𝐏𝐃𝐀𝐓𝐄 ꒰🐉⃝⃕꒱',
                    body: groupName,
                    thumbnailUrl: 'https://files.catbox.moe/zd89n4.jpg', 
                    sourceUrl: link,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m })

    } catch (e) {
        console.error(e)
        m.reply('*[❌] حدث خطأ أثناء محاولة جلب الرابط، تأكد من صلاحياتي.*')
    }
}

handler.help = ['لينكي']
handler.tags = ['group']
handler.command = /^(لينكي|رابط|الرابط)$/i
handler.group = true
handler.botAdmin = true

export default handler
