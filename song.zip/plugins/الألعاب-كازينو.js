const cooldown = 30000;

let handler = async (m, { conn, args, usedPrefix, command }) => {
    const now = Date.now();
    const user = global.db.data.users[m.sender];

    const last = user.wait || 0;
    const remaining = last + cooldown - now;
    if (remaining > 0) return conn.reply(m.chat, `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*🕓 اهدأ يا بشر، انتظر ⟦ ${msToTime(remaining)} ⟧ قبل اللعب مجدداً.*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`, m);

    // نظام التعرف الذكي على المدخلات
    let tipo = '';
    let cantidad = 0;

    // فحص المدخلات سواء كانت الكلمة الأولى أو الثانية
    for (let arg of args) {
        let lowArg = arg.toLowerCase();
        if (['xp', 'exp'].includes(lowArg)) tipo = 'exp';
        else if (['coin', 'money', 'عملات', 'كاش'].includes(lowArg)) tipo = 'coin';
        else if (['bank', 'بنك'].includes(lowArg)) tipo = 'bank';
        else if (!isNaN(parseInt(arg))) cantidad = parseInt(arg);
    }

    if (!tipo || !cantidad || cantidad < 10) {
        return m.reply(`*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*⚠️ الاستخدام الصحيح:*\n*${usedPrefix + command} <الكمية> <xp|coin|bank>*\n\n*مثال: ${usedPrefix + command} 1000 xp*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`);
    }

    const saldo = user[tipo];
    if (saldo < cantidad) return m.reply(`*❌ رصيدك غير كافٍ من ${tipoBonito(tipo)}. لديك حالياً: ⟦ ${formatNumber(saldo)} ⟧*`);

    const emojis = ['🐲', '💎', '⚡', '🪙', '🔥', '🔮'];
    let final;
    
    let { key } = await conn.sendMessage(m.chat, { text: renderRandom(emojis) }, { quoted: m });

    for (let i = 0; i < 3; i++) {
        await new Promise(res => setTimeout(res, 400));
        await conn.sendMessage(m.chat, { text: renderRandom(emojis), edit: key });
    }

    final = [
        [rand(emojis), rand(emojis), rand(emojis)],
        [rand(emojis), rand(emojis), rand(emojis)],
        [rand(emojis), rand(emojis), rand(emojis)],
    ];

    const resultado = evaluarLinea(final[1]);
    let ganancia = 0;
    let textoFinal = '';

    if (resultado === 'triple') {
        ganancia = cantidad * 3;
        textoFinal = `*🎊 مذهل! فوز ثلاثي ملكي! 🎊*\n*لقد ربحت: ⟦ ${formatNumber(ganancia)} ${tipoBonito(tipo)} ⟧*`;
    } else if (resultado === 'doble') {
        ganancia = Math.floor(cantidad * 1.5);
        textoFinal = `*✨ تطابق ثنائي.. ليس سيئاً! ✨*\n*لقد ربحت: ⟦ ${formatNumber(ganancia)} ${tipoBonito(tipo)} ⟧*`;
    } else {
        ganancia = -cantidad;
        textoFinal = `*💀 حظاً عاثراً.. ابتلع التنين مراهنتك! 💀*\n*خسرت: ⟦ ${formatNumber(cantidad)} ${tipoBonito(tipo)} ⟧*`;
    }

    user[tipo] += ganancia;
    user.wait = now;

    const resultRender = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*✧ \`ماكينة حظ التنين\` ✧*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

${render(final)}

*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
${textoFinal}
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

> *رصيدك الحالي في ${tipoBonito(tipo)} هو: ${formatNumber(user[tipo])}*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`;

    await new Promise(res => setTimeout(res, 500));
    await conn.sendMessage(m.chat, { text: resultRender, edit: key });
};

handler.command = ['slot', 'كازينو', 'ماكينة', 'حظ'];
handler.tags = ['game'];

export default handler;

function rand(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

function render(matriz) {
    return `*╔═════ 🎰 ═════╗*\n\n     ${matriz[0].join('  |  ')}\n     ${matriz[1].join('  |  ')}\n     ${matriz[2].join('  |  ')}\n\n*╚═════ 🎰 ═════╝*`;
}


function renderRandom(emojis) {
    const temp = [[rand(emojis), rand(emojis), rand(emojis)], [rand(emojis), rand(emojis), rand(emojis)], [rand(emojis), rand(emojis), rand(emojis)]];
    return `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*✧ \`جاري تدوير الماكينة...\` ✧*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n\n${render(temp)}\n\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`;
}

function evaluarLinea(arr) {
    const [a, b, c] = arr;
    if (a === b && b === c) return 'triple';
    if (a === b || b === c || a === c) return 'doble';
    return 'nada';
}

function formatNumber(num) { return num.toLocaleString('en').replace(/,/g, '.'); }

function msToTime(duration) {
    const s = Math.floor(duration / 1000) % 60;
    const m = Math.floor(duration / (1000 * 60)) % 60;
    return `${m ? `${m} دقيقة و ` : ''}${s} ثانية`;
}

function tipoBonito(tipo) {
    if (tipo === 'coin') return 'العملات 🪙';
    if (tipo === 'bank') return 'رصيد البنك 🏦';
    return 'XP ⚡';
}
