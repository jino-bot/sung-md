let handler = async (m, { conn }) => {

  let response =
    m.message?.interactiveResponseMessage ||
    m.message?.templateButtonReplyMessage ||
    m.message?.buttonsResponseMessage

  if (!response) return true

  let id = null
  if (response.nativeFlowResponseMessage?.paramsJson) {
    let json = JSON.parse(response.nativeFlowResponseMessage.paramsJson)
    id = json.id
  } else {
    id = response.selectedId || response.selectedButtonId
  }

  if (!id || !id.startsWith('kasab|')) return true

  let session = global.kasabSession?.[m.sender]
  if (!session) {
    await m.reply('❌ انتهت العملية أو لا توجد بيانات.')
    return true
  }

  let { target, amount } = session
  let type = id.split('|')[1]

  let db = global.db.data

  // إنشاء المستخدم إن لم يكن موجود
  if (!db.users[target]) {
    db.users[target] = {
      exp: 0,
      coin: 0, // العملات
      bank: 0, // النقاط
      level: 0
    }
  }

  let user = db.users[target]
  let added = []

  // ⭐ النقاط (bank)
  if (type === 'points' || type === 'all') {
    user.bank += amount
    added.push(`🏦 النقاط: +${amount}`)
  }

  // 💰 العملات (coin)
  if (type === 'coins' || type === 'all') {
    user.coin += amount
    added.push(`🪙 العملات: +${amount}`)
  }

  // 💡 الخبرة
  if (type === 'exp' || type === 'all') {
    user.exp += amount
    added.push(`💡 الخبرة: +${amount}`)
  }

  // 🔥 حفظ فعلي للداتابيس
  global.db.data = db

  delete global.kasabSession[m.sender]

  let name = await conn.getName(target)

  await conn.reply(
    m.chat,
    `*『✅┇تم التسليم بنجاح┇✅』*

*👤┇المستلم:* ${name}
${added.map(v => `*• ${v}*`).join('\n')}

*✔️ تم تحديث الحساب بنجاح!*`,
    m
  )

  return true
}

handler.before = handler
export default handler