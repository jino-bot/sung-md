import pkg from "@whiskeysockets/baileys";
const { generateWAMessageFromContent } = pkg;

const cooldown = 30000;

let handler = async (m, { conn, args, usedPrefix, command }) => {
    const now = Date.now();
    const user = global.db.data.users[m.sender];
    
    // نظام الانتظار
    const lastWait = user.wait || 0;
    const remaining = lastWait + cooldown - now;
    if (remaining > 0) return conn.reply(m.chat, `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*🕓 اهدأ يا بطل، انتظر ⟦ ${msToTime(remaining)} ⟧ قبل المحاولة مجدداً.*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`, m);

    const betAmount = parseInt(args[0]);

    // إذا لم يحدد المبلغ أو جاء الاختيار من زر
    if (isNaN(betAmount) || betAmount < 1) {
        const colorInput = args[0]?.toLowerCase();
        const betFromButton = parseInt(args[1]);

        if (['red', 'black', 'green'].includes(colorInput) && !isNaN(betFromButton)) {
            return await executeRoulette(m, conn, colorInput, betFromButton, user, now);
        }

        return conn.reply(m.chat, `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*⚠️ يجب تحديد مبلغ صالح للمراهنة!*\n*استخدم:* ${usedPrefix + command} <المبلغ>\n\n*مثال:* ${usedPrefix + command} 10\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`, m);
    }

    // التحقق من رصيد العملات (coin)
    if ((user.coin || 0) < betAmount) return conn.reply(m.chat, `*❌ رصيدك لا يكفي! لديك حالياً: ⟦ ${user.coin.toLocaleString()} 🪙 عملة ⟧*`, m);

    // إرسال رسالة الأزرار لاختيار اللون
    const buttons = [
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔴 الأحمر (2x)", id: `${usedPrefix + command} red ${betAmount}` }) },
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⚫ الأسود (2x)", id: `${usedPrefix + command} black ${betAmount}` }) },
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🟢 الأخضر (14x)", id: `${usedPrefix + command} green ${betAmount}` }) }
    ];

    const interactiveMessage = {
        body: { text: `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*✧ \`مراهنة الروليت الملكية\` ✧*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

*💰 المبلغ المراهن به: ⟦ ${betAmount.toLocaleString()} 🪙 عملة ⟧*

*اختر اللون الذي تتوقع فوزه:*` },
        footer: { text: "𝚂𝙾𝙽𝙶 𝙱𝙾𝚃 • 𝚁𝙾𝚄𝙻𝙴𝚃𝚃𝙴" },
        nativeFlowMessage: { buttons }
    };

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: { message: { interactiveMessage } }
    }, { userJid: conn.user.jid, quoted: m });

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
};

async function executeRoulette(m, conn, color, betAmount, user, now) {
    if ((user.coin || 0) < betAmount) return m.reply('*❌ رصيد العملات لديك غير كافٍ الآن!*');

    let { key } = await conn.sendMessage(m.chat, { text: `*🎰 جاري تدوير عجلة الروليت...*` });
    await new Promise(res => setTimeout(res, 1500));

    const resultColor = getRandomColor();
    const isWin = resultColor === color;
    let winAmount = 0;

    if (isWin) {
        winAmount = color === 'green' ? betAmount * 14 : betAmount * 2;
    }

    // تحديث رصيد العملات (coin)
    user.coin = (user.coin || 0) - betAmount + winAmount;
    user.wait = now;

    let colorEmoji = resultColor === 'red' ? '🔴 الأحمر' : resultColor === 'black' ? '⚫ الأسود' : '🟢 الأخضر';
    
    let resultRender = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*✧ \`نتيجة الروليت الملكية\` ✧*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

*🎰 استقرت الكرة على : ⟦ ${colorEmoji} ⟧*

*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
${isWin ? `*🎉 مبروك! لقد فزت بـ: ⟦ ${winAmount.toLocaleString()} 🪙 ⟧*` : `*💀 للأسف، خسرت مراهنتك: ⟦ ${betAmount.toLocaleString()} 🪙 ⟧*`}
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

> *رصيدك الحالي: ${user.coin.toLocaleString()} 🪙 عملة*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`;

    return conn.sendMessage(m.chat, { text: resultRender, edit: key });
}

handler.help = ['روليت <المبلغ>'];
handler.tags = ['game'];
handler.command = ['rt', 'ruleta', 'روليت'];

export default handler;

function getRandomColor() {
    const random = Math.random() * 100;
    if (random < 47.5) return 'red';
    if (random < 95) return 'black';
    return 'green';
}

function msToTime(duration) {
    const s = Math.floor(duration / 1000) % 60;
    const m = Math.floor(duration / 60000) % 60;
    return `${m ? m + ' دقيقة ' : ''}${s} ثانية`;
}
