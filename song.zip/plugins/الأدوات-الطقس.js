import axios from "axios"

let handler = async (m, { args, usedPrefix, command }) => {
    if (!args[0]) return m.reply(`*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n* \`˼⚠️˹ تـنـبـيـه هـام \` ↶*\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n*｢☁️｣⇇ يرجى كتابة اسم المدينة باللغة الإنجليزية*\n*💡 مثال:* ${usedPrefix}${command} London\n*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*\n> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`);

    try {
        // تفاعل الانتظار
        try { await m.react('🌤️') } catch (_) {}

        const response = await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${args.join(' ')}&units=metric&lang=ar&appid=060a6bcfa19809c2cd4d97a212b19273`)
        const res = response.data
        
        const name = res.name
        const country = res.sys.country
        const weatherDesc = res.weather[0].description
        const temp = res.main.temp
        const minTemp = res.main.temp_min
        const maxTemp = res.main.temp_max
        const humidity = res.main.humidity
        const wind = res.wind.speed

        let wea = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
* \`˼🌦️˹ حـالـة الـطـقـس الآن \` ↶*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

*｢📍┊الـمـوقـع الـجـغـرافـي┊📍｣*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*┊⟣ الـمـديـنـة:* 『 ${name} 』
*┊⟣ الـدولـة:* 『 ${country} 』
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

*｢🌡️┊بـيـانـات الأرصـاد الـحـالـيـة┊🌡️｣*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*┊⟣ الـمـنـظـر:* 『 ${weatherDesc} 』
*┊⟣ درجة الـحرارة:* 『 ${temp}°C 』
*┊⟣ الـنـهـايـة الـعـظمى:* 『 ${maxTemp}°C 』
*┊⟣ الـنـهـايـة الـصـغرى:* 『 ${minTemp}°C 』
*┊⟣ الـرطـوبـة:* 『 ${humidity}% 』
*┊⟣ سرعة الـريـاح:* 『 ${wind} km/h 』
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*

*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

        await conn.sendMessage(m.chat, {
            text: wea,
            contextInfo: {
                externalAdReply: {
                    title: `تقرير الطقس: ${name}, ${country}`,
                    body: `درجة الحرارة الحالية: ${temp}°C`,
                    mediaType: 1,
                    thumbnailUrl: 'https://files.catbox.moe/cplot6.png',
                    sourceUrl: 'https://whatsapp.com/channel/0029Vaardwo5vKA95jcDWU3P',
                    renderLargerThumbnail: false
                }
            }
        }, { quoted: m })

        try { await m.react('✅') } catch (_) {}

    } catch (e) {
        console.error(e)
        try { await m.react('❌') } catch (_) {}
        return m.reply('*⚠️ خطأ: لم يتم العثور على المدينة، تأكد من كتابة الاسم بالإنجليزية بشكل صحيح.*')
    }
}

handler.help = ['طقس']
handler.tags = ['tools']
handler.command = /^(طقس|weather)$/i

export default handler
