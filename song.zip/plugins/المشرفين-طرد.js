import moment from 'moment-timezone'

let handler = async (m, { conn, participants }) => {
  // تحقق من أن الأمر في مجموعة
  if (!m.isGroup) return m.reply('❌ هذا الأمر خاص بالمجموعات')

  // جلب الشخص المراد طرده
  let target =
    m.mentionedJid?.[0] ||
    m.quoted?.sender

  if (!target) {
    return m.reply('❌ استخدم الأمر بالرد على رسالة أو بالمنشن\nمثال:\n.طرد @user')
  }

  // لا تطرد نفسك
  if (target === m.sender) {
    return m.reply('❌ لا يمكنك طرد نفسك')
  }

  // تحقق أن الهدف موجود في المجموعة
  let member = participants.find(p => p.id === target)
  if (!member) {
    return m.reply('❌ المستخدم غير موجود في المجموعة')
  }

  // لا تطرد مشرف
  if (member.admin) {
    return m.reply('❌ لا يمكن طرد مشرف')
  }

  // طرد العضو
  await conn.groupParticipantsUpdate(m.chat, [target], 'remove')

  // بيانات
  let time = moment.tz('Asia/Riyadh').format('hh:mm A')
  let date = moment.tz('Asia/Riyadh').format('YYYY/MM/DD')

  let teks = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
\`˼🚫˹ تم طرد عضو من المجموعة\`↶
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
👤 *العضو المطرود:* ｢@${target.split('@')[0]}｣
👮‍♂️ *بواسطة:* ｢@${m.sender.split('@')[0]}｣
📅 *التاريخ:* 『 ${date} 』
🕰️ *الوقت:* 『 ${time} 』
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

  // ===== القناة + المنشن =====
  const channelInfo = {
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: '120363416870755391@newsletter',
      newsletterName: '𝐒𝐔𝐍𝐆 ꒰🐉⃝⃕꒱𝐔𝐏𝐃𝐀𝐓𝐄',
      serverMessageId: -1
    },
    mentionedJid: [target, m.sender]
  }

  // إرسال إشعار الطرد
  await conn.sendMessage(
    m.chat,
    {
      text: teks,
      contextInfo: channelInfo
    },
    { quoted: m }
  )
}

handler.help = ['طرد']
handler.tags = ['group']
handler.command = /^طرد$/i
handler.group = true
handler.admin = true

export default handler