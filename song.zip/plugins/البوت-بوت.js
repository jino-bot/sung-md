import { prepareWAMessageMedia, generateWAMessageFromContent } from "@whiskeysockets/baileys";
import fs from 'fs';

const handler = async (m, { conn }) => {
    // الإعدادات الجديدة
    const imagePath = "./src/media/Menu3.jpg"; // المسار المحلي للصورة
    const devNumber = "23595456638"; // رقم المطور
    const channelUrl = "https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o"; // رابط القناة
    
    // التزيين المطلوب
    const bodyText = `
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*『 👤┇بوت سونغ جينوو┇👤』*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*

\`⧉↫ اهلا بك في بوت سونغ جينو الاصدار الرابع\`

*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*`.trim();

    // التأكد من وجود الصورة وتجهيزها
    let media;
    if (fs.existsSync(imagePath)) {
        media = await prepareWAMessageMedia(
            { image: fs.readFileSync(imagePath) },
            { upload: conn.waUploadToServer }
        );
    } else {
        // في حال عدم وجود الصورة يرسل نص فقط أو يمكنك وضع رابط احتياطي هنا
        console.error("Image not found at: " + imagePath);
    }

    // إنشاء الرسالة التفاعلية بالأزرار الجديدة
    const interactiveMessage = {
        body: { text: bodyText },
        footer: { text: "> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*" },
        header: { 
            title: "", 
            hasMediaAttachment: !!media, 
            imageMessage: media ? media.imageMessage : null 
        },
        nativeFlowMessage: {
            buttons: [
                {
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "｢👑┊الـمـطـور┊👑｣",
                        url: `https://wa.me/${devNumber}`
                    })
                },
                {
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "｢📣┊الـقـنـاة┊📣｣",
                        url: channelUrl
                    })
                },
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "｢📜┊الـأوامـر┊📜｣",
                        id: ".اوامر"
                    })
                }
            ]
        }
    };

    // توليد الرسالة
    let msg = generateWAMessageFromContent(
        m.chat,
        { viewOnceMessage: { message: { interactiveMessage } } },
        { userJid: conn.user.jid, quoted: m }
    );

    // إرسال الرسالة
    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
};

handler.command = /^بوت$/i; 

export default handler;
