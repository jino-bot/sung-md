import fs from 'fs'
import path from 'path'

// 🧑‍💻 أرقام المطورين
const devNumbers = [
  '23595456638@s.whatsapp.net',
  '23585122237@s.whatsapp.net'
]

// 🐉 الزخرفة
const decoTop = '*❐═━━━═╊⊰🐉⊱╉═━━━═❐*'
const decoMid = '*⟐━───━「✨️✨️」━───━⟐*'

const handler = async (m, { conn, text }) => {

  // 🔒 تحقق من المطور
  if (!devNumbers.includes(m.sender)) return

  // 🧠 تحقق من الصيغة
  if (!text || !text.includes('|')) {
    return conn.reply(
      m.chat,
`${decoTop}
✧ *طريقة الاستخدام غير صحيحة* ❌

📌 استخدم الأمر هكذا:
*.بدل كلمة_قديمة|كلمة_جديدة*
${decoTop}`,
      m
    )
  }

  const [oldWord, newWord] = text.split('|').map(v => v.trim())
  if (!oldWord || !newWord) {
    return conn.reply(
      m.chat,
`${decoTop}
✧ *تأكد من كتابة الكلمتين بشكل صحيح* ⚠️
${decoTop}`,
      m
    )
  }

  const basePath = 'plugins'
  const files = fs.readdirSync(basePath).filter(f => f.endsWith('.js'))

  let changedFiles = 0
  let errors = []

  // 🔄 الاستبدال
  for (const file of files) {
    const filePath = path.join(basePath, file)
    try {
      const content = fs.readFileSync(filePath, 'utf-8')
      if (content.includes(oldWord)) {
        fs.writeFileSync(
          filePath,
          content.split(oldWord).join(newWord),
          'utf-8'
        )
        changedFiles++
      }
    } catch (e) {
      errors.push(`📄 ${file} → ${e.message}`)
    }
  }

  // ✅ رسالة النجاح
  let msg =
`${decoTop}
✧ *تم الاستبدال بنجاح* ✅

🔁 "${oldWord}" ➜ "${newWord}"
📂 عدد الملفات المتأثرة: ${changedFiles}
${decoMid}

*❏-🤖 الــبـــوت ⟦𝐒𝐨𝐧𝐠 𝐣𝐢𝐧𝐨⟧*
*❏-🧑‍💻 المـــطور ⟦𝐀𝐲𝐨𝐮𝐛⟧*
${decoTop}`

  if (errors.length) {
    msg += `\n\n⚠️ *أخطاء في بعض الملفات:*\n` + errors.join('\n')
  }

  await conn.reply(m.chat, msg, m)
}

handler.help = ['بدل <قديم>|<جديد>']
handler.tags = ['owner']
handler.command = /^بدل$/i

export default handler