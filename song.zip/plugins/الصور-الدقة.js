import Jimp from 'jimp'

// نستخدم نفس المخزن المؤقت لضمان التوافق بين الأوامر
const imageCache = new Map()

const resolutionOptions = [
  { name: '4K (Ultra HD)', width: 3840, height: 2160 },
  { name: '2K (QHD)', width: 2560, height: 1440 },
  { name: '1080p (Full HD)', width: 1920, height: 1080 },
  { name: '720p (HD)', width: 1280, height: 720 },
  { name: '480p (SD)', width: 854, height: 480 },
  { name: '360p', width: 640, height: 360 },
  { name: '144p', width: 256, height: 144 },
]

const handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ''
    const userId = m.sender

    // الحالة 1: عرض أزرار اختيار الدقة
    if (!text && mime.startsWith('image')) {
      const imgBuffer = await q.download()
      if (!imgBuffer) return conn.reply(m.chat, '❌ فشل تحميل الصورة', m)
      
      // حفظ الصورة في الذاكرة لتنفيذ التغيير عند الضغط على الزر
      imageCache.set(userId, imgBuffer)

      const buttons = resolutionOptions.map((res, i) => ({
        buttonId: `${usedPrefix + command} ${i + 1}`,
        buttonText: { displayText: `دقة ${res.name}` },
        type: 1
      }))

      return conn.sendMessage(
        m.chat,
        {
          image: imgBuffer,
          caption: '⚙️ اختر الدقة المطلوبة لتحويل الصورة إليها:',
          buttons,
          headerType: 4
        },
        { quoted: m }
      )
    }

    // الحالة 2: تنفيذ تغيير الدقة
    if (text) {
      const index = parseInt(text.trim()) - 1
      const selectedRes = resolutionOptions[index]

      if (!selectedRes) {
        return conn.reply(m.chat, `❌ اختيار غير صحيح. يرجى اختيار رقم من القائمة.`, m)
      }

      let imgBuffer = imageCache.get(userId)
      if (!imgBuffer && mime.startsWith('image')) {
        imgBuffer = await q.download()
      }

      if (!imgBuffer) {
        return conn.reply(m.chat, '❌ يرجى إرسال الصورة أو الرد عليها أولاً ثم استخدام الأمر.', m)
      }

      await conn.reply(m.chat, `⏳ جاري معالجة الصورة وتحويلها إلى ${selectedRes.name}...`, m)

      const image = await Jimp.read(imgBuffer)
      
      // تغيير الحجم مع الحفاظ على التناسب (Aspect Ratio)
      // نستخدم الـ width المحدد والارتفاع تلقائي للحفاظ على أبعاد الصورة الأصلية
      image.resize(selectedRes.width, Jimp.AUTO)

      const out = await image.getBufferAsync(Jimp.MIME_JPEG)
      const sizeInMB = (out.length / (1024 * 1024)).toFixed(2)

      await conn.sendFile(
        m.chat,
        out,
        'resolution.jpg',
        `✅ تم التحويل إلى: ${selectedRes.name}\n📦 الحجم التقريبي: ${sizeInMB} MB`,
        m
      )
      
      return
    }

    // إذا تم استدعاء الأمر بدون صورة
    conn.reply(m.chat, '❌ يجب الرد على صورة لتغيير دقتها.', m)

  } catch (e) {
    console.error(e)
    conn.reply(m.chat, '⚠️ حدث خطأ أثناء تغيير الدقة. قد تكون الصورة كبيرة جداً للمعالجة.', m)
  }
}

handler.help = ['الدقة']
handler.tags = ['tools']
handler.command = /^(الدقة|دقة)$/i

export default handler
