let handler = async (m, { conn, args, usedPrefix, command }) => {
    let chat = global.db.data.chats[m.chat]

    // عرض الحالة الحالية
    if (!args[0]) {
        let status = chat.antiver ? 'مفعل ✅' : 'معطل ❌'
        return m.reply(
            `*🛡️ حالة مانع الإخفاء (العرض مرة واحدة):*\n\n` +
            `• الحالة: ${status}\n\n` +
            `*للتحكم استخدم:*\n` +
            `• ${usedPrefix + command} on\n` +
            `• ${usedPrefix + command} off`
        )
    }

    // تفعيل
    if (args[0] === 'on') {
        if (chat.antiver) return m.reply('*⚠️ مانع الإخفاء مفعل بالفعل.*')
        chat.antiver = true
        return m.reply('*✅ تم تفعيل مانع الإخفاء بنجاح.\nسيتم كشف أي صورة/فيديو/صوت (عرض مرة واحدة).*')
    }

    // تعطيل
    if (args[0] === 'off') {
        if (!chat.antiver) return m.reply('*⚠️ مانع الإخفاء معطل بالفعل.*')
        chat.antiver = false
        return m.reply('*❌ تم تعطيل مانع الإخفاء بنجاح.*')
    }

    // أمر غير صحيح
    return m.reply(
        `*❌ أمر غير صالح*\n\n` +
        `استخدم:\n` +
        `• ${usedPrefix + command} on\n` +
        `• ${usedPrefix + command} off`
    )
}

// تعريفات الأمر
handler.help = ['اخفاء']
handler.tags = ['group']
handler.command = ['اخفاء', 'antiver', 'viewonce']

// الشروط
handler.group = true
handler.admin = true

export default handler
