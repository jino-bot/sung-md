import fs from 'fs'
import path from 'path'

const FILE_PATH = path.resolve('src/datatms.json')

let handler = async (m, { conn, args, usedPrefix, command, isAdmin }) => {
  if (!isAdmin) return m.reply('❌ هذا الأمر للمشرفين فقط')

  const chatId = m.chat
  let data = {}

  if (fs.existsSync(FILE_PATH)) {
    data = JSON.parse(fs.readFileSync(FILE_PATH))
  }

  // تهيئة المجموعة
  if (!data[chatId]) {
    data[chatId] = {
      enabled: false,
      total: 0,
      users: {}
    }
  }

  // عرض الحالة
  if (!args[0]) {
    const status = data[chatId].enabled ? 'مفعل ✅' : 'معطل ❌'
    return conn.reply(
      m.chat,
      `*📊 حالة نظام الحسبة:* ${status}\n\n` +
      `*الاستخدام:*\n` +
      `• ${usedPrefix + command} on\n` +
      `• ${usedPrefix + command} off`,
      m
    )
  }

  // تفعيل
  if (args[0] === 'on') {
    if (data[chatId].enabled) return m.reply('⚠️ الحسبة مفعلة بالفعل')
    data[chatId].enabled = true
    fs.writeFileSync(FILE_PATH, JSON.stringify(data, null, 2))
    return m.reply('✅ تم تفعيل نظام الحسبة بنجاح')
  }

  // تعطيل
  if (args[0] === 'off') {
    if (!data[chatId].enabled) return m.reply('⚠️ الحسبة معطلة بالفعل')
    data[chatId].enabled = false
    fs.writeFileSync(FILE_PATH, JSON.stringify(data, null, 2))
    return m.reply('❌ تم تعطيل نظام الحسبة')
  }

  m.reply(`❗ استخدم:\n${usedPrefix + command} on\n${usedPrefix + command} off`)
}

handler.help = ['حسبة']
handler.tags = ['group']
handler.command = ['حسبة']
handler.group = true
handler.admin = true

export default handler
