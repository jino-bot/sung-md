import fs from 'fs';

let handler = async (m, { conn, text, participants }) => {
    let users = participants.map(u => u.id);
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';
    let messageContent = text ? text : (m.quoted && m.quoted.text ? m.quoted.text : 'لا توجد رسالة محددة');

    // الزخرفة الأساسية
    let teks = `*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*⧉╎⏎ مـنـشـن مـخـفـي*
*✠ ━━ • ━ ‹✤› ━ • ━━ ✠*
*الرسالة ╎${messageContent} ╎*
*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`;

    // 1. حالة الرد على وسائط (صورة، فيديو، صوت، مستند)
    if (m.quoted && (mime.includes('image') || mime.includes('video') || mime.includes('audio') || mime.includes('document'))) {
        await conn.sendMessage(m.chat, { 
            forward: m.quoted.fakeObj, 
            contextInfo: { mentionedJid: users } 
        });
    } 
    
    // 2. حالة كتابة ".مخفي" بدون نص (إرسال الزخرفة مع الصورة من المسار)
    else if (!text && !m.quoted) {
        const imagePath = './src/media/Menu4.jpg';
        if (fs.existsSync(imagePath)) {
            await conn.sendMessage(m.chat, { 
                image: fs.readFileSync(imagePath), 
                caption: teks, 
                mentions: users 
            }, { quoted: m });
        } else {
            // إذا لم توجد الصورة في المسار يرسل النص فقط
            await conn.sendMessage(m.chat, { text: teks, mentions: users }, { quoted: m });
        }
    } 
    
    // 3. حالة ".مخفي نص" أو الرد على رسالة نصية (إرسال الزخرفة نصاً فقط)
    else {
        await conn.sendMessage(m.chat, { text: teks, mentions: users }, { quoted: m });
    }
};

handler.help = ['مخفي'];
handler.tags = ['group'];
handler.command = /^(مخفي|منشن_مخفي)$/i;
handler.group = true;
handler.admin = true;

export default handler;
