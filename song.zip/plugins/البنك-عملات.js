let handler = async (m, { conn, usedPrefix }) => {
    let who = m.quoted ? m.quoted.sender : m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
    let user = global.db.data.users[who]
    let username = conn.getName(who)

    if (!(who in global.db.data.users)) throw `🟨 المستخدم غير موجود في قاعدة بياناتي`

    let caption = `
*『🪙┇ العملات الذهبية┇🪙』*

*❐═━━━═╊⊰🐲⊱╉═━━━═❐*
*❐↞👤┇الــأســـــم: ${username}*
*❐↞🪙┇الـعـمـلات: ${user.coin}*
*❐═━━━═╊⊰🐲⊱╉═━━━═❐*

*❐↞💰┇النقــــــاط: ${user.bank}*
*❐↞💡┇الخـــبـــرة: ${user.exp}*

*❐═━━━═╊⊰🐲⊱╉═━━━═❐*

> *⌫┇اهـلا يمكنك اختيار زر من القائمة ┇〄*`.trim()

    // إرسال الرسالة مع زر البنك الذي ينفذ أمر .قسم11
    await conn.sendButton(m.chat, caption, '> 𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃', null, [
        ['🏦 الـبـنـك', `.قسم11`]
    ], m, { mentions: [who] })
}

handler.help = ['عملات']
handler.tags = ['economy']
handler.command = ['عملاتي', 'عملات'] 

export default handler
