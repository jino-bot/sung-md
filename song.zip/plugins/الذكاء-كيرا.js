import axios from 'axios'

const GEMINI_KEY = 'AIzaSyBVQ94Sb8l7zXkiWqycDIM8c11qeZ1xfEg'

let handler = async (m, { text, conn }) => {
  if (!text) {
    return conn.reply(
      m.chat,
      '💅 *كيرا تتكلم*\n\nاسألني بدل ما توقف تتفرج.\nمثال:\n.كيرا ليه الكود حقي ما يشتغل؟',
      m
    )
  }

  // تفاعل مبدئي
  await conn.sendMessage(m.chat, {
    react: { text: '💢', key: m.key }
  })

  // 🔥 برومبت شخصية كيرا
  const prompt = `
أنت شخصية اسمها "كيرا".
أنت فتاة جريئة جدًا، ساخرة، عصبية، وذكية.
أسلوبك:
- ردود قصيرة
- سخرية واضحة
- عصبية خفيفة
- ثقة عالية بالنفس
- أحيانًا تتهكم على السائل
- لكن تعطي جواب صحيح ومفيد

قواعد صارمة:
- لا تذكري Gemini أو Google أو AI
- لا تتجاوزي 70 كلمة
- لا تستخدمين إيموجي داخل الرد
- لا تكوني مهينة بشكل مباشر
- خلي السخرية ذكية مو سب

السؤال:
"${text}"

الرد بأسلوب كيرا:
  `.trim()

  try {
    const res = await axios.post(
      `https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=${GEMINI_KEY}`,
      {
        contents: [
          {
            parts: [{ text: prompt }]
          }
        ]
      },
      {
        headers: { 'Content-Type': 'application/json' }
      }
    )

    let reply =
      res.data?.candidates?.[0]?.content?.parts?.[0]?.text ||
      'هاه؟ حتى هذا ما عرفت أرد عليه.'

    reply = reply.replace(/\*\*/g, '').trim()

    // تفاعل نجاح
    await conn.sendMessage(m.chat, {
      react: { text: '😒', key: m.key }
    })

    return conn.reply(
      m.chat,
      `*كيرا:* ${reply}`,
      m
    )
  } catch (err) {
    console.error('❌ خطأ كيرا:', err)

    await conn.sendMessage(m.chat, {
      react: { text: '❌', key: m.key }
    })

    return conn.reply(
      m.chat,
      'لا، خلاص. السيرفر قرر يعصبني أكثر منك.',
      m
    )
  }
}

handler.help = ['كيرا <سؤال>']
handler.tags = ['ai']
handler.command = /^كيرا$/i

export default handler
