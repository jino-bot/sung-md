const SPAM_LIMIT = 5      // عدد الرسائل
const SPAM_TIME = 7000    // الفترة الزمنية (7 ثواني)
const REPEAT_LIMIT = 3    // تكرار نفس المحتوى

let handler = async (m, { conn, chat, isAdmin, isOwner, isROwner, isBotAdmin }) => {
  // 1. الحمايات الأساسية (تجاهل المطورين، البوت نفسه، والرسائل الخاصة)
  if (!m.isGroup || !chat.antiSpam) return
  if (m.fromMe || isOwner || isROwner || m.isBaileys) return
  if (!m.message) return

  let user = global.db.data.users[m.sender]
  if (!user) return

  // تهيئة سجل السبام للمستخدم
  user.spam = user.spam || { msgs: [], lastContent: '', repeat: 0, warned: false }

  const now = Date.now()

  // التعرف على المحتوى (نص أو بصمة الملف الرقمية للوسائط)
  const contentId = m.text || m.msg?.fileSha256?.toString('hex') || m.mtype

  // تنظيف الرسائل القديمة من السجل
  user.spam.msgs = user.spam.msgs.filter(v => now - v.time < SPAM_TIME)
  
  // إضافة الرسالة الحالية للسجل
  user.spam.msgs.push({ time: now, id: m.key?.id })

  // فحص التكرار (نصوص، ملصقات، صور)
  if (contentId === user.spam.lastContent) {
    user.spam.repeat++
  } else {
    user.spam.repeat = 1
    user.spam.lastContent = contentId
  }

  // هل تجاوز الحد؟
  const isSpam = user.spam.msgs.length >= SPAM_LIMIT || user.spam.repeat >= REPEAT_LIMIT
  if (!isSpam) return

  const mention = '@' + m.sender.split('@')[0]

  // 2. حذف كل الرسائل المسببة للإسبام
  if (isBotAdmin) {
    for (const msg of user.spam.msgs) {
      if (!msg.id) continue
      await conn.sendMessage(m.chat, {
        delete: { remoteJid: m.chat, fromMe: false, id: msg.id, participant: m.sender }
      }).catch(() => {})
    }
  }

  // 3. التعامل مع المشرف (إنذار فقط بدون طرد)
  if (isAdmin) {
    user.spam.msgs = [] // تصفير السجل للمشرف بعد الحذف
    user.spam.repeat = 0
    return conn.sendMessage(m.chat, {
      text: `⚠️ عذراً أيها المشرف ${mention}، تم حذف رسائل الإسبام الخاصة بك للحفاظ على هدوء المجموعة.`,
      mentions: [m.sender]
    })
  }

  // 4. نظام العقوبات للأعضاء (تحذير ثم طرد مباشر)
  if (!user.spam.warned) {
    // أول مرة: تحذير وتصفير مؤقت
    user.spam.warned = true
    user.spam.msgs = []
    user.spam.repeat = 0

    return conn.sendMessage(m.chat, {
      text: `⚠️ *تحذير إسبام يا ${mention}*\nتم حذف رسائلك. إذا كررت الأمر الآن سيتم طردك فوراً!`,
      mentions: [m.sender]
    })
  } else {
    // ثاني مرة: طرد مباشر
    if (isBotAdmin) {
      await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove').catch(() => {})
      user.spam = null // حذف بياناته تماماً بعد الطرد
      return conn.sendMessage(m.chat, {
        text: `🚫 تم طرد ${mention} بسبب تكرار الإسبام بعد التحذير.`,
        mentions: [m.sender]
      })
    }
  }
}

handler.before = handler // ليعمل الكود تلقائياً عند كل رسالة
export default handler
