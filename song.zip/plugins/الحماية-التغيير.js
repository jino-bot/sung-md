let handler = async (m, { conn, args, usedPrefix, command }) => {
    let chat = global.db.data.chats[m.chat]
    if (!chat) return

    // ===== عرض الحالة =====
    if (!args[0]) {
        let status = chat.protect ? 'مفعل ✅' : 'معطل ❌'
        return conn.reply(
            m.chat,
            `*🛡️ حالة حماية المجموعة:* ${status}\n\n` +
            `*الاستخدام:*\n` +
            `• ${usedPrefix + command} on (تفعيل)\n` +
            `• ${usedPrefix + command} off (تعطيل)`,
            m
        )
    }

    // ===== تفعيل الحماية =====
    if (args[0] === 'on') {
        if (chat.protect) {
            return m.reply('⚠️ حماية المجموعة مفعّلة بالفعل.')
        }

        // جلب بيانات المجموعة
        let metadata = await conn.groupMetadata(m.chat)

        // حفظ الحالة الأصلية
        chat.groupState = {
            name: metadata.subject || '',
            desc: metadata.desc || '',
            photo: await conn.profilePictureUrl(m.chat, 'image').catch(() => null)
        }

        chat.protect = true
        chat.protectLock = false

        return m.reply('✅ تم تفعيل حماية المجموعة ومنع جميع التغييرات.')
    }

    // ===== تعطيل الحماية =====
    if (args[0] === 'off') {
        if (!chat.protect) {
            return m.reply('⚠️ حماية المجموعة معطّلة بالفعل.')
        }

        chat.protect = false
        chat.protectLock = false
        chat.groupState = null

        return m.reply('❌ تم تعطيل حماية المجموعة.')
    }

    // ===== إدخال غير صحيح =====
    return m.reply(
        `❌ خيار غير صحيح\n\n` +
        `*استخدم فقط:*\n` +
        `• ${usedPrefix + command} on\n` +
        `• ${usedPrefix + command} off`
    )
}

// ===== تعريفات الأمر =====
handler.help = ['حماية']
handler.tags = ['group']
handler.command = ['حماية', 'protect']

// ===== القيود =====
handler.group = true
handler.admin = true
handler.botAdmin = true

export default handler