let handler = async (m, { conn }) => {

const text = `
*↲مـطـور  الـبـوت↳*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
*\`مـرًحـبا بـك فـي شـات مـطـوري\`*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
*❐⇇ إسم المطور ┊ \`𝐀𝐲𝐨𝐮𝐛\` ┊*
*❐⇇ لقـب المطور ┊ \`𝐒𝐮𝐨𝐧𝐠\` ┊*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
*⏎ شروط التكلم مع المطور*
① ارسال طلبك كاملا في رسالة واحدة.
② مـمـنـوع الاتـصـال نـهـائـيـاً .
③ الإزعـاج يـعـنـي حـظـرك تـلـقـائـيـاً (بـلوك) .
④ ممنوع الدخول لدافع السوالف
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> 𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃
`

// إرسال الرسالة النصية
await conn.reply(m.chat, text, m)

// إرسال بطاقة جهة الاتصال
await conn.sendMessage(
  m.chat,
  {
    contacts: {
      displayName: 'Ayoub | Developer',
      contacts: [
        {
          vcard:
`BEGIN:VCARD
VERSION:3.0
FN:Ayoub
ORG:Song Bot Developer
TEL;type=CELL;type=VOICE;waid=23595456638:+23595456638
END:VCARD`
        }
      ]
    }
  },
  { quoted: m }
)

}

handler.command = /^المطور$/i
handler.tags = ['info']
handler.help = ['المطور']

export default handler
