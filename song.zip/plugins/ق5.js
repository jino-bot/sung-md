import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

let handler = async (m, { conn, usedPrefix }) => {
    try {
        await conn.sendMessage(m.chat, { react: { text: "🕌", key: m.key } });

        let name = await conn.getName(m.sender)
        
        const messageText = `*مـــرحبــــاً بـــكـ/ﻲ يـا ❪${name}❫ في قسم الدين*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *شرح القسم: واحة إيمانية تضم الأذكار، التفسير، والتلاوات العطرة*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *｢🕌┊قسم الإسـلامـيـات┊🕌｣*
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
┊📖┊: \`${usedPrefix}حديث\`
> قراءة حديث نبوي شريف.
┊📜┊: \`${usedPrefix}تفسير\`
> تفسير سور جزء عمَّ بشكل مبسط ومنظم.
┊🕌┊: \`${usedPrefix}آية\`
> عرض سورة كاملة أو آيات معينة من القرآن.
┊🎓┊: \`${usedPrefix}شيخ\`
> استفسر عن أمور دينك مع بوت الفقيه الذكي.
┊🎧┊: \`${usedPrefix}استماع\`
> تلاوات خاشعة بصوت الشيخ ماهر المعيقلي.
┊🕋┊: \`${usedPrefix}مواقيت\`
> معرفة مواقيت الصلاة حسب مدينتك بدقة.
┊🌅┊: \`${usedPrefix}اذكار_الصباح\`
> قرائة ذكر صباحي للتحصين وكسب الاجر.
┊🌄┊: \`${usedPrefix}اذكار_المساء\`
> قرائة ذكر مسائي للتحصين وكسب الاجر.
┊🍽┊: \`${usedPrefix}افطاري\`
> اختيار فطور لذيذ على الصيام.
┊🕋┊: \`${usedPrefix}الله\`
> عرض تفسير اسم من احد اسماء الله الحسنى.
*❐═━━━═╊⊰🐉⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*`

        const imagePath = path.join(__dirname, '../src/media/Menu4.jpg')

        if (fs.existsSync(imagePath)) {
            await conn.sendMessage(m.chat, { image: { url: imagePath }, caption: messageText }, { quoted: m })
        } else {
            await conn.sendMessage(m.chat, { text: messageText }, { quoted: m })
        }
    } catch (e) { console.error(e) }
}

handler.help = ['الدين']
handler.tags = ['islam']
handler.command = /^(قسم5)$/i 

export default handler
