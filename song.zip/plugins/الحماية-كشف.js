let handler = async (m, { args, usedPrefix, command }) => {
    let chat = global.db.data.chats[m.chat]

    // عرض الحالة
    if (!args[0]) {
        let status = chat.detect ? 'مفعل ✅' : 'معطل ❌'
        return m.reply(
            `*📢 إشعارات تغييرات المجموعة*\n\n` +
            `• الحالة: ${status}\n\n` +
            `*طريقة الاستخدام:*\n` +
            `• ${usedPrefix + command} on\n` +
            `• ${usedPrefix + command} off`
        )
    }

    // تفعيل
    if (args[0] === 'on') {
        if (chat.detect) return m.reply('⚠️ الإشعارات مفعلة بالفعل.')
        chat.detect = true
        return m.reply('✅ تم تفعيل إشعارات تغييرات المجموعة.')
    }

    // تعطيل
    if (args[0] === 'off') {
        if (!chat.detect) return m.reply('⚠️ الإشعارات معطلة بالفعل.')
        chat.detect = false
        return m.reply('❌ تم تعطيل إشعارات تغييرات المجموعة.')
    }

    // خطأ
    return m.reply(
        `❌ خيار غير صحيح\n\n` +
        `استخدم:\n` +
        `• ${usedPrefix + command} on\n` +
        `• ${usedPrefix + command} off`
    )
}

handler.help = ['كشف']
handler.tags = ['group']
handler.command = ['كشف', 'detect', 'اشعارات']

handler.group = true
handler.admin = true

export default handler