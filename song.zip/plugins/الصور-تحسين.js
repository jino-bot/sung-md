import Jimp from 'jimp'

// مخزن مؤقت لحفظ صور المستخدمين لتنفيذ العمليات عليها عبر الأزرار
const imageCache = new Map()

const colorOptions = [
  { name: 'أحمر', color: '#FF0000' },
  { name: 'أخضر', color: '#00FF00' },
  { name: 'أزرق', color: '#0000FF' },
  { name: 'أصفر', color: '#FFFF00' },
  { name: 'برتقالي', color: '#FFA500' },
  { name: 'بنفسجي', color: '#800080' },
  { name: 'رمادي', color: '#808080' },
]

const operations = [
  { name: 'تغيير الحجم', operation: img => img.resize(800, Jimp.AUTO) },
  { name: 'زيادة الحدة', operation: img => img.convolute([[0,-1,0],[-1,5,-1],[0,-1,0]]) },
  { name: 'تحسين السطوع', operation: img => img.brightness(0.1) },
  { name: 'تحسين التباين', operation: img => img.contrast(0.3) },
  { name: 'أبيض وأسود', operation: img => img.grayscale() },
  { name: 'تنعيم', operation: img => img.blur(5) },
  { name: 'تدوير', operation: img => img.rotate(90) },
  { name: 'تغيير الألوان', operation: null },
  { name: 'شفافية', operation: img => img.opacity(0.8) },
  { name: 'إضافة نص', operation: null },
  { name: 'قص', operation: null },
  { name: 'إطار مشوش', operation: null },
  { name: 'بورتريه', operation: null },
  { name: 'HD', operation: img => img.resize(Jimp.AUTO, 1080) },
  { name: 'ضبابية', operation: img => img.blur(10) },
  { name: 'كرتوني', operation: img => img.convolute([[-1,-1,-1],[-1,9,-1],[-1,-1,-1]]) },
  { name: 'ظل', operation: img => {
      const shadow = img.clone().opacity(0.5).blur(5)
      return img.composite(shadow, 10, 10)
    }
  },
  { name: 'زيتي', operation: img => img.color([{ apply: 'mix', params: ['#8B4513', 100] }]) },
  { name: 'HDR', operation: img => img.contrast(0.3).brightness(0.1) },
  { name: 'فيلم', operation: img => img.color([{ apply: 'mix', params: ['#000000', 50] }]) },
  { name: 'تشويش', operation: img => img.blur(3) },
  { name: 'تعتيم', operation: img => img.opacity(0.5) },
]

const handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ''
    const userId = m.sender

    // الحالة 1: إرسال قائمة الأزرار (عند الرد على صورة أو إرسال صورة مع الأمر)
    if (!text && mime.startsWith('image')) {
      const imgBuffer = await q.download()
      if (!imgBuffer) return conn.reply(m.chat, '❌ فشل تحميل الصورة', m)
      
      // حفظ الصورة في الذاكرة المؤقتة للمستخدم
      imageCache.set(userId, imgBuffer)

      const buttons = operations.map((op, i) => ({
        buttonId: `${usedPrefix + command} ${i + 1}`,
        buttonText: { displayText: `${i + 1}. ${op.name}` },
        type: 1
      }))

      return conn.sendMessage(
        m.chat,
        {
          image: imgBuffer,
          caption: '🎨 اختر عملية تحسين من الأسفل تطبيقها على هذه الصورة:',
          buttons,
          headerType: 4
        },
        { quoted: m }
      )
    }

    // الحالة 2: تنفيذ العملية (عند الضغط على زر أو كتابة رقم)
    if (text) {
      const args = text.trim().split(/\s+/)
      const index = parseInt(args[0]) - 1
      const extra = args.slice(1).join(' ')

      if (isNaN(index) || !operations[index]) {
        return conn.reply(m.chat, `❌ رقم غير صحيح. اختر من 1 إلى ${operations.length}`, m)
      }

      // جلب الصورة من الذاكرة المؤقتة أو من الرد المباشر
      let imgBuffer = imageCache.get(userId)
      if (!imgBuffer && mime.startsWith('image')) {
        imgBuffer = await q.download()
      }

      if (!imgBuffer) {
        return conn.reply(m.chat, '❌ انتهت صلاحية الجلسة أو لم يتم العثور على صورة. يرجى إرسال الصورة مرة أخرى.', m)
      }

      const image = await Jimp.read(imgBuffer)

      // --- تنفيذ العمليات الخاصة ---
      
      // تغيير الألوان
      if (operations[index].name === 'تغيير الألوان') {
        const colorIndex = parseInt(extra) - 1
        const color = colorOptions[colorIndex]
        if (!color) {
          const colorList = colorOptions.map((c, i) => `*${i + 1}.* ${c.name}`).join('\n')
          return conn.reply(m.chat, `🎨 اختر لوناً بإرسال الرقم مع الأمر:\nمثال: *${usedPrefix + command} ${index + 1} 1*\n\n${colorList}`, m)
        }
        image.color([{ apply: 'mix', params: [color.color, 100] }])
      }

      // إضافة نص
      if (operations[index].name === 'إضافة نص') {
        if (!extra) return conn.reply(m.chat, `❌ يرجى كتابة النص بعد الرقم.\nمثال: *${usedPrefix + command} ${index + 1} Hello*`, m)
        const font = await Jimp.loadFont(Jimp.FONT_SANS_64_WHITE)
        image.print(font, 10, image.bitmap.height - 80, extra)
      }

      // إطار مشوش
      if (operations[index].name === 'إطار مشوش') {
        const bg = image.clone().blur(15).resize(
          image.bitmap.width * 1.2,
          image.bitmap.height * 1.2
        )
        bg.composite(
          image,
          (bg.bitmap.width - image.bitmap.width) / 2,
          (bg.bitmap.height - image.bitmap.height) / 2
        )
        image.bitmap = bg.bitmap
      }

      // بورتريه
      if (operations[index].name === 'بورتريه') {
        const w = image.bitmap.height * (9 / 16)
        image.resize(w, image.bitmap.height)
        image.crop(0, 0, w, image.bitmap.height)
      }

      // تنفيذ العملية العامة (إذا وجدت)
      if (operations[index].operation) {
        await operations[index].operation(image)
      }

      const out = await image.getBufferAsync(Jimp.MIME_JPEG)

      await conn.sendFile(
        m.chat,
        out,
        'enhanced.jpg',
        `✅ تم تطبيق: ${operations[index].name}`,
        m
      )
      
      // اختيارياً: مسح الصورة من الذاكرة بعد التنفيذ لتوفير الرام
      // imageCache.delete(userId) 
      
      return
    }

    // إذا لم يرسل نصاً ولم يرفق صورة
    conn.reply(m.chat, '❌ يجب الرد على صورة أو إرسال صورة مع الأمر لاستخدام أدوات التحسين.', m)

  } catch (e) {
    console.error(e)
    conn.reply(m.chat, '⚠️ خطأ أثناء معالجة الصورة', m)
  }
}

handler.help = ['تحسين']
handler.tags = ['tools']
handler.command = /^(تحسين)$/i
export default handler
