import fs from 'fs'

let handler = async (m, { conn, args }) => {
  try {
    const header = '*⎔⋅• ━╼╃ ⌬〔️🐲〕⌬ ╄╾ ━ •⋅⎔*'
    const footer = header
    const imageUrl = 'https://files.catbox.moe/rirzvp.jpg'

    const styles = [
      { name: "𝟎𝟏𝟐𝟑𝟒𝟓𝟔𝟕𝟖𝟗", map: mapStyle('𝟎','𝟏','𝟐','𝟑','𝟒','𝟓','𝟔','𝟕','𝟖','𝟗') },
      { name: "𝟬𝟭𝟮𝟯𝟰𝟱𝟲𝟳𝟴𝟵", map: mapStyle('𝟬','𝟭','𝟮','𝟯','𝟰','𝟱','𝟲','𝟳','𝟴','𝟵') },
      { name: "𝟘𝟙𝟚𝟛𝟜𝟝𝟞𝟟𝟠𝟡", map: mapStyle('𝟘','𝟙','𝟚','𝟛','𝟜','𝟝','𝟞','𝟟','𝟠','𝟡') },
      { name: "⓿①②③④⑤⑥⑦⑧⑨", map: mapStyle('⓿','①','②','③','④','⑤','⑥','⑦','⑧','⑨') },
      { name: "０１２３４５６７８９", map: mapStyle('０','１','２','３','４','５','６','７','８','９') },
      { name: "₀₁₂₃₄₅₆₇₈₉", map: mapStyle('₀','₁','₂','₃','₄','₅','₆','₇','₈','₉') },
      { name: "⁰¹²³⁴⁵⁶⁷⁸⁹", map: mapStyle('⁰','¹','²','³','⁴','⁵','⁶','⁷','⁸','⁹') },
      { name: "〇一二三四五六七八九", map: mapStyle('〇','一','二','三','四','五','六','七','八','九') }
    ]

    /* ===== بدون إدخال ===== */
    if (!args[0]) {
      let text = `${header}\n`
      text += '*📜 الأنماط المتاحة للأرقام:*\n\n'

      styles.forEach((s, i) => {
        text += `*${i + 1}* ⟶ ${s.name}\n`
      })

      text += `\n✏️ *مثال:* \`.أرقام 2 12345\`\n`
      text += footer

      return conn.sendMessage(m.chat, {
        image: { url: imageUrl },
        caption: text
      }, { quoted: m })
    }

    /* ===== مع إدخال ===== */
    const index = parseInt(args[0]) - 1
    const input = args.slice(1).join('')

    if (isNaN(index) || index < 0 || index >= styles.length || !input) {
      return m.reply('❌ الصيغة الصحيحة:\n`.أرقام [رقم النمط] [الأرقام]`')
    }

    const result = input
      .split('')
      .map(c => styles[index].map[c] || c)
      .join('')

    await m.reply(result)

  } catch (e) {
    console.error(e)
    m.reply('❌ حدث خطأ')
  }
}

/* ===== EMS INFO ===== */
handler.help = ['أرقام']
handler.tags = ['tools']
handler.command = /^أرقام$/i

export default handler

function mapStyle(z0,z1,z2,z3,z4,z5,z6,z7,z8,z9) {
  return {
    '0': z0, '1': z1, '2': z2, '3': z3, '4': z4,
    '5': z5, '6': z6, '7': z7, '8': z8, '9': z9
  }
}