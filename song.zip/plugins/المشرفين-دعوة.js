let handler = async (m, { conn, text, usedPrefix, command }) => {

  if (!text)
    throw `❌ *اكتب الرقم الذي تريد إرسال الدعوة له*\n\n📌 مثال:\n${usedPrefix + command} 249922420554`

  if (text.includes('+'))
    throw '❌ *لا تضع علامة + في الرقم*'

  if (isNaN(text))
    throw '❌ *أدخل الرقم بدون مسافات أو حروف*'

  let jid = text + '@s.whatsapp.net'
  let group = m.chat

  let link = 'https://chat.whatsapp.com/' + await conn.groupInviteCode(group)

  await conn.sendMessage(jid, {
    text: `*📩 دعوة للانضمام إلى القروب*\n\n🔗 *رابط الدعوة:*\n${link}`,
    mentions: [m.sender]
  })

  await m.reply('✅ *تم إرسال رابط الدعوة بنجاح*')
}

handler.help = ['دعوة <رقم>']
handler.tags = ['group']
handler.command = /^(دعوة|دعوه)$/i
handler.group = true
handler.botAdmin = true
handler.admin = false // غيرها true لو حاب للمشرفين فقط

export default handler