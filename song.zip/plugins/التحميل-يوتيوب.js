import { exec } from 'child_process'
import { promisify } from 'util'
import fs from 'fs'
import path from 'path'

const execAsync = promisify(exec)

let handler = async (m, { conn, args }) => {
  const chatId = m.chat

  // ===============================
  // ✅ الحالة 1: رابط فقط → معلومات + أزرار
  // ===============================
  if (args.length === 1 && args[0].startsWith('http')) {
    const url = args[0]

    let info
    try {
      const { stdout } = await execAsync(
        `yt-dlp --print "%(title)s|%(duration_string)s|%(uploader)s" "${url}"`
      )
      const [title, duration, uploader] = stdout.trim().split('|')
      info = { title, duration, uploader }
    } catch {
      info = {
        title: 'غير معروف',
        duration: 'غير معروف',
        uploader: 'غير معروف'
      }
    }

    return conn.sendMessage(chatId, {
      text:
        `┏━━━✦ 『 📊 معلومات الفيديو 』✦━━━┓\n\n` +
        `🎬 العنوان: ${info.title}\n` +
        `⏱️ المدة: ${info.duration}\n` +
        `📤 القناة: ${info.uploader}\n\n` +
        `اختر طريقة التحميل:\n` +
        `┗━━━━━━━━━━━━━━━━━━━━┛`,
      buttons: [
        {
          buttonId: `.يوتيوب فيديو ${url}`,
          buttonText: { displayText: '🎬 تحميل فيديو' },
          type: 1
        },
        {
          buttonId: `.يوتيوب صوت ${url}`,
          buttonText: { displayText: '🎧 تحميل صوت' },
          type: 1
        }
      ],
      headerType: 1
    }, { quoted: m })
  }

  // ===============================
  // ❌ صيغة ناقصة
  // ===============================
  if (args.length < 2) {
    return conn.sendMessage(chatId, {
      text:
        `❌ *| الصيغة الصحيحة:*\n\n` +
        `.يوتيوب (الرابط)\n` +
        `.يوتيوب فيديو (الرابط)\n` +
        `.يوتيوب صوت (الرابط)`
    }, { quoted: m })
  }

  // ===============================
  // ✅ الحالة 2: تحميل فعلي
  // ===============================
  const format = args[0].toLowerCase()
  const url = args[1]

  const tempDir = './temp'
  if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true })

  const filePath = path.join(
    tempDir,
    `${Date.now()}.${format === 'صوت' ? 'mp3' : 'mp4'}`
  )

  await conn.sendMessage(chatId, {
    text: `⏳ جاري التحميل...\n🎬 النوع: ${format}`
  }, { quoted: m })

  // 🎬 فيديو
  if (format === 'فيديو') {
    exec(`yt-dlp -f mp4 -o "${filePath}" "${url}"`, async err => {
      if (err || !fs.existsSync(filePath)) {
        return conn.sendMessage(chatId, {
          text: '❌ فشل تحميل الفيديو'
        }, { quoted: m })
      }

      await conn.sendMessage(chatId, {
        video: fs.readFileSync(filePath),
        caption:
          `┏━━━✦ 『 📥 تم التحميل 』✦━━━┓\n\n` +
          `🎬 النوع: فيديو\n` +
          `📱 المصدر: YouTube\n` +
          `🤖 بواسطة: سونغ\n` +
          `┗━━━━━━━━━━━━━━━━━━━━┛`
      }, { quoted: m })

      fs.unlinkSync(filePath)
    })
  }

  // 🎧 صوت
  else if (format === 'صوت') {
    exec(`yt-dlp -x --audio-format mp3 -o "${filePath}" "${url}"`, async err => {
      if (err || !fs.existsSync(filePath)) {
        return conn.sendMessage(chatId, {
          text: '❌ فشل تحميل الصوت'
        }, { quoted: m })
      }

      await conn.sendMessage(chatId, {
        audio: fs.readFileSync(filePath),
        mimetype: 'audio/mpeg',
        caption:
          `┏━━━✦ 『 🎧 تم التحميل 』✦━━━┓\n\n` +
          `🔊 النوع: صوت\n` +
          `📱 المصدر: YouTube\n` +
          `🤖 بواسطة: سونغ\n` +
          `┗━━━━━━━━━━━━━━━━━━━━┛`
      }, { quoted: m })

      fs.unlinkSync(filePath)
    })
  }

  else {
    return conn.sendMessage(chatId, {
      text: '❗ اختر: فيديو أو صوت'
    }, { quoted: m })
  }
}

handler.help = ['يوتيوب <رابط>', 'يوتيوب <فيديو|صوت> <رابط>']
handler.tags = ['downloader']
handler.command = ['يوتيوب']

export default handler