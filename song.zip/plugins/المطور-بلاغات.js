import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const REPORTS_DIR = path.join(__dirname, '../src/JSON');
const REPORTS_FILE = path.join(REPORTS_DIR, 'البلاغات.json');

function formatDate(dateStr) {
  const d = new Date(dateStr);
  return d.toLocaleString('ar-EG', { hour12: false });
}

let handler = async (m, { conn }) => {
  try {
    // نص الرسالة
    let text = '';
    if (m.message?.conversation) text = m.message.conversation;
    else if (m.message?.extendedTextMessage?.text) text = m.message.extendedTextMessage.text;
    else if (m.message?.imageMessage?.caption) text = m.message.imageMessage.caption;
    else if (m.message?.videoMessage?.caption) text = m.message.videoMessage.caption;
    text = text.trim();

    // إزالة الأمر نفسه من النص
    const commandRegex = /^\.?بلاغات\s*/i;
    text = text.replace(commandRegex, '').trim();

    // التحقق من وجود الملف
    if (!await fs.pathExists(REPORTS_FILE)) {
      return conn.sendMessage(m.key.remoteJid, { text: '📂 لا يوجد بلاغات مسجلة حالياً.' }, { quoted: m });
    }

    let reports = await fs.readJSON(REPORTS_FILE);
    if (!reports.length) {
      return conn.sendMessage(m.key.remoteJid, { text: '📂 لا يوجد بلاغات مسجلة حالياً.' }, { quoted: m });
    }

    // إذا لم يحدد رقم، عرض قائمة البلاغات
    if (!text) {
      let listText = `*❍━━━══━━❪📮❫━━══━━━❍*\n\n*📋 قائمة البلاغات:*\n\n`;
      reports.forEach((_, i) => {
        listText += `*${i + 1}.* بلاغ\n`;
      });
      listText += `\n*❍━━━══━━❪📮❫━━══━━━❍*`;
      return conn.sendMessage(m.key.remoteJid, { text: listText }, { quoted: m });
    }

    const args = text.split(/\s+/);
    const index = parseInt(args[0], 10) - 1;

    if (isNaN(index) || index < 0 || index >= reports.length) {
      return conn.sendMessage(m.key.remoteJid, { text: '❗ رقم البلاغ غير صحيح.' }, { quoted: m });
    }

    // حذف البلاغ
    if (args[1] && args[1].toLowerCase() === 'حذف') {
      const removed = reports.splice(index, 1);
      await fs.writeJSON(REPORTS_FILE, reports, { spaces: 2 });
      return conn.sendMessage(m.key.remoteJid, {
        text: `✅ تم حذف البلاغ رقم ${index + 1} بنجاح:\n\n📝: ${removed[0].text}`
      }, { quoted: m });
    }

    // عرض البلاغ بالتفصيل
    const r = reports[index];
    const fullText = `
*❍━━══━━✦🌊✦━━══━━❍*
*┊   🚀『 𝑩𝑶𝑻 - 𝐒𝐎𝐍𝐆 』🚀 ┊*
*❍━━══━━✦🌊✦━━══━━❍*

📢 *بلاغ رقم:* ${index + 1}
👤 *من:* wa.me/${r.user.split('@')[0]}
🕒 *التاريخ:* ${formatDate(r.time || r.timestamp)}

📝 *النص:*
${r.text}
    `.trim();

    return conn.sendMessage(m.key.remoteJid, {
      text: fullText,
      contextInfo: {
        externalAdReply: {
          title: 'قناة البوت',
          body: 'Song Bot',
          thumbnailUrl: 'https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o',
          sourceUrl: 'https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o'
        }
      }
    }, { quoted: m });

  } catch (error) {
    console.error('❌ خطأ في تنفيذ أمر بلاغات:', error);
    await conn.sendMessage(m.key.remoteJid, {
      text: '❌ حدث خطأ أثناء تنفيذ الأمر.'
    }, { quoted: m });
  }
}

handler.command = /^(بلاغات)$/i;
handler.owner = true; // للأمان: للمطور فقط
export default handler;
