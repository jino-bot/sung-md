let handler = async (m, { conn, args }) => {
  const prompt = args.join(' ').trim()

  if (!prompt) {
    return conn.reply(
      m.chat,
      '❌ أرسل النص بعد الأمر.\n\nمثال:\n.ارسم غوكو يقاتل في الفضاء',
      m
    )
  }

  try {
    // ستايل أبيض وأسود (رسم بالقلم)
    const artPrompt = `${prompt}, black and white pencil sketch, line art, anime drawing, no colors`
    const imageUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(artPrompt)}`

    const caption = `
*❐═━━━═╊⊰🖼️⊱╉═━━━═❐*

✏️ *الوصف:* ${prompt}
🎨 *النمط:* رسمة أبيض وأسود

*❐═━━━═╊⊰🖼️⊱╉═━━━═❐*
> *𝙱𝚈┇𝚂𝙾𝙽𝙶 𝙱𝙾𝚃*
    `.trim()

    // تفاعل قبل الإرسال
    try {
      await conn.sendMessage(m.chat, {
        react: { text: '🎨', key: m.key }
      })
    } catch {}

    await conn.sendMessage(
      m.chat,
      {
        image: { url: imageUrl },
        caption
      },
      { quoted: m }
    )

    // تفاعل نجاح
    try {
      await conn.sendMessage(m.chat, {
        react: { text: '✅', key: m.key }
      })
    } catch {}

  } catch (e) {
    console.error('❌ خطأ في أمر ارسم:', e)
    await conn.reply(m.chat, '❌ حدث خطأ أثناء إنشاء الرسمة.', m)
  }
}

handler.help = ['ارسم <وصف>']
handler.tags = ['tools', 'ai']
handler.command = /^ارسم$/i

export default handler